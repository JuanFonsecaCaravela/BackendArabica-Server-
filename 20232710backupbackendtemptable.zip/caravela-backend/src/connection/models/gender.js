"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const gender = sequelize.define(
    "gender",
    {
      gender_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      i18n: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "gender",
        plural: "gender"
      }
    }
  );
  gender.associate = function (models) {
    gender.hasMany(models.caravela_user, {
      foreignKey: { name: 'gender_id', allowNull: false }
    });

    gender.belongsTo(models.family_member, {
      foreignKey: { name: "gender_id", allowNull: false }
    });
  };
  sequelizePaginate.paginate(gender);
  return gender;
};
