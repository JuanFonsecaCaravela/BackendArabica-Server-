'use strict';
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const Nutrition = sequelize.define('Nutrition', {
    nutrient_id: DataTypes.STRING,
    nutrient: DataTypes.STRING,
    acronym: DataTypes.STRING,
    maximum_excess: DataTypes.STRING,
    maximum_deficit: DataTypes.STRING,
    condition: DataTypes.BOOLEAN,
    isDeleted:DataTypes.BOOLEAN,
    isDeletedDate:DataTypes.STRING,
    version:DataTypes.INTEGER
  }, {});
  Nutrition.associate = function(models) {
    // associations can be defined here
    Nutrition.hasMany(models.NutriPercent,{
      foreignKey: { name: "NutriRef", allowNull: false},
    })
  };
  sequelizePaginate.paginate(Nutrition);
  return Nutrition;
};