import express from 'express'
import jwtService from '../services/jwt.service'
import ctrlConfiguration from '../controllers/configuration.controller'

const router = express.Router()
const verifyToken = jwtService.verifyToken
router.post('/', verifyToken, ctrlConfiguration.create)
router.put('/:id', verifyToken, ctrlConfiguration.update)
router.get('/getParametroNitrogeno', verifyToken, ctrlConfiguration.getParametroNitrogeno)
router.get('/urlMobilePolicy', ctrlConfiguration.urlMobilePolicy)
router.get('/getAppVersion', ctrlConfiguration.getAppVersion)


export default router