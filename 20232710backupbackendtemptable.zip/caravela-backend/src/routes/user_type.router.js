import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlUserType from '../controllers/user_type.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', verifyToken, ctrlUserType.create);

router.put('/', verifyToken, ctrlUserType.update);

router.get('/all', verifyToken, ctrlUserType.findAll);

router.get('/:id', verifyToken, ctrlUserType.findById);

router.delete('/:id', verifyToken, ctrlUserType.deleteOne);

export default router;