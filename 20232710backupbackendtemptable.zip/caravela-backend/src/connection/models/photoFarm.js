'use strict'
import sequelizePaginate from 'sequelize-paginate'
module.exports = (sequelize, DataTypes) => {
  const photoFarm = sequelize.define('photoFarm', {
    uuid: DataTypes.STRING,
    unique_id: DataTypes.STRING,
    photo: DataTypes.STRING,
    farm_id: DataTypes.INTEGER,
    state_id: DataTypes.INTEGER,
    deleteAt: DataTypes.DATE,
    date: DataTypes.DATE
  })

  photoFarm.associate = function (models) {
    photoFarm.belongsTo(models.farm, {
      foreignKey: { name: 'farm_id', allowNull: false }
    })

    // photoFarm.belongsTo(models.state, {
    //   foreignKey: { name: 'state_id', allowNull: false }
    // })
  }
  sequelizePaginate.paginate(photoFarm)
  return photoFarm
}
