'use strict';
module.exports = (sequelize, DataTypes) => {
    const QuestionnaireQuestion = sequelize.define('QuestionnaireQuestion', {
        order: DataTypes.INTEGER,
        version: DataTypes.INTEGER,
        required: DataTypes.BOOLEAN,
        date: DataTypes.BOOLEAN,
        time: DataTypes.BOOLEAN,
        pdf: DataTypes.BOOLEAN,
        png: DataTypes.BOOLEAN,
        min: DataTypes.INTEGER,
        max: DataTypes.INTEGER,
        jpg: DataTypes.BOOLEAN,
        doc: DataTypes.BOOLEAN,
        excel: DataTypes.BOOLEAN,
        description: DataTypes.STRING,
        unique_id: DataTypes.STRING,
        iddispositivo: DataTypes.STRING,
        delete_user_id: DataTypes.INTEGER,
        survey_id: DataTypes.INTEGER,
        type_question_id: DataTypes.INTEGER,
        delete_at: DataTypes.DATE,
        condicionation: DataTypes.BOOLEAN,
        observation: DataTypes.STRING,
        descriptionPhotos: DataTypes.STRING,
        entrytext: DataTypes.BOOLEAN,
        order_section: DataTypes.INTEGER,
        section: DataTypes.STRING,
        id_condicionation: DataTypes.STRING,
        id_option_condicionation: DataTypes.INTEGER,
        state_id: DataTypes.INTEGER,
        categoryId: DataTypes.INTEGER,
        operationText: DataTypes.STRING,
        id_category_condicionation: DataTypes.STRING,

      },
      {
        /*freezeTableName: true,
        name: {
          singular: "QuestionnaireQuestion",
          plural: "QuestionnaireQuestion",
        },*/
      }
    )
    QuestionnaireQuestion.associate = function (models) {
      // associations can be defined here
      this.belongsTo(models.questionnaire_category, {
        foreignKey: { name: "categoryId", allowNull: true }
      })
      QuestionnaireQuestion.belongsTo(models.questionnaire, {
        foreignKey: { name: "survey_id", allowNull: false },
      })
  
      QuestionnaireQuestion.hasMany(models.QuestionnaireQuestionOption, {
        foreignKey: { name: "question_id", allowNull: false },
      })
  
      QuestionnaireQuestion.hasMany(models.questionnaire_answer_body, {
        foreignKey: { name: "id_question", allowNull: false },
      })
      QuestionnaireQuestion.hasMany(models.questionnaireQuestionsAssociate, {
        as: 'QuestionA',
        foreignKey: { name: "id_question", allowNull: true },
      })
      QuestionnaireQuestion.hasMany(models.questionnaireQuestionsAssociate, {
        as: 'QuestionC',
        foreignKey: { name: "id_question_create", allowNull: false },
      })
    };
    return QuestionnaireQuestion;
};