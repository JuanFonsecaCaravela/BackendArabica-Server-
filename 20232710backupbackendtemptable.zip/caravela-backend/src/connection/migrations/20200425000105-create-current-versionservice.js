'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('current_versionservices', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      id_user: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },
      uuid_phone: {
        type: Sequelize.STRING,
      },
      current_version: {
        type: Sequelize.INTEGER
      },
      version_in_app: {
        type: Sequelize.INTEGER
      },
      type_service_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "typeServices",
          key: "id"
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    },{
      indexes: [
          {
              unique: true,
              fields: ['uuid_phone', 'id_usercount', 'type_service_id']
          }
      ]
  });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('current_versionservices');
  }
};