'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('answer_surveys', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      unique_id: {
        type: Sequelize.STRING(100),
        allowNull: false
      },      
      producer: {
        type: Sequelize.STRING,
        allowNull: true,
      },   
      version: {
        type: Sequelize.INTEGER
      },   
      farm: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      plot: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      id_survey: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "survey",
          key: "id"
        }
      },   
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('answer_surveys');
  }
};