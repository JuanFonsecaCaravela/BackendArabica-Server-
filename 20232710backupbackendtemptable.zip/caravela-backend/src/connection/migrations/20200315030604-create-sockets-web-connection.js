"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("SocketsWebConnections", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      unique_id: {
        type: Sequelize.STRING
      },
      status: {
        type: Sequelize.INTEGER // 1- Abierto, 2- Cerrado
      },
      message_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "MessageHeads",
          key: "id"
        }
      },
      producer_ws_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "SocketsWebs",
          key: "id"
        }
      },
      technical_ws_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "SocketsWebs",
          key: "id"
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("SocketsWebConnections");
  }
};
