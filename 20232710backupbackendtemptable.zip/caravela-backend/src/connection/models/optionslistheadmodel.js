'use strict';
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const OptionsListHeadModel = sequelize.define('OptionsListHeadModel', {
    unique_id: DataTypes.STRING,
    description: DataTypes.STRING,
    id_tenant:DataTypes.INTEGER,
  }, {});
  OptionsListHeadModel.associate = function(models) {
    OptionsListHeadModel.hasMany(models.OptionsListBodyModel, { 
      foreignKey: { name: 'id_head', allowNull: false }
     }); 
  };
  sequelizePaginate.paginate(OptionsListHeadModel);
  return OptionsListHeadModel;
};