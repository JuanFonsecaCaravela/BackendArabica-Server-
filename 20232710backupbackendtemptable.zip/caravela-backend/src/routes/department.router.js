import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlDepartment from '../controllers/department.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlDepartment.create);

router.put('/', verifyToken, ctrlDepartment.update);

router.post('/all', ctrlDepartment.findAll);

router.get('/:id', verifyToken, ctrlDepartment.findById);

router.get('/country/:id', ctrlDepartment.findByCountryId);

router.delete('/:id', verifyToken, ctrlDepartment.deleteOne);

export default router;