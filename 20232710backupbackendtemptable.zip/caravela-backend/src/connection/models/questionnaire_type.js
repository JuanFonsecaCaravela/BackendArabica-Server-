'use strict';
import sequelizePaginate from "sequelize-paginate"
import capitalize from 'capitalize'
module.exports = (sequelize, DataTypes) => {
    const questionnaire_type = sequelize.define('questionnaire_type', {
        survey_type_id: DataTypes.STRING,
        name: {
            type: DataTypes.STRING,
            set(value) {
                this.setDataValue('name', value.toLowerCase())
            },
            get() {
                const name = this.getDataValue('name')
                return capitalize.words(name)
            },
        },
        state_id: DataTypes.INTEGER,
        deleteAt: DataTypes.DATE
    }, {
        /*freezeTableName: true,
        name: {
            singular: "questionnaire_type",
            plural: "questionnaire_type"
        }*/
    }
)
questionnaire_type.associate = function(models) {
    questionnaire_type.hasMany(models.questionnaire, {
        foreignKey: {
            name: "survey_type_id",
            allowNull: true
        },
    })
    };
    sequelizePaginate.paginate(questionnaire_type);
    return questionnaire_type;
};