import express from "express";
import jwtService from "../services/jwt.service";
import ctrlFarm from "../controllers/farm.controller";

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post("/", verifyToken, ctrlFarm.create);

router.post("/images", verifyToken, ctrlFarm.uploadImages);

router.post("/delete-image", verifyToken, ctrlFarm.deleteImage);
router.delete("/imgDel/:id/:id_farm", verifyToken, ctrlFarm.deleteImg);

router.post("/save-farms", verifyToken, ctrlFarm.saveFarms);
router.post(
  "/save-farmdryingmethods",
  verifyToken,
  ctrlFarm.saveFarmsDryingmethods
);
router.post(
  "/save-farmfermentationtypes",
  verifyToken,
  ctrlFarm.saveFarmsFermentationtype
);
router.post(
  "/save-farmprocesstypes",
  verifyToken,
  ctrlFarm.saveFarmsProcesstypes
);
router.post(
  "/save-farmflycropperiods",
  verifyToken,
  ctrlFarm.saveFarmFlycropPeriods
);
router.post(
  "/save-farmharvestperiods",
  verifyToken,
  ctrlFarm.saveFarmHarvestPeriods
);

router.post(
  "/save-farmcertifications",
  verifyToken,
  ctrlFarm.saveFarmsCertifications
);

router.put("/", verifyToken, ctrlFarm.update);

router.get("/all", verifyToken, ctrlFarm.findAll);

router.get("/:id", verifyToken, ctrlFarm.findById);
router.get("/find_farm/:id", verifyToken, ctrlFarm.findByIdFarm);

router.get("/producer-id/:id", verifyToken, ctrlFarm.findByUserId);

router.delete("/:id", verifyToken, ctrlFarm.deleteOne);

router.post("/save-photofarm", verifyToken, ctrlFarm.createPhotoFarm);
router.delete("/remove/:id", verifyToken, ctrlFarm.Remove);
router.put("/photofarm/", verifyToken, ctrlFarm.updatePhotoFarm);



export default router;
