'use strict';
module.exports = (sequelize, DataTypes) => {
    const questionnaire_category = sequelize.define('questionnaire_category', {
        name: DataTypes.STRING,
        uuid: DataTypes.STRING,
        description: DataTypes.STRING,
        order: DataTypes.INTEGER,
        version: DataTypes.INTEGER,
        surveyId: DataTypes.INTEGER,
        id_category: DataTypes.STRING,
        id_condicionation: DataTypes.STRING,
        id_option_condicionation: DataTypes.STRING,
        condicionation: DataTypes.BOOLEAN
      },
      {}
    )
    questionnaire_category.associate = function (models) {
      questionnaire_category.belongsTo(models.questionnaire, {
        foreignKey: { name: 'surveyId', allowNull: true }
      })
      questionnaire_category.hasMany(models.QuestionnaireQuestion, {
        foreignKey: { name: 'categoryId', allowNull: true }
      })
    };
    return questionnaire_category;
};