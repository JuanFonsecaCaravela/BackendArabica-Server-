'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([

        queryInterface.addColumn('PlannerMasters','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('gender','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('fermentation_type','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),
        
        queryInterface.addColumn('dni_type','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('scholarship','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('process_type','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('relationship','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('visit_type','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('coffee_variety','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('drying_method','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('civil_status','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('renovation_type','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),

        queryInterface.addColumn('certification','i18n',{
          type: Sequelize.DataTypes.STRING(500),
          allowNull: true,
        },{ transaction: t }),


      ]);
    });
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};
