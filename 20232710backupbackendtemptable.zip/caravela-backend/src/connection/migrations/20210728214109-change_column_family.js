'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction(() => {
      return Promise.all([

        queryInterface.addColumn('family_member','typeDni_id',{
          type: Sequelize.DataTypes.INTEGER,
          allowNull: true,
          references: {
            model: "dni_type",
            key: "id"
          }
        },{}),

        queryInterface.addColumn('family_member','dni',{
          type: Sequelize.DataTypes.INTEGER,
          allowNull: true,
        },{}),
        

      ]);
    });
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};
