import express from 'express';
import jwtService from '../services/jwt.service';
import ctrl from '../controllers/agroferestry_type.controller';

const router = express.Router();
const verifyToken = jwtService.verifyToken;

router.get('/', verifyToken, ctrl.getAll);
router.post('/create', verifyToken, ctrl.create);
router.put('/update/:id', verifyToken, ctrl.update);
router.get('/:id', verifyToken, ctrl.findByUuid);
router.delete('/:id', verifyToken, ctrl.updateDelete);

export default router;