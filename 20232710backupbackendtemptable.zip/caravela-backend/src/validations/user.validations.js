const { body } = require("express-validator/check")

const changePasswordUser = () => {
  return [
    body("oldPassword")
      .exists()
      .withMessage("oldPassword doesn't exists")
      .not()
      .isEmpty()
      .withMessage("oldPassword isEmpty")
      .isLength({ min: 3 })
      .withMessage("oldPassword must have more than 6 characters"),
    body("newPassword")
      .exists()
      .withMessage("newPassword doesn't exists")
      .not()
      .isEmpty()
      .withMessage("newPassword isEmpty")
      .isLength({ min: 6 })
      .withMessage("newPassword must have more than 6 characters"),
    body("newPasswordRepeat")
      .exists()
      .withMessage("newPasswordRepeat doesn't exists")
      .not()
      .isEmpty()
      .withMessage("newPasswordRepeat isEmpty")
      .isLength({ min: 6 })
      .withMessage("newPasswordRepeat must have more than 6 characters")
  ]
}

const searchUserDNIValidation = () => {
  return [
    body("dni")
      .exists()
      .withMessage("dni doesn't exists")
      .not()
      .isEmpty()
      .withMessage("dni isEmpty"),
    body("type_dni_id")
      .exists()
      .withMessage("type_dni_id doesn't exists")
      .not()
      .isEmpty()
      .withMessage("type_dni_id isEmpty"),
    body("country_id")
      .exists()
      .withMessage("country_id doesn't exists")
      .not()
      .isEmpty()
      .withMessage("country_id isEmpty"),
    body("role_id")
      .exists()
      .withMessage("role_id doesn't exists")
      .not()
      .isEmpty()
      .withMessage("role_id isEmpty")
  ]
}

const recoveryPasswordEmail = () => {
  return [
    body("email")
      .exists()
      .withMessage("email doesn't exists")
      .not()
      .isEmpty()
      .withMessage("email isEmpty")
      .isEmail()
      .withMessage("No es un tipo de correo"),
    body("dni")
      .exists()
      .withMessage("dni doesn't exists")
      .not()
      .isEmpty()
      .withMessage("dni isEmpty"),
    body("role_id")
      .exists()
      .withMessage("role_id doesn't exists")
      .not()
      .isEmpty()
      .withMessage("role_id isEmpty")
  ]
}

const RecoveryPasswordValidation = () =>{
  return[   
    body("password")      
      .not()
      .isEmpty()
      .withMessage("newPassword isEmpty")
      .isLength({ min: 8 })
      .withMessage("newPassword must have more than 8 characters")      
      // .matches(/^[a-zA-Z][\w\s-]+/)
      // .matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/, "i")
      .matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/, "i")
      .withMessage("newPassword must have one captital, small letter and one digit.")
  ]
}

/*
body("email", "Invalid email")
      .exists()
      .isEmail(),
    body("phone")
      .optional()
      .isInt(),
    body("status")
      .optional()
      .isIn(["enabled", "disabled"])
      */

export default { changePasswordUser, searchUserDNIValidation, recoveryPasswordEmail, RecoveryPasswordValidation }
