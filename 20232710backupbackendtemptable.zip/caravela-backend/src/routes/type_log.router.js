import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlTypeLog from '../controllers/type_log.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlTypeLog.create);

router.put('/', verifyToken, ctrlTypeLog.update);

router.post('/all', verifyToken, ctrlTypeLog.findAll);

router.get('/:id', verifyToken, ctrlTypeLog.findById);

router.delete('/:id', verifyToken, ctrlTypeLog.deleteOne);

export default router;