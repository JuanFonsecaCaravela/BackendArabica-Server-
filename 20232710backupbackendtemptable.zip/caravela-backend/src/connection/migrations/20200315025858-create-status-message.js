"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("StatusMessages", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      unique_id: {
        type: Sequelize.STRING
      },
      description: {
        type: Sequelize.STRING(30),
        allowNull: false,
        get: function() {
          return this.getDataValue("description");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("description", capitalize.words(value));
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("StatusMessages");
  }
};
