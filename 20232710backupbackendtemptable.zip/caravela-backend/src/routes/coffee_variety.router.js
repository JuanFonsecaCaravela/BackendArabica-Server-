import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlCoffeeVariety from '../controllers/coffee_variety.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlCoffeeVariety.create);

router.put('/', verifyToken, ctrlCoffeeVariety.update);

router.post('/all', verifyToken, ctrlCoffeeVariety.findAll);

router.get('/:id', verifyToken, ctrlCoffeeVariety.findById);

router.delete('/:id', verifyToken, ctrlCoffeeVariety.deleteOne);

export default router;