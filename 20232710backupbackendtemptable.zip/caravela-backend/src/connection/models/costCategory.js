'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const costCategory = sequelize.define (
    'costCategory',
    {
      description: DataTypes.STRING,
      uuid: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      orderBy :DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: 'costCategory',
        plural: 'costCategory',
      },
    }
  );

  costCategory.associate = function (models) {
    costCategory.hasMany (models.cost_Body, {
      foreignKey: {name: 'id_costCategory', allowNull: false},
  
    });
  };
  sequelizePaginate.paginate (costCategory);
  return costCategory;
};
