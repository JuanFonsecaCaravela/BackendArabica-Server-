"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("department", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      department_id: {
        type: Sequelize.STRING(255)
      },
      country_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "country",
          key: "id"
        }
      },
      spanish_name: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("spanish_name");
        },
        set: function(value) {
          this.setDataValue("spanish_name", capitalize.words(value));
        }
      },
      department_code: {
        type: Sequelize.STRING(10),
        defaultValue: "NA"
      },
      area_code: {
        type: Sequelize.STRING(5),
        defaultValue: "NA"
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("department");
  }
};
