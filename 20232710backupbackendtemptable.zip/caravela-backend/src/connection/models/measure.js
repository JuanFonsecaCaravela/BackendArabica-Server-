"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const measure = sequelize.define(
    "measure",
    {
      description: DataTypes.STRING,
      uuid: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      value: DataTypes.STRING,
    },
    {
      freezeTableName: true,
      name: {
        singular: "measure",
        plural: "measure"
      }
    }
  );

  measure.associate = function (models) {


  };
  sequelizePaginate.paginate(measure);
  return measure;
};


