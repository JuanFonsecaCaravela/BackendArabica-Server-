'use strict';
import sequelizePaginate from 'sequelize-paginate';

module.exports = (sequelize, DataTypes) => {
  const Role = sequelize.define('Role', {
    description: DataTypes.STRING,
    unique_id: DataTypes.STRING
  }, {});
  Role.associate = function(models) {
    // associations can be defined here
    // Role.hasMany(models.UserModel, {
    //   foreignKey: { name: "enterprise_job_id", allowNull: false }
    // });

    Role.belongsToMany(models.PermissionModel, {
      through: models.RolePermissionModel,
      foreignKey: "id_role",
    });

  };
  sequelizePaginate.paginate(Role);
  return Role;
};