"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const elearning_Task = sequelize.define(
    "elearning_Task",
    {
      elearning_Task_id: DataTypes.STRING,
      title: DataTypes.STRING,
      id_elearning_Task_type: DataTypes.INTEGER,
      id_elearning_Body: DataTypes.INTEGER,
      description: DataTypes.STRING,
      createdAt: DataTypes.DATE,
      state_id: DataTypes.INTEGER,
      version: DataTypes.STRING,
    },
    {
      freezeTableName: true,
      name: {
        singular: "elearning_Task",
        plural: "elearning_Task"
      }
    }
  );

  elearning_Task.associate = function (models) {

    elearning_Task.belongsTo(models.elearning_Body, {
      foreignKey: { name: "id_elearning_Body", allowNull: true }
    });
    elearning_Task.belongsTo(models.elearning_Task_Type, {
      foreignKey: { name: "id_elearning_Task_type", allowNull: true }
    });
  };
  sequelizePaginate.paginate(elearning_Task);
  return elearning_Task;
};
