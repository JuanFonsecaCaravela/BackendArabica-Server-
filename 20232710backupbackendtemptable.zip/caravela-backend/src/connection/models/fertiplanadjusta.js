'use strict';
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const fertiPlanAdjusta = sequelize.define('fertiPlanAdjusta', {
    fertiPlanAdjusta_id: DataTypes.STRING,
    ano: DataTypes.INTEGER,
    isDeleted:DataTypes.BOOLEAN,
    isDeletedDate:DataTypes.STRING,
    version:DataTypes.INTEGER
  }, {});
  fertiPlanAdjusta.associate = function(models) {
    fertiPlanAdjusta.hasMany(models.fertiPlanAdjustaCountry,{
      foreignKey: { name: "fertiPlanCountryRef_id", allowNull: false },
      onDelete: "CASCADE",
    });
    fertiPlanAdjusta.hasMany(models.fertiPlanAdjustaFertilizer,{
      foreignKey: { name: "fertiPlanRef_id", allowNull: false },
      onDelete: "CASCADE",
    })
    
  };
  sequelizePaginate.paginate(fertiPlanAdjusta);
  return fertiPlanAdjusta;
};