"use strict";

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("elearning_Head", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      elearning_Head_id: {
        type: Sequelize.STRING(255),
      },
      title: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },
      category: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },

      trainingCycle: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },

      consecutiveCourse: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },

      TypeCourse: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },

      nameWhoOffers: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },

      accessLink: {
        type: Sequelize.STRING(255),
        defaultValue: "NA",

      },

      courseValidity: {
        type: Sequelize.DATE


      },

      modality: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },

      Hourlyintensity: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },


      maximumQuota: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },


      numberStars: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },

      strengthenKnowledge: {
        type: Sequelize.STRING(255),
        defaultValue: "NA",

      },
      description: {
        type: Sequelize.STRING(500),
        defaultValue: "NA",

      },
      loadFile: {
        type: Sequelize.STRING(500),
        defaultValue: "NA",

      },

      userCreate: {
        type: Sequelize.INTEGER,

        references: {
          model: "caravela_user",
          key: "id"
        }
      },

      version: {
        type: Sequelize.STRING,
        defaultValue: "NA",
      },

      state_id: {
        type: Sequelize.INTEGER, 
        references: {
          model: 'state',
          key: 'id'
        }
      },
      deleteAt: {
        allowNull: true,
        type: Sequelize.DATE
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("elearning_Head");
  }
};
