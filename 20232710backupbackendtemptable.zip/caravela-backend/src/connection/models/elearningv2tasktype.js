'use strict';
module.exports = (sequelize, DataTypes) => {
  const elearningv2TaskType = sequelize.define('elearningv2TaskType', {
    typesResponses: DataTypes.STRING,
  //  id_elearningv2_Task_type:  DataTypes.STRING,
  }, {});
  elearningv2TaskType.associate = function(models) {
    // associations can be defined here
  };
  return elearningv2TaskType;
};