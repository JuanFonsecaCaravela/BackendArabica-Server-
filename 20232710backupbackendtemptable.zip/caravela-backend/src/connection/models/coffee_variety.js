'use strict';
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const coffee_variety = sequelize.define('coffee_variety', {
    coffee_variety_id: DataTypes.STRING,
    spanish_name: DataTypes.STRING,
    i18n: DataTypes.STRING,
    state_id: DataTypes.INTEGER,
    deleteAt: DataTypes.DATE,
    id_tenant:DataTypes.INTEGER,
  },
  {
    freezeTableName: true,
    name: {
      singular: "coffee_variety",
      plural: "coffee_variety"
    }
  }
);

  coffee_variety.associate = function(models) {
    coffee_variety.hasMany(models.plot, {
      foreignKey: { name: "coffee_variety_id", allowNull: false }
    });
  };
  sequelizePaginate.paginate(coffee_variety);
  return coffee_variety;
};