import express from "express";
import jwtService from "../services/jwt.service";
import ctrlPermission from "../controllers/permission.controller";

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post("/", [verifyToken], ctrlPermission.createPermission);
router.get("/get-all", [verifyToken], ctrlPermission.getAllPermission);

export default router;
