if (process.env.NODE_ENV !== "production") {
    require('dotenv').config()
}
const accountSid = process.env.TWILIO_ACCOUNT_SID
const authToken = process.env.TWILIO_AUTH_TOKEN
const client = require('twilio')(accountSid, authToken)
import db from '../connection/models/index'


const senMessage = async (message, to, user) => {
    try {
        
        let Rest = await client.messages
            .create({
                body: message,
                from: process.env.TWILIO_NUMBER_PHONE,
                to
            })
        console.log({Rest})
        await saveDataTwilio(Rest, user)
    } catch (error) {
        await saveDataTwilio({
            from: process.env.TWILIO_NUMBER_PHONE,
            to: to,
            status: 400,
            sid: '',
            body: message,
            error_code: 'unknown',
            error_message: JSON.stringify(error)
        }, user)
    }
}
const senMessageWP = async (message, to, user) => {
    try {
        console.log("SEND MESSAGE WHAST: " , {message, to, user})
        let Rest = await client.messages
            .create({
                from: `whatsapp:${process.env.TWILIO_NUMBER_PHONE}`,
                body: message, // "Estimado Michael Valencia, su lote 1 de prueba ha sido cancelado. CARAVELA.",
                to: `whatsapp:${to}`
            })
        await saveDataTwilio(Rest, user)
        console.log({Rest})
    } catch (error) {
        console.log({error})
        await saveDataTwilio({
            from: process.env.TWILIO_NUMBER_PHONE,
            to: to,
            status: 400,
            sid: '',
            body: message,
            error_code: 'unknown',
            error_message: JSON.stringify(error)
        }, user)
    }

}
const saveDataTwilio = async (data, user_id) => {
    try {
        await db.twilioResponse.create({
            from: data.from,
            to: data.to,
            status: data.status,
            sid: data.sid,
            body: data.body,
            error_code: data.error_code,
            error_message: data.error_message,
            user_id
        })
    } catch (error) {
        console.log('Hubo un error insertando la respuesta', error)
    }
}

export default {
    senMessage,
    senMessageWP
}