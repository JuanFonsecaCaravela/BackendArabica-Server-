"use strict";
module.exports = (sequelize, DataTypes) => {
  const emailNotification = sequelize.define(
    "emailNotification",
    {
      message: DataTypes.STRING,
      state: DataTypes.STRING,
      emailSend: DataTypes.STRING,
      title: DataTypes.STRING,
      type: DataTypes.INTEGER,
      idElement: DataTypes.INTEGER,
    },
    {}
  );
  emailNotification.associate = function (models) {
    // associations can be defined here
  };
  return emailNotification;
};
