'use strict';
module.exports = (sequelize, DataTypes) => {
  const plot_share_tree = sequelize.define('plot_share_tree', {
    plot_id: DataTypes.INTEGER,
    tree_name: DataTypes.STRING,
    quantity: DataTypes.STRING,
    unique_id: DataTypes.STRING,
    deleteAt: DataTypes.DATE
  }, {});
  plot_share_tree.associate = function(models) {
    plot_share_tree.belongsTo(models.plot , {
      foreignKey: { name: "plot_id", allowNull: false }
    });
  };
  return plot_share_tree;
};