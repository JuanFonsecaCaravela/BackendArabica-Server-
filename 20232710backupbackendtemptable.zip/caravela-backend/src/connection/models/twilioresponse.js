'use strict'
module.exports = (sequelize, DataTypes) => {
  const twilioResponse = sequelize.define('twilioResponse', {
    from: DataTypes.STRING,
    to: DataTypes.STRING,
    status: DataTypes.STRING,
    sid: DataTypes.STRING,
    body: DataTypes.STRING,
    error_code: DataTypes.STRING,
    error_message: DataTypes.STRING,
    user_id: DataTypes.INTEGER
  }, {})
  twilioResponse.associate = function (models) {
    this.belongsTo(models.caravela_user, {
      foreignKey: { name: "user_id", allowNull: false }
    })
  }
  return twilioResponse
}