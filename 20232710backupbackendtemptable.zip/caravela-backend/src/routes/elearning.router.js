import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlElearning from '../controllers/elearning.controller';

const router = express.Router();
// head
const verifyToken = jwtService.verifyToken;

router.post('/', verifyToken, ctrlElearning.create);

router.put('/', verifyToken, ctrlElearning.update);

router.post('/all', verifyToken, ctrlElearning.findAll);

router.get('/:id', verifyToken, ctrlElearning.findById);

router.delete('/:id', verifyToken, ctrlElearning.deleteOne);

//body
router.post('/Section/', verifyToken, ctrlElearning.createSection);

router.put('/Section/', verifyToken, ctrlElearning.updateSection);

router.post('/Section/all', verifyToken, ctrlElearning.findAllSection);

router.get('/Section/:id', verifyToken, ctrlElearning.findByIdSection);

router.delete('/Section/:id', verifyToken, ctrlElearning.deleteOneSection);

//task
router.post('/Task/', verifyToken, ctrlElearning.createTask);

router.put('/Task/', verifyToken, ctrlElearning.updateTask);

router.post('/Task/all', verifyToken, ctrlElearning.findAllTask);

router.get('/Task/:id', verifyToken, ctrlElearning.findByIdTask);

router.delete('/Task/:id', verifyToken, ctrlElearning.deleteOneTask);

export default router;