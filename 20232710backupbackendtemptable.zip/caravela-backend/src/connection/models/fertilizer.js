'use strict';
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const Fertilizer = sequelize.define('Fertilizer', {
    fertilizer_id: DataTypes.STRING,
    fertilizerName: DataTypes.STRING,
    isDeleted:DataTypes.BOOLEAN,
    isDeletedDate:DataTypes.STRING,
    version:DataTypes.INTEGER
  }, {});
  Fertilizer.associate = function(models) {
    Fertilizer.hasMany(models.NutriPercent,{
      foreignKey: { name: "nutriPercent", allowNull: false},
      onDelete: "CASCADE",
    })
  };
  sequelizePaginate.paginate(Fertilizer);
  return Fertilizer;
};