'use strict';
import sequelizePaginate from "sequelize-paginate"

module.exports = (sequelize, DataTypes) => {
    const questionnaire_answer = sequelize.define('questionnaire_answer', {
        unique_id: DataTypes.STRING,
        producer: DataTypes.STRING,
        version: DataTypes.INTEGER,
        farm: DataTypes.STRING,
        plot: DataTypes.STRING,
        location: DataTypes.STRING,
        date: DataTypes.STRING,
        id_survey: DataTypes.INTEGER,
        id_producer: DataTypes.INTEGER,
        id_technician: DataTypes.INTEGER,
        creatorRoleType: DataTypes.STRING
      },
      {}
    )
    questionnaire_answer.associate = function (models) {
      // associations can be defined here
      questionnaire_answer.belongsTo(models.questionnaire, {
        foreignKey: { name: "id_survey", allowNull: false },
      })
      questionnaire_answer.hasMany(models.questionnaire_answer_body, {
        foreignKey: { name: "id_answer", allowNull: false },
      })
  
      questionnaire_answer.belongsTo(models.caravela_user, {
        as: 'Producer',
        foreignKey: { name: "id_producer", allowNull: false },
      })
  
      questionnaire_answer.belongsTo(models.caravela_user, {
        as: 'Technician',
        foreignKey: { name: "id_technician", allowNull: false },
      })
    };
    sequelizePaginate.paginate(questionnaire_answer)

    return questionnaire_answer;
};