'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('plot_share_trees', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      plot_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "plot",
          key: "id"
        }
      },
      tree_name: {
        type: Sequelize.STRING
      },
      quantity: {
        type: Sequelize.STRING
      },
      unique_id: {
        type: Sequelize.STRING,
        allowNull: false,
        unique:true
      },
      deleteAt: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('plot_share_trees');
  }
};