import nodemailer from 'nodemailer'
import db from "../connection/models/index"

const sendEmail = async (data) => {
  // Generate test SMTP service account from ethereal.email
  // Only needed if you don't have a real mail account for testing
  let testAccount = await nodemailer.createTestAccount()
  let ConfigurationEmail = await db.Configuration.findOne({
    attributes: ['valueText'],
    where: {
      name: 'email'
    }
  })
  let ConfigurationPass = await db.Configuration.findOne({
    attributes: ['valueText'],
    where: {
      name: 'password'
    }
  })
  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: "smtp.office365.com",
    port: 587,
    secure: false,
    requireTLS: true,
    secureConnection: false,
    // debug: true,
    // logger:true,
    tls: {
      ciphers: 'SSLv3'
    },
    // secure: true, // true for 465, false for other ports
    auth: {
      user: ConfigurationEmail.valueText, // generated ethereal user
      pass: ConfigurationPass.valueText // generated ethereal password
    }
  })

  // send mail with defined transport object
  let info = await transporter.sendMail({
    from: data.from, // sender address
    to: data.to, // list of receivers
    subject: data.subject, // Subject line
    html: data.html // html body
  })

  console.log("Message sent: %s", info.messageId)
  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
  return true
}

export default {
  sendEmail,
}