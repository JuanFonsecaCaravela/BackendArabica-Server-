'use strict';
module.exports = (sequelize, DataTypes) => {
  const LogAnswer = sequelize.define('LogAnswer', {
    id_answer: DataTypes.INTEGER,
    type: DataTypes.INTEGER,
    data: DataTypes.STRING,
    context: DataTypes.STRING,
    user: DataTypes.INTEGER,
    producer: DataTypes.INTEGER
  }, {});
  LogAnswer.associate = function(models) {
    // associations can be defined here
  };
  return LogAnswer;
};