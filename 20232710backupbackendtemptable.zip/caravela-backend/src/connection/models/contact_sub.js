'use strict';
module.exports = (sequelize, DataTypes) => {
  const Contact_SubType = sequelize.define('Contact_SubType', {
    uuid: DataTypes.STRING,
    description_spanish: DataTypes.STRING,
    description_english: DataTypes.STRING,
    state_id: DataTypes.INTEGER
  }, {});
  Contact_SubType.associate = function(models) {
    // associations can be defined here
  };
  return Contact_SubType;
};