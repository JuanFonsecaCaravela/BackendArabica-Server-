"use strict";
module.exports = (sequelize, DataTypes) => {
  const farm_certification = sequelize.define(
    "farm_certification",
    {
      certification_dates: DataTypes.TEXT,
      farm_id: DataTypes.INTEGER,
      certification_id: DataTypes.INTEGER,
      unique_id : DataTypes.STRING,
      deleteAt: DataTypes.DATE,
      state_id: DataTypes.INTEGER
    },
    {
      freezeTableName: true,
      name: {
        singular: "farm_certification",
        plural: "farm_certification"
      }
    }
  );
  farm_certification.associate = function(models) {
    farm_certification.belongsTo(models.farm, {
      foreignKey: { name: "farm_id", allowNull: false }
    });
    farm_certification.belongsTo(models.certification, {
      foreignKey: { name: "certification_id", allowNull: false }
    });
  };
  return farm_certification;
};
