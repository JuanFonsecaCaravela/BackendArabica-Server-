import {
  BlobServiceClient,
  StorageSharedKeyCredential,
} from '@azure/storage-blob';
import fs from 'fs';
import azure from 'azure-storage';

const STORAGE_ACCOUNT_NAME = process.env.AZURE_STORAGE_ACCOUNT_NAME;
const ACCOUNT_ACCESS_KEY = process.env.AZURE_STORAGE_ACCOUNT_ACCESS_KEY;
const containerName = 'profile-pictures';
const sharedKeyCredential = new StorageSharedKeyCredential (
  STORAGE_ACCOUNT_NAME,
  ACCOUNT_ACCESS_KEY
);
const connString = `https://${STORAGE_ACCOUNT_NAME}.blob.core.windows.net`;

const blobServiceClient = new BlobServiceClient (
  connString,
  sharedKeyCredential
);

async function uploadLocalFile (filePath, fileName, size) {
  const containerClient = await blobServiceClient.getContainerClient (
    containerName
  );
  const blockBlobClient = containerClient.getBlockBlobClient (fileName);
  const buffer = fs.readFileSync (filePath);
  const uploadBlobResponse = await blockBlobClient.upload (buffer, size);
  if (!uploadBlobResponse) {
    return false;
  } else {
    return true;
  }
}

const getFilesizeInBytes = filename => {
  var stats = fs.statSync (filename);
  var fileSizeInBytes = stats['size'];
  return fileSizeInBytes;
};

const generateSasToken = (container, blobName) => {
  const connString = process.env.AZURE_STORAGE_CONNECTION_STRING;
  const blobService = azure.createBlobService (connString);

  const startDate = new Date ();
  startDate.setMinutes (startDate.getMinutes () - 5);
  const expiryDate = new Date (startDate);
  expiryDate.setFullYear (2100);

  const permissions =
    azure.BlobUtilities.SharedAccessPermissions.READ +
    azure.BlobUtilities.SharedAccessPermissions.LIST;
  const sharedAccessPolicy = {
    AccessPolicy: {
      Permissions: permissions,
      Start: startDate,
      Expiry: expiryDate,
    },
  };

  const sasToken = blobService.generateSharedAccessSignature (
    container,
    blobName,
    sharedAccessPolicy
  );
  return {
    token: sasToken,
    url: blobService.getUrl (container, blobName, sasToken, true),
  };
};

const DeleteFile = async fileName => {
  //AssertBlobContainer ();
  try {
    const containerClient = await blobServiceClient.getContainerClient (
      containerName
    );
    
    var blob = await containerClient.deleteBlob (fileName);
    console.log (blob);
    // await blob.DeleteIfExists ();
    return true;
  } catch (error) {
    console.log (error);
    return false;
  }
};

const listData = async container => {
  const containerClient = blobServiceClient.getContainerClient (containerName);

  let i = 1;
  let blobs = containerClient.listBlobsFlat ();
  for await (const blob of blobs) {
    console.log (`Blob ${i++}: ${blob.name}`);
  }
};

export default {
  listData,
  DeleteFile,
  uploadLocalFile,
  generateSasToken,
  getFilesizeInBytes,
};
