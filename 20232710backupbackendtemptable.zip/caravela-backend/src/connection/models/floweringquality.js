"use strict";
module.exports = (sequelize, DataTypes) => {
  const FloweringQuality = sequelize.define(
    "FloweringQuality",
    {
      description: DataTypes.STRING,
      unique_id: DataTypes.STRING
    },
    {}
  );
  FloweringQuality.associate = function(models) {
    FloweringQuality.hasMany(models.PlannerProgrammingHead, {
      foreignKey: { name: "flowering_qualities_id", allowNull: false }
    });
  };
  return FloweringQuality;
};
