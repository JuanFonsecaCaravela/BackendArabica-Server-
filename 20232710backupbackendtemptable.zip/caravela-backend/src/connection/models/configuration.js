'use strict'
module.exports = (sequelize, DataTypes) => {
  const Configuration = sequelize.define('Configuration', {
    uuid: DataTypes.STRING,
    name: DataTypes.STRING,
    value: DataTypes.BOOLEAN,
    valueText: DataTypes.STRING
  }, {})
  Configuration.associate = function (models) {
    // associations can be defined here
  }
  return Configuration
}