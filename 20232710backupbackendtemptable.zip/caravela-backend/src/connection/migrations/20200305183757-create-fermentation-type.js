"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("fermentation_type", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      fermentation_type_id: {
        type: Sequelize.STRING(255),
      },
      spanish_name: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("spanish_name");
        },
        set: function(value) {
          this.setDataValue("spanish_name", capitalize.words(value));
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("fermentation_type");
  }
};
