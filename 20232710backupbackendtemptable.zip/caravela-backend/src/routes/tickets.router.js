import express from "express"
import jwtService from "../services/jwt.service"
import ctrlTickets from "../controllers/tickets.controller"

const router = express.Router()

const verifyToken = jwtService.verifyToken
router.get("/get-messages/tikets/:id/:version/:uuid", verifyToken, ctrlTickets.getTiketsMessages)
router.get("/get-tickets-producer", verifyToken, ctrlTickets.getTiketsProducer)
router.get("/get-tickets-technical/:version/:uuid", verifyToken, ctrlTickets.getTiketsTechnicial)
router.get("/get-tickets-technicalWeb", ctrlTickets.getTiketsTechnicialWeb)
router.post("/get-tickets-producer-last", verifyToken, ctrlTickets.getTiketsProducerLast)
router.post("/get-tickets-technical-last", verifyToken, ctrlTickets.getTiketsTechnicialLast)
router.get("/get-tickets-producer-update-head/:version/:uuid", verifyToken, ctrlTickets.getTiketsProducerHeadUpdate)
router.post("/get-tickets-producer-all", verifyToken, ctrlTickets.getTiketsProducerAll)
router.get("/get-messages/tiketsproducer/:id/:version/:uuid", verifyToken, ctrlTickets.getTiketsMessagesProducer)
router.get("/get-messages/tiketsproducer/:uuid", verifyToken, ctrlTickets.getTiketsProducerById) 


export default router
