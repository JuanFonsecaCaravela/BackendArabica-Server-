"use strict";
module.exports = (sequelize, DataTypes) => {
  const question_type = sequelize.define(
    "question_type",
    {
      description: DataTypes.STRING,
      unique_id: DataTypes.STRING,
      delete_at: DataTypes.DATE
    },
    {
      freezeTableName: true,
      name: {
        singular: "question_type",
        plural: "question_type"
      }
    }
  );
  question_type.associate = function(models) {
    // associations can be defined here
  };
  return question_type;
};
