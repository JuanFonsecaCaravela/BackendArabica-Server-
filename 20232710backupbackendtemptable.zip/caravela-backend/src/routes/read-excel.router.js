import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlExcel from '../controllers/read-excel.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

//router.post('/load-excel-country',[verifyToken], ctrlExcel.loadCountry);
router.post('/load-excel-municipality',[verifyToken], ctrlExcel.loadMunicipality);
router.post('/load-excel-department',[verifyToken], ctrlExcel.loadDepartment); 


export default router;
