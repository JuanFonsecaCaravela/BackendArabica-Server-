import formidable from 'formidable';
import accents from 'remove-accents';

const parseRequest = (request) => {
    try {
        return new Promise((resolve, reject) => {
            // Se parsea la petición para obtener el body
            let form = new formidable.IncomingForm();
            form.parse(request, function (err, fields, files) {
                if (err) {
                    reject();
                    console.log('Hubo un error en multipart: ', err);
                    return new Error('Hubo un error en multipart');
                }
                let body = null;
                if (fields) {
                    body = fields;
                }
                let message = {
                    body,
                    files
                }
                resolve(message);
            });
        });
    } catch (error) {
        console.log('Hubo un error parseando request: ', error);
    }
}

const generateFileName = (fileName) => {
    let newFileName = '';
    let noAccents = accents.remove(fileName);
    let noSpaces = noAccents.replace(/\s/g, '');
    newFileName = noSpaces;
    return newFileName;
}

export default {
    parseRequest,
    generateFileName
}