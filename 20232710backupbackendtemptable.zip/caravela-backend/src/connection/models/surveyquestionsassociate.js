'use strict'
module.exports = (sequelize, DataTypes) => {
  const SurveyQuestionsAssociate = sequelize.define(
    'SurveyQuestionsAssociate',
    {
      id_question: DataTypes.INTEGER,
      id_question_create: DataTypes.INTEGER,
      operation_type: DataTypes.INTEGER,
      number_operation: DataTypes.STRING,
      operation: DataTypes.STRING,
      parenthesisL: DataTypes.BOOLEAN,
      parenthesisR: DataTypes.BOOLEAN,
      id_category: DataTypes.STRING,
      id_question_id_device: DataTypes.STRING
    },
    {}
  )
  SurveyQuestionsAssociate.associate = function (models) {
    SurveyQuestionsAssociate.belongsTo(models.question, {
      as: 'QuestionAssociate',
      foreignKey: { name: 'id_question', allowNull: true }
    })
    SurveyQuestionsAssociate.belongsTo(models.question, {
      as: 'QuestionCreate',
      foreignKey: { name: 'id_question_create', allowNull: false }
    })
  }
  return SurveyQuestionsAssociate
}
