'use strict'

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([
        queryInterface.addColumn(
          "categories",
          "id_category",
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "categories",
          "uuid",
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "categories",
          "id_condicionation",
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "categories",
          "id_option_condicionation",
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true, 
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "categories",
          "condicionation",
          {
            type: Sequelize.DataTypes.BOOLEAN,
            allowNull: true,
          },
          { transaction: t }
        ),
      ])
    })
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  }
}
