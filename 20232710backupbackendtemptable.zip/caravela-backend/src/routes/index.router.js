import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlIndex from '../controllers/index.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.get('/register-data', ctrlIndex.getRegisterData);

router.get('/general-data-to-store/:version/:uuid', ctrlIndex.getGeneralDataToStore);

router.get('/login-data/:version/:uuid', ctrlIndex.getLoginData);

router.get('/login-master-country/:country/:version/:uuid', ctrlIndex.getLoginDataCountry);

router.post('/producer-visit-data', verifyToken, ctrlIndex.getProducerVisitData);

router.get('/formulaCost/all/:version/:uuid/:userId', ctrlIndex.getFormulaCost);

export default router;