"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("farm_drying_method", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      farm_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "farm",
          key: "id"
        }
      },

      drying_method_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "drying_method",
          key: "id"
        }
      },
      drying_time: {
        type: Sequelize.INTEGER
      },
      unique_id: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("farm_drying_method");
  }
};
