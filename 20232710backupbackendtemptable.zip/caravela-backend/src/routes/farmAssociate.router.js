import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlFarmAssociate from '../controllers/farmAssociate.controller';
const router = express.Router();
const verifyToken = jwtService.verifyToken;

router.post("/", verifyToken, ctrlFarmAssociate.setCreate);
router.post("/app", verifyToken, ctrlFarmAssociate.setCreateAPP);

router.post("/params", verifyToken, ctrlFarmAssociate.getByParams);
router.get("/farm/:dni/:id", verifyToken, ctrlFarmAssociate.getFarmsAssociate);
router.post("/farm", verifyToken, ctrlFarmAssociate.getFindAllByUser);
router.post("/peca", ctrlFarmAssociate.getPecaFarms);
router.delete('/:id' , verifyToken , ctrlFarmAssociate.deleteAssociation );

export default router;