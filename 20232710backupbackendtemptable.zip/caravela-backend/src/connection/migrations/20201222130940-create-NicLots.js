'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable ('NicLots', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      unique_id: {
        type: Sequelize.STRING,
      },

      turned_dry_at: {
        type: Sequelize.DATE,
      },
      local_identifier: {
        type: Sequelize.STRING,
      },
      created_at: {
        type: Sequelize.DATE,
      },
      quality_code: {
        type: Sequelize.STRING,
      },
      grade: {
        type: Sequelize.INTEGER,
      },
      warehouse: {
        type: Sequelize.STRING,
      },
      country: {
        type: Sequelize.STRING,
      },
      department: {
        type: Sequelize.STRING,
      },
      municipality: {
        type: Sequelize.STRING,
      },
      price_accepted_at: {
        type: Sequelize.DATE,
      },
      producer_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'caravela_user',
          key: 'id',
        },
      },
      producer_name: {
        type: Sequelize.STRING,
      },
      total_weight: {
        type: Sequelize.STRING,
      },
      unit_purchase_price: {
        type: Sequelize.DECIMAL,
      },
      coffee_type: {
        type: Sequelize.STRING,
      },
      certificate: {
        type: Sequelize.STRING,
      },
      fermentation_type: {
        type: Sequelize.STRING,
      },
      variety: {
        type: Sequelize.STRING,
      },
      process_type: {
        type: Sequelize.STRING,
      },
      factor_14: {
        type: Sequelize.STRING,
      },
      factor_15: {
        type: Sequelize.STRING,
      },
      yield_14: {
        type: Sequelize.STRING,
      },
      yield_15: {
        type: Sequelize.STRING,
      },
      density: {
        type: Sequelize.STRING,
      },
      green: {
        type: Sequelize.STRING,
      },
      merma: {
        type: Sequelize.STRING,
      },
      sieve_0: {
        type: Sequelize.STRING,
      },
      sieve_12: {
        type: Sequelize.STRING,
      },
      sieve_14: {
        type: Sequelize.STRING,
      },
      sieve_15: {
        type: Sequelize.STRING,
      },
      group_1: {
        type: Sequelize.STRING,
      },
      group_2: {
        type: Sequelize.STRING,
      },
      broca: {
        type: Sequelize.STRING,
      },
      paloteo: {
        type: Sequelize.STRING,
      },
      ripio: {
        type: Sequelize.STRING,
      },
      guayabas: {
        type: Sequelize.STRING,
      },
      caracol: {
        type: Sequelize.STRING,
      },
      physical_analysis_observations: {
        type: Sequelize.STRING,
      },
      accepting_reason: {
        type: Sequelize.STRING,
      },
      farm_name: {
        type: Sequelize.STRING,
      },
      association: {
        type: Sequelize.STRING,
      },
      humidity_green: {
        type: Sequelize.STRING,
      },
      humidity_dry_parchment: {
        type: Sequelize.STRING,
      },
      water_activity: {
        type: Sequelize.STRING,
      },
      initial_weight: {
        type: Sequelize.STRING,
      },
      roasted_weight: {
        type: Sequelize.STRING,
      },
      time_roasting: {
        type: Sequelize.INTEGER,
      },
      time_to_first_crack: {
        type: Sequelize.INTEGER,
      },
      development: {
        type: Sequelize.STRING,
      },
      pppt: {
        type: Sequelize.STRING,
      },
      final_score: {
        type: Sequelize.DECIMAL,
      },
      descriptor_overall: {
        type: Sequelize.STRING,
      },
      descriptor_body: {
        type: Sequelize.STRING,
      },
      descriptor_roast: {
        type: Sequelize.STRING,
      },
      descriptor_flavours: {
        type: Sequelize.STRING,
      },
      alternatives: {
        type: Sequelize.STRING,
      },
      defects: {
        type: Sequelize.STRING,
      },
      sensorial_analysis_observation: {
        type: Sequelize.STRING,
      },
      sensorial_accepting_reason: {
        type: Sequelize.STRING,
      },

      deleteAt: {
        allowNull: true,
        type: Sequelize.DATE,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable ('NicLots');
  },
};
