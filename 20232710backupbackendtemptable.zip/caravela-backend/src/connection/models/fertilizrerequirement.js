'use strict';
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const fertilizreRequirement = sequelize.define('fertilizreRequirement', {
    addrequirement_id: DataTypes.STRING,
    tipo: DataTypes.STRING,
    coffeeAgeBegin: DataTypes.INTEGER,
    coffeeAgeEnd: DataTypes.INTEGER,
    NumberOfStemsBegin: DataTypes.INTEGER,
    NumberOfStemsEnd: DataTypes.INTEGER,
    PlantingDistBegin: DataTypes.INTEGER,
    PlantingDistEnd: DataTypes.INTEGER,
    isDeleted:DataTypes.BOOLEAN,
    isDeletedDate:DataTypes.STRING,
    version:DataTypes.INTEGER


  }, {});
  fertilizreRequirement.associate = function(models) {
    fertilizreRequirement.hasMany(models.fertilizreRequirementOption,{
      foreignKey: { name: "fertilizreRequirement_id", allowNull: false },
      onDelete: "CASCADE",
    });
    fertilizreRequirement.hasMany(models.fertilizreRequirementCountry,{
      foreignKey: { name: "fertilizreRequirement_id", allowNull: false },
      onDelete: "CASCADE",
    });
  };
  sequelizePaginate.paginate(fertilizreRequirement);
  return fertilizreRequirement;
};