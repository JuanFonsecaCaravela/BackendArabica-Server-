import express from "express";
import jwtService from "../services/jwt.service";
import ctrlMeasure from "../controllers/measure.controller";

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post("/", [verifyToken], ctrlMeasure.createMeasure);
router.get("/:id", [verifyToken], ctrlMeasure.getMeasureByUUID);
router.get("/all/measure", [verifyToken], ctrlMeasure.getAllMeasures);
router.put("/", [verifyToken], ctrlMeasure.updateMeasure);

export default router;
