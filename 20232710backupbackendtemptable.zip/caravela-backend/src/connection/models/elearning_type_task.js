"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const elearning_Task_Type = sequelize.define(
    "elearning_Task_Type",
    {
      typesResponses: DataTypes.STRING,
    
    },
    {
      freezeTableName: true,
      name: {
        singular: "elearning_Task_Type",
        plural: "elearning_Task_Type"
      }
    }
  );

  elearning_Task_Type.associate = function(models) {
    
 
  };
  sequelizePaginate.paginate(elearning_Task_Type);
  return elearning_Task_Type;
};
