import express from 'express'
import jwtService from '../services/jwt.service'
import ctrlQuestionnaireType from '../controllers/questionnaire_type.controller'

const router = express.Router()

const verifyToken = jwtService.verifyToken

router.post('/', ctrlQuestionnaireType.create)

router.put('/', verifyToken, ctrlQuestionnaireType.update)

router.post('/all', verifyToken, ctrlQuestionnaireType.findAll)

router.get('/:id', verifyToken, ctrlQuestionnaireType.findById)

router.delete('/:id', verifyToken, ctrlQuestionnaireType.deleteOne)

export default router