'use strict';
module.exports = (sequelize, DataTypes) => {
  const wareHouseCountry = sequelize.define('wareHouseCountry', {
    country_id: DataTypes.INTEGER,
    wareHouseCountry_id: DataTypes.INTEGER
  }, {});
  wareHouseCountry.associate = function(models) {
    // associations can be defined here
    wareHouseCountry.belongsTo(models.wareHouseDepartment,{
      foreignKey: { name: "wareHouseCountry_id", allowNull: false },
      onDelete: "CASCADE",
    })
  };
  return wareHouseCountry;
};