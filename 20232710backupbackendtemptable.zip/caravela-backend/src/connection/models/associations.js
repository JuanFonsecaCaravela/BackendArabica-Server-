'use strict';
import sequelizePaginate from "sequelize-paginate"
module.exports = (sequelize, DataTypes) => {
  const associations = sequelize.define('associations', {
    nit: DataTypes.STRING,
    name: DataTypes.STRING,
    country_id: DataTypes.INTEGER
  }, {});
  associations.associate = function(models) {
    // associations can be defined here
  };
  sequelizePaginate.paginate(associations)
  return associations;
};