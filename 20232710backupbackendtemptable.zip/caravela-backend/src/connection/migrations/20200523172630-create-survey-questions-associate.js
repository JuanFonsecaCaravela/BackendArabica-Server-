"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("SurveyQuestionsAssociates", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      id_question: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "question",
          key: "id",
        },
      },

      id_question_create: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "question",
          key: "id",
        },
      },

      operation_type: {
        type: Sequelize.INTEGER,
      },
      number_operation: {
        type: Sequelize.STRING(25),
      },
      operation: {
        type: Sequelize.STRING(15),
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("SurveyQuestionsAssociates");
  },
};
