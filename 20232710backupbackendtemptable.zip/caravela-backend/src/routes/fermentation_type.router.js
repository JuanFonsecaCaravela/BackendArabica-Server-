import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlFermentationType from '../controllers/fementation_type.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlFermentationType.create);

router.put('/', verifyToken, ctrlFermentationType.update);

router.post('/all', verifyToken, ctrlFermentationType.findAll);

router.get('/:id', verifyToken, ctrlFermentationType.findById);

router.delete('/:id', verifyToken, ctrlFermentationType.deleteOne);

export default router;