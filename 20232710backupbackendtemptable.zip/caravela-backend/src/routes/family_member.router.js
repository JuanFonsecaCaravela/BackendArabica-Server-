import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlFamilyMember from '../controllers/family_member.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', verifyToken, ctrlFamilyMember.create);

router.put('/', verifyToken, ctrlFamilyMember.update);

router.post('/all/', verifyToken, ctrlFamilyMember.findAllByUserId);

router.get('/:id', verifyToken, ctrlFamilyMember.findById);
router.get('/family/:dni', verifyToken, ctrlFamilyMember.getFamily);

router.delete('/:id', verifyToken, ctrlFamilyMember.deleteOne);
router.delete('/delete/:id', verifyToken, ctrlFamilyMember.deleteFamily);
export default router;