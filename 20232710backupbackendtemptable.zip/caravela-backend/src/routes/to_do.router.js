import express from "express";
import jwtService from "../services/jwt.service";
import ctrlToDo from "../controllers/to_do.controller";

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post("/", ctrlToDo.create);

router.put("/", verifyToken, ctrlToDo.update);

router.post("/all", ctrlToDo.findAll);

router.get("/:id", verifyToken, ctrlToDo.findById);

router.get(
  "/my-to-do-list-producer/:id/:version/:uuid",
  verifyToken,
  ctrlToDo.getToDoDataProducer
);
router.get(
  "/to-do-list-technician/:id/:version/:uuid",
  verifyToken,
  ctrlToDo.getToDoDaTechnician
);
router.delete("/:id", verifyToken, ctrlToDo.deleteOne);
router.post("/create_producer", ctrlToDo.createProducer);

export default router;
