import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlPersonalizacion from '../controllers/personalization.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlPersonalizacion.create);

router.put('/:id', verifyToken, ctrlPersonalizacion.update);

router.post('/all', verifyToken, ctrlPersonalizacion.findAll);

router.get('/:id', verifyToken, ctrlPersonalizacion.findById);

router.delete('/:id', verifyToken, ctrlPersonalizacion.deleteOne);

export default router;
