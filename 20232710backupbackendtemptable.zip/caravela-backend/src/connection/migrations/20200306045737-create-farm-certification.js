"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("farm_certification", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      certification_dates: {
        type: Sequelize.ARRAY(Sequelize.DATEONLY)
      },
      farm_id: {
        type: Sequelize.INTEGER,
        references: {
          model: "farm",
          key: "id"
        }
      },
      certification_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "certification",
          key: "id"
        }
      },      
      unique_id: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("farm_certification");
  }
};
