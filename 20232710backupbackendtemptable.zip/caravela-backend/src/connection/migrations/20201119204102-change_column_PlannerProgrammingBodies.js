'use strict'

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction(t => {
      return Promise.all([
        queryInterface.changeColumn(
          'PlannerProgrammingBodies',
          'color',
          {
            type: Sequelize.DataTypes.STRING(20),
            allowNull: true
          },
          { transaction: t }
        ),
        queryInterface.changeColumn(
          'PlannerProgrammingBodies',
          'date_initial',
          {
            type: Sequelize.DataTypes.DATEONLY,
            allowNull: true
          },
          { transaction: t }
        ),
        queryInterface.changeColumn(
          'PlannerProgrammingBodies',
          'date_limit',
          {
            type: Sequelize.DataTypes.DATEONLY,
            allowNull: true
          },
          { transaction: t }
        ),
        queryInterface.changeColumn(
          'PlannerProgrammingBodies',
          'date_app_movil',
          {
            type: Sequelize.DataTypes.DATEONLY,
            allowNull: true
          },
          { transaction: t }
        ),
        queryInterface.changeColumn(
          'PlannerProgrammingBodies',
          'date_app_movil_check',
          {
            type: Sequelize.DataTypes.DATEONLY,
            allowNull: true
          },
          { transaction: t }
        )
      ])
    })
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  }
}
