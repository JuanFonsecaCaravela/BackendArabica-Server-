import express from "express";
import jwtService from "../services/jwt.service";
import ctrlRole from "../controllers/role.controller";

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post("/", [verifyToken], ctrlRole.createRole);
router.get("/get/:id", [verifyToken], ctrlRole.getRoleByUUID);
router.get('/get/roleqr/:id', [verifyToken], ctrlRole.roleIdCode);
router.get("/get-all", [verifyToken], ctrlRole.getAllRoles);
router.put("/update/:id", [verifyToken], ctrlRole.updateRole);

export default router;
