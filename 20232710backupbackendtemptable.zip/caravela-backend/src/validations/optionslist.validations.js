const { body } = require("express-validator");

const create = () => {
  return [
    body("description")
      .exists()
      .withMessage("description doesn't exists")
      .not()
      .isEmpty()
      .withMessage("description isEmpty"),
    body("bodyoptions")
      .exists()
      .withMessage("bodyoptions doesn't exists")
      .not()
      .isEmpty()
      .withMessage("bodyoptions isEmpty")
  ];
};

const update = () => {
  return [
    body("UUID")
      .exists()
      .withMessage("UUID doesn't exists")
      .not()
      .isEmpty()
      .withMessage("UUID isEmpty"),
    body("bodyoptions")
      .exists()
      .withMessage("bodyoptions doesn't exists")
      .not()
      .isEmpty()
      .withMessage("bodyoptions isEmpty")
  ];
};

const findAll = () => {
  return [
    body("page")
      .exists()
      .withMessage("page doesn't exists")
      .not()
      .isEmpty()
      .withMessage("page isEmpty"),
    body("paginate")
      .exists()
      .withMessage("paginate doesn't exists")
      .not()
      .isEmpty()
      .withMessage("paginate isEmpty")
  ];
};




export default { 
                create ,
                update,
                findAll
              };
