'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('fertilizreRequirements', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      addrequirement_id: {
        type: Sequelize.STRING
      },
      tipo: {
        type: Sequelize.STRING
      },
      coffeeAgeBegin: {
        type: Sequelize.INTEGER
      },
      coffeeAgeEnd: {
        type: Sequelize.INTEGER
      },
      NumberOfStemsBegin: {
        type: Sequelize.INTEGER
      },
      NumberOfStemsEnd: {
        type: Sequelize.INTEGER
      },
      PlantingDistBegin: {
        type: Sequelize.INTEGER
      },
      PlantingDistEnd: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('fertilizreRequirements');
  }
};