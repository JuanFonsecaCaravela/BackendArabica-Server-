'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('AnswerBodies', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      unique_id: {
        type: Sequelize.STRING(200),
        allowNull: false
      },     
      type: {
        type: Sequelize.STRING,
        allowNull: true
      },
      version: {
        type: Sequelize.INTEGER
      }, 
      answer: {
        type: Sequelize.STRING(5000),
        allowNull: true
      },
      
      id_answer : {
        type : Sequelize.INTEGER,
        allowNull:false,
        references: {
          model: "answer_surveys",
          key: "id"
        }

      },
      id_question: {
        type : Sequelize.INTEGER,
        allowNull:false,
        references: {
          model: "question",
          key: "id"
        }

      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('AnswerBodies');
  }
};