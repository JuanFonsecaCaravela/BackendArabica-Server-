"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("question", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      order: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      version: {
        type: Sequelize.INTEGER,
        allowNull: false
      },

      min: {
        type: Sequelize.INTEGER,
        allowNull: false
      },

      max: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      required: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      date: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      time: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      pdf: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      png: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      jpg: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      doc: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      excel: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      description: {
        type: Sequelize.STRING(1000),
        allowNull: false,
        get: function() {
          return this.getDataValue("description");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("description", capitalize.words(value));
        }
      },
      unique_id: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      iddispositivo: {
        type: Sequelize.STRING(100),
        allowNull: false
      },
      delete_user_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },
      survey_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "survey",
          key: "id"
        }
      },
      type_question_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "question_type",
          key: "id"
        }
      },
      delete_at: {
        type: Sequelize.DATE,
        allowNull: true
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("question");
  }
};
