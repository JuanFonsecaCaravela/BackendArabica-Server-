import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlProcessType from '../controllers/process_type.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlProcessType.create);

router.put('/', verifyToken, ctrlProcessType.update);

router.post('/all', verifyToken, ctrlProcessType.findAll);

router.get('/:id', verifyToken, ctrlProcessType.findById);

router.delete('/:id', verifyToken, ctrlProcessType.deleteOne);

export default router;