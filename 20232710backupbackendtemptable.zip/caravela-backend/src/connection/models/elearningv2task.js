'use strict';
module.exports = (sequelize, DataTypes) => {
  const elearningv2Task = sequelize.define('elearningv2Task', {
    elearningv2_Task_id: DataTypes.STRING,
    title: DataTypes.STRING,
    id_elearningv2_Task_type: DataTypes.INTEGER,
    elearningv2_session_id: DataTypes.INTEGER,
    description: DataTypes.STRING,
    Type: DataTypes.STRING,
    version: DataTypes.STRING,
    state_id: DataTypes.INTEGER
  }, {});
  elearningv2Task.associate = function(models) {
    // associations can be defined here
    elearningv2Task.belongsTo(models.elearningv2session, {
      foreignKey: { name: "elearningv2_session_id", allowNull: true }
    });
    elearningv2Task.belongsTo(models.elearningv2TaskType, {
      foreignKey: { name: "id_elearningv2_Task_type", allowNull: true }
    });
  };
  return elearningv2Task;
};