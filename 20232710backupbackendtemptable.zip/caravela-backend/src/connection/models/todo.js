"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const ToDo = sequelize.define(
    "ToDo",
    {
      name: DataTypes.STRING,
      description: DataTypes.STRING,
      id_producer: DataTypes.INTEGER,
      unique_id: DataTypes.STRING,
      id_peca: DataTypes.INTEGER,
      date: DataTypes.STRING,
      state: DataTypes.STRING,
      type: DataTypes.INTEGER,
      hour: DataTypes.STRING,
      priority: DataTypes.STRING,
      status: DataTypes.STRING,
    },
    {}
  );
  ToDo.associate = function (models) {
    ToDo.belongsTo(models.caravela_user, {
      foreignKey: { name: "id_producer" },
      as: "Producer_ToDo",
    });
    ToDo.belongsTo(models.caravela_user, {
      foreignKey: { name: "id_peca", allowNull: false },
      as: "Technician_ToDo",
    });
  };
  sequelizePaginate.paginate(ToDo);
  return ToDo;
};
