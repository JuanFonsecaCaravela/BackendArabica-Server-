"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("MessageHeads", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      unique_id: {
        type: Sequelize.STRING
      },
      subject: {
        type: Sequelize.STRING(100),
        allowNull: false,
        get: function() {
          return this.getDataValue("description");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("description", capitalize.words(value));
        }
      },
      content: {
        type: Sequelize.STRING(1000),
        allowNull: false,
        get: function() {
          return this.getDataValue("description");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("description", capitalize.words(value));
        }
      },
      img: {
        type: Sequelize.STRING(200),
        allowNull: false,
        get: function() {
          return this.getDataValue("description");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("description", capitalize.words(value));
        }
      },
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },
      technicial_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },
      status_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "StatusMessages",
          key: "id"
        }
      },

      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("MessageHeads");
  }
};
