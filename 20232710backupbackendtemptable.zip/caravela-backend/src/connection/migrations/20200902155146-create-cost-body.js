"use strict";

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("cost_Body", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      cost_Body_id: {
        type: Sequelize.STRING(255),
      },
      description: {
        type: Sequelize.STRING,
        defaultValue: "NA",

      },
      id_costCategory: {
        type: Sequelize.INTEGER,
        references: {
          model: 'costCategory',
          key: 'id'
        }
      },

      id_cost_Head: {
        type: Sequelize.INTEGER,
        references: {
          model: 'cost_Head',
          key: 'id'
        }
      },

      colombia: {
        type: Sequelize.STRING,
        defaultValue: "NA",

      },
      ecuador: {
        type: Sequelize.STRING,
        defaultValue: "NA",

      },
      salvador: {
        type: Sequelize.STRING,
        defaultValue: "NA",

      },
      guatemala: {
        type: Sequelize.STRING,
        defaultValue: "NA",

      },
      mexico: {
        type: Sequelize.STRING,
        defaultValue: "NA",

      },
      nicaragua: {
        type: Sequelize.STRING,
        defaultValue: "NA",

      },
      peru: {
        type: Sequelize.STRING,
        defaultValue: "NA",

      },

      askProducer: {
        allowNull: true,
        type: Sequelize.BOOLEAN,
        defaultValue:false,
      },
      required: {
        allowNull: true,
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      },
      state_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'state',
          key: 'id'
        }
      },

      deleteAt: {
        allowNull: true,
        type: Sequelize.DATE
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("cost_Body");
  }
};
