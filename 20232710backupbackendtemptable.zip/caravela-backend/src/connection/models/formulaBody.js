'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const formula_Body = sequelize.define (
    'formula_Body',
    {
      uuid: DataTypes.STRING,
      operator: DataTypes.STRING,
      term: DataTypes.INTEGER,
      parenthesis: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      orderBy :DataTypes.INTEGER,
      id_formula_Head: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
    },
    {
      freezeTableName: true,
      name: {
        singular: 'formula_Body',
        plural: 'formula_Body',
      },
    }
  );

  formula_Body.associate = function (models) {
    formula_Body.belongsTo (models.formula_Head, {
      foreignKey: {name: 'id_formula_Head', allowNull: false},
    });
    formula_Body.belongsTo (models.cost_Body, {
      foreignKey: {name: 'term', allowNull: false},
    });
    // formula_Body.belongsTo(models.state, {
    //   foreignKey: { name: "state_id", allowNull: false }
    // });
  };
  sequelizePaginate.paginate (formula_Body);
  return formula_Body;
};
