'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([
        queryInterface.addColumn(
          "caravela_user",
          "check_coffee",
          {
            type: Sequelize.DataTypes.BOOLEAN,
            allowNull: true
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "caravela_user",
          "dni_associated",
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true
          },
          { transaction: t }
        )


      ]);
    });
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  }
};
