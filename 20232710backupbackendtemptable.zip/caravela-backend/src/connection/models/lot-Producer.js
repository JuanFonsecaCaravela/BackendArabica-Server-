'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const LotProducer = sequelize.define ('LotProducer', {
    unique_id: DataTypes.STRING,
    IdProducer: DataTypes.INTEGER,
    idLot: DataTypes.STRING,
    IdStatusLot: DataTypes.INTEGER,
    DateStatusLot: DataTypes.DATE,
    Value: DataTypes.DECIMAL,
    Quality: DataTypes.DECIMAL,
    Quantity: DataTypes.DECIMAL,
    Score: DataTypes.DECIMAL,
    Humidity: DataTypes.DECIMAL,
    WaterActivity: DataTypes.DECIMAL,
    Performance: DataTypes.DECIMAL,
    CauseRejection: DataTypes.STRING,
    DateUpdated: DataTypes.DATE,
    Origin: DataTypes.STRING,
    version:DataTypes.INTEGER,
    deleteAt: DataTypes.DATE,
    qualityletter: DataTypes.STRING,
  },
  {
    freezeTableName: true,
    name: {
      singular: 'LotProducer',
      plural: 'LotProducer',
    },
  });
  LotProducer.associate = function (models) {
    LotProducer.belongsTo (models.caravela_user, {
      foreignKey: {name: 'IdProducer', allowNull: true},
    });
    LotProducer.belongsTo (models.StateLot, {
      foreignKey: {name: 'IdStatusLot', allowNull: true},
    });
  };
  sequelizePaginate.paginate (LotProducer);
  return LotProducer;
};
