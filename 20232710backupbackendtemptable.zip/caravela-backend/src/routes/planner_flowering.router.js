import express from "express"
import jwtService from "../services/jwt.service"
import ctrlPlannerFlowering from "../controllers/planner_flowering.controller"

const router = express.Router()

const verifyToken = jwtService.verifyToken

router.post("/create", verifyToken, ctrlPlannerFlowering.Create)
router.post("/save-planner-body", verifyToken, ctrlPlannerFlowering.savePlannerBody)
router.post("/save-planner-head", verifyToken, ctrlPlannerFlowering.savePlannerHead)
router.post("/getAll/:version/:uuid", verifyToken, ctrlPlannerFlowering.getAllPlannerByidsFarms)

router.post("/list", verifyToken, ctrlPlannerFlowering.FindAll)
router.get("/find/:id", verifyToken, ctrlPlannerFlowering.Find)
router.post("/listAll", verifyToken, ctrlPlannerFlowering.listAll)

export default router
