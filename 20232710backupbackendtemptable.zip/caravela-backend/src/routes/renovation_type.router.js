import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlRenovationType from '../controllers/renovation_type.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlRenovationType.create);

router.put('/', verifyToken, ctrlRenovationType.update);

router.post('/all', verifyToken, ctrlRenovationType.findAll);

router.get('/:id', verifyToken, ctrlRenovationType.findById);

router.delete('/:id', verifyToken, ctrlRenovationType.deleteOne);

export default router;