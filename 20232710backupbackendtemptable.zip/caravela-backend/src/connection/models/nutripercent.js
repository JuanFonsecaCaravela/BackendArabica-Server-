'use strict';
module.exports = (sequelize, DataTypes) => {
  const NutriPercent = sequelize.define('NutriPercent', {
    nutriPercent_id: DataTypes.STRING,
    nutriName: DataTypes.STRING,
    percent: DataTypes.STRING,
    nutriPercent: DataTypes.INTEGER,
    NutriRef: DataTypes.INTEGER,
  }, {});
  NutriPercent.associate = function(models) {
    NutriPercent.belongsTo(models.Fertilizer,{
      foreignKey: { name: "nutriPercent", allowNull: false },
      onDelete: 'CASCADE'
    })
    NutriPercent.belongsTo(models.Nutrition,{
      foreignKey: { name: "NutriRef", allowNull: false },
    })
  };
  return NutriPercent;
};