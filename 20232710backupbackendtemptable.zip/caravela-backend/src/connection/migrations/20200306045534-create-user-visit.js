"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("user_visit", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      user_visit_id: {
        type: Sequelize.STRING(255),
      },
      visit_rating: {
        type: Sequelize.DOUBLE
      },
      done_user: {
        type: Sequelize.BOOLEAN,
        defaultValue: false
      },
      done_peca: {
        type: Sequelize.BOOLEAN,
        defaultValue: false
      },
      skills: {
        type: Sequelize.JSONB,
        defaultValue: []
      },
      producer_visited_id: {        
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },
      visiting_technician_id: {        
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },
      visit_id: {        
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "visit",
          key: "id"
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("user_visit");
  }
};
