'use strict';
module.exports = (sequelize, DataTypes) => {
    const questionnaireApply = sequelize.define('questionnaireApply', {
        id_country: DataTypes.INTEGER,
        id_deparment: DataTypes.INTEGER,
        id_survey: DataTypes.INTEGER
      }, {});
      questionnaireApply.associate = function(models) {
        questionnaireApply.belongsTo(models.questionnaire, {
          foreignKey: { name: "id_survey", allowNull: false },
        });
        questionnaireApply.belongsTo(models.country, {
          foreignKey: { name: "id_country", allowNull: false },
        });
        questionnaireApply.belongsTo(models.department, {
          foreignKey: { name: "id_deparment", allowNull: true },
        });
    };
    return questionnaireApply;
};