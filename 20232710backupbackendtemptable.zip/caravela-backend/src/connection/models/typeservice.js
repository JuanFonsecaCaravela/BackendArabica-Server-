'use strict';
module.exports = (sequelize, DataTypes) => {
  const typeService = sequelize.define('typeService', {
    description: DataTypes.STRING
  }, {});
  typeService.associate = function(models) {
    typeService.hasMany(models.serviceVersion, {
      foreignKey: { name: "type_service_id", allowNull: true }
    });
    typeService.hasMany(models.current_versionservice, {
      foreignKey: { name: "type_service_id", allowNull: true }
    });
  };
  return typeService;
};