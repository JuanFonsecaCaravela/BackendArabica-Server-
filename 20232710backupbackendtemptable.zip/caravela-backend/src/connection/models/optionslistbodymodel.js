'use strict';
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const OptionsListBodyModel = sequelize.define('OptionsListBodyModel', {
    description: DataTypes.STRING,
    id_head: DataTypes.INTEGER
  }, {});
  OptionsListBodyModel.associate = function(models) {
    OptionsListBodyModel.belongsTo(models.OptionsListHeadModel, { 
      foreignKey: { name: 'id_head', allowNull: false }
     }); 
  };
  sequelizePaginate.paginate(OptionsListBodyModel);
  return OptionsListBodyModel;
};