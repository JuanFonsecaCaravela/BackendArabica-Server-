"use strict";
module.exports = (sequelize, DataTypes) => {
  const user_type = sequelize.define(
    "user_type",
    {
      user_type_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING
    },
    {
      freezeTableName: true,
      name: {
        singular: "visit_type",
        plural: "visit_type"
      }
    }
  );
  user_type.associate = function(models) {
    // associations can be defined here
  };
  return user_type;
};
