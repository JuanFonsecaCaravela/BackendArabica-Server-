import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlGender from '../controllers/gender.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlGender.create);

router.put('/', verifyToken, ctrlGender.update);

router.post('/all', verifyToken, ctrlGender.findAll);

router.get('/:id', verifyToken, ctrlGender.findById);

router.delete('/:id', verifyToken, ctrlGender.deleteOne);

export default router;