import express from "express";
import jwtService from "../services/jwt.service";
import ctrlTenant from "../controllers/tenant.controller";

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post("/", ctrlTenant.create);

router.put("/", verifyToken, ctrlTenant.update);

router.post("/all-Tenant", verifyToken, ctrlTenant.findAll);

router.get("/:id", verifyToken, ctrlTenant.findById);

router.delete("/:id", verifyToken, ctrlTenant.deleteOne);

export default router;
