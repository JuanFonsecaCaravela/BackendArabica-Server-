"use strict";
module.exports = (sequelize, DataTypes) => {
  const farm_fermentation_type = sequelize.define(
    "farm_fermentation_type",
    {
      farm_id: DataTypes.INTEGER,
      fermentation_type_id: DataTypes.INTEGER,
      unique_id : DataTypes.STRING,
      state_id: DataTypes.INTEGER
    },
    {
      freezeTableName: true,
      name: {
        singular: "farm_fermentation_type",
        plural: "farm_fermentation_type"
      }
    }
  );
  farm_fermentation_type.associate = function(models) {
    farm_fermentation_type.belongsTo(models.farm, {
      foreignKey: { name: "farm_id", allowNull: false }
    });
    farm_fermentation_type.belongsTo(models.fermentation_type, {
      foreignKey: { name: "fermentation_type_id", allowNull: false }
    });
  };
  return farm_fermentation_type;
};
