'use strict';
module.exports = (sequelize, DataTypes) => {
  const current_versionservice = sequelize.define('current_versionservice', {
    id_user: DataTypes.INTEGER,
    uuid_phone: DataTypes.STRING,
    current_version: DataTypes.INTEGER,
    version_in_app: DataTypes.INTEGER,
    type_service_id: DataTypes.INTEGER,
    id_country: DataTypes.INTEGER,
  }, {});
  current_versionservice.associate = function(models) {
    
    current_versionservice.belongsTo(models.caravela_user, {
      foreignKey: { name: "id_user", allowNull: true }
    });
    current_versionservice.belongsTo(models.country, {
      foreignKey: { name: "id_country", allowNull: true }
    });
    current_versionservice.belongsTo(models.typeService, {
      foreignKey: { name: "type_service_id", allowNull: true }
    });
  };
  return current_versionservice;
};