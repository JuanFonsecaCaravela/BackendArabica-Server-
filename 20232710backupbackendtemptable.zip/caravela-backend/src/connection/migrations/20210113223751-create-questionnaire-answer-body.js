'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('questionnaire_answer_bodies', {
            id: {
              allowNull: false,
              autoIncrement: true,
              primaryKey: true,
              type: Sequelize.INTEGER
            },
            unique_id: {
              type: Sequelize.STRING(200),
              allowNull: false
            },     
            type: {
              type: Sequelize.STRING,
              allowNull: true
            },
            version: {
              type: Sequelize.INTEGER
            }, 
            answer: {
              type: Sequelize.STRING(2000),
              allowNull: true
            },
            
            id_answer : {
              type : Sequelize.INTEGER,
              allowNull:false,
              references: {
                model: "questionnaire_answers",
                key: "id"
              }
      
            },
            id_question: {
              type : Sequelize.INTEGER,
              allowNull:false,
              references: {
                model: "QuestionnaireQuestions",
                key: "id"
              }
      
            },
            createdAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            updatedAt: {
              allowNull: false,
              type: Sequelize.DATE
            }
          });
    },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('questionnaire_answer_bodies');
    }
};