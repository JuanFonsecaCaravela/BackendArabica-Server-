"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const elearning_Head = sequelize.define(
    "elearning_Head",
    {
      elearning_Head_id: DataTypes.STRING,
      title: DataTypes.STRING,
      category: DataTypes.STRING,
      trainingCycle: DataTypes.STRING,
      consecutiveCourse: DataTypes.STRING,
      TypeCourse: DataTypes.STRING,
      nameWhoOffers: DataTypes.STRING,
      accessLink: DataTypes.STRING,
      modality: DataTypes.STRING,
      Hourlyintensity: DataTypes.STRING,
      maximumQuota: DataTypes.STRING,
      numberStars: DataTypes.STRING,
      strengthenKnowledge: DataTypes.STRING,
      description: DataTypes.STRING,
      loadFile: DataTypes.STRING,
      courseValidity: DataTypes.DATE,
      deleteAt: DataTypes.DATE,
      state_id: DataTypes.INTEGER,
      version: DataTypes.STRING,
      userCreate: DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "elearning_Head",
        plural: "elearning_Head"
      }
    }
  );

  elearning_Head.associate = function (models) {

    
    elearning_Head.hasMany(models.elearning_Body, {
      foreignKey: { name: "id_elearning_Head", allowNull: false }
    });
    elearning_Head.hasMany(models.elearning_Objective, {
      foreignKey: { name: "id_elearning_Head", allowNull: false }
    });
  };
  sequelizePaginate.paginate(elearning_Head);
  return elearning_Head;
};
