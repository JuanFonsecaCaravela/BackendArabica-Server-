"use strict";
module.exports = (sequelize, DataTypes) => {
  const PermissionModel = sequelize.define(
    "PermissionModel",
    {
      description: DataTypes.STRING,
      slug: DataTypes.STRING,
      unique_id: DataTypes.STRING
    },
    {}
  );
  PermissionModel.associate = function(models) {
    PermissionModel.belongsToMany(models.Role, {
      through: models.RolePermissionModel,
      foreignKey: "id_permission",
    });
  };
  return PermissionModel;
};
