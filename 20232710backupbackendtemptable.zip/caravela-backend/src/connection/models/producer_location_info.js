'use strict';
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const Producer_Location_Info = sequelize.define('Producer_Location_Info', {    
    producer_location_id: DataTypes.STRING,
    wareHouse_Name: DataTypes.STRING,
    factor_base: DataTypes.STRING,
    humidity: DataTypes.STRING,
    contact1: DataTypes.STRING,
    contact2: DataTypes.STRING,
    wareHouseLocation_id: DataTypes.INTEGER,
    isDeleted:DataTypes.BOOLEAN,
    isDeletedDate:DataTypes.STRING,
    version:DataTypes.INTEGER
  }, {});
  Producer_Location_Info.associate = function(models) {
    // Producer_Location_Info.belongsTo(models.caravela_user, {
    //   foreignKey: { name: "user_id", allowNull: false }
    // })
    //parent relation
    Producer_Location_Info.hasMany(models.coffee_price,{
      foreignKey: { name: "location_id", allowNull: false },
      onDelete: "CASCADE",
    })//child relation
    Producer_Location_Info.belongsTo(models.wareHouse,{
      foreignKey: { name: "wareHouseLocation_id", allowNull: false },
      onDelete: "CASCADE",
    })
  };
  sequelizePaginate.paginate(Producer_Location_Info);
  return Producer_Location_Info;
};
//nitish
