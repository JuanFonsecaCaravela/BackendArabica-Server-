import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlCostHead from '../controllers/costHead.controller';

const router = express.Router ();

const verifyToken = jwtService.verifyToken;

router.post ('/', verifyToken, ctrlCostHead.create);

router.put ('/', verifyToken, ctrlCostHead.update);

router.post ('/all', verifyToken, ctrlCostHead.findAll);

router.post ('/body/all', verifyToken, ctrlCostHead.findAllBody);

router.get ('/sync/all', verifyToken, ctrlCostHead.findHeadSync);

router.get ('/sync/body/all', verifyToken, ctrlCostHead.findBodySync);

router.get ('/:id', verifyToken, ctrlCostHead.findById);

router.get ('/allYear/all', verifyToken, ctrlCostHead.findAllyear);

router.delete ('/:id', verifyToken, ctrlCostHead.deleteOne);

router.delete ('/deleteBody/:id', verifyToken, ctrlCostHead.deleteCostBody);

router.post ('/save-ReplyCost/', verifyToken, ctrlCostHead.saveRepry);

router.post (
  '/YearCategory',
  verifyToken,
  ctrlCostHead.findByIdCategoryAndYear
);


router.get ('/Reply/all/', verifyToken, ctrlCostHead.findAllReply);

router.get ('/Average/all/', verifyToken, ctrlCostHead.average);

router.post ('/detailsUser/', verifyToken, ctrlCostHead.findAllCostDetailsUser);



export default router;
