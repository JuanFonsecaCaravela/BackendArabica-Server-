'use strict';
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const wareHouse = sequelize.define('wareHouse', {
    wareHouse_unique_id: DataTypes.STRING,
    wareHouse_name: DataTypes.STRING,
    isDeleted:DataTypes.BOOLEAN,
    isDeletedDate:DataTypes.STRING,
    version:DataTypes.INTEGER
  }, {});
  wareHouse.associate = function(models) {
    wareHouse.hasMany(models.wareHouseMunicipality,{
      foreignKey: { name: "wareHouse_id", allowNull: false },
      onDelete: 'CASCADE'
    })
    wareHouse.hasMany(models.Producer_Location_Info,{
      foreignKey: { name: "wareHouseLocation_id", allowNull: false },
      onDelete: 'CASCADE'
    })
    // associations can be defined here
  };
  sequelizePaginate.paginate(wareHouse);
  return wareHouse;
};