'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('NutriPercents', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      nutriPercent_id: {
        type: Sequelize.STRING
      },
      nutriName: {
        type: Sequelize.STRING
      },
      percent: {
        type: Sequelize.STRING
      },
      nutriPercent: {
        type: Sequelize.INTEGER, 
        onDelete: 'CASCADE',      
        allowNull: true,   
        references: {
          model: "Fertilizers",
          key: "id"
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('NutriPercents');
  }
};