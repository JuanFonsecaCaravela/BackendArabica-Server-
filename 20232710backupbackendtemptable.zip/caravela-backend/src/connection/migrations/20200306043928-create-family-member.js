"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("family_member", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      family_member_id: {
        type: Sequelize.STRING(255),
        primaryKey: true,
        allowNull: false
      },
      name: {
        type: Sequelize.STRING(80),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("name");
        },
        set: function(value) {
          this.setDataValue("name", capitalize.words(value));
        }
      },
      lastname: {
        type: Sequelize.STRING(80),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("lastname");
        },
        set: function(value) {
          this.setDataValue("lastname", capitalize.words(value));
        }
      },
      birthdate: {
        type: Sequelize.DATEONLY,
        allowNull: true
      },
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },

      gender_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "gender",
          key: "id"
        }
      },

      relationship_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "relationship",
          key: "id"
        }
      },

      scholarship_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "scholarship",
          key: "id"
        }
      },
      deleteAt: {
        allowNull: true,
        type: Sequelize.DATE
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("family_member");
  }
};
