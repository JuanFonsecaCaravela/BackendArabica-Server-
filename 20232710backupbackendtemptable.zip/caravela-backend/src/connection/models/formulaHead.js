"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const formula_Head = sequelize.define(
    "formula_Head",
    {
      description: DataTypes.STRING,
      uuid: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      orderBy :DataTypes.INTEGER,
      measure_id: DataTypes.INTEGER,
      category_select: DataTypes.INTEGER
    },
    {
      freezeTableName: true,
      name: {
        singular: "formula_Head",
        plural: "formula_Head"
      }
    }
  );

  formula_Head.associate = function (models) {

    formula_Head.hasMany(models.formula_Body, {
      foreignKey: { name: "id_formula_Head", allowNull: false }
    });
    formula_Head.belongsTo(models.measure, {
      foreignKey: { name: "measure_id", allowNull: true }
    });
  };
  sequelizePaginate.paginate(formula_Head);
  return formula_Head;
};


