'use strict';
module.exports = (sequelize, DataTypes) => {
  const Land_Ownership = sequelize.define('Land_Ownership', {
    uuid: DataTypes.STRING,
    description_spanish: DataTypes.STRING,
    description_english: DataTypes.STRING,
    state_id: DataTypes.INTEGER
  }, {});
  Land_Ownership.associate = function(models) {
    // associations can be defined here
  };
  return Land_Ownership;
};