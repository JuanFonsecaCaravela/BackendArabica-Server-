'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([
        queryInterface.addColumn(
          'farm_fermentation_type',
          'state_id',
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
            references: {
              model: 'state',
              key: 'id',
            },
          },
          { transaction: t }
        ),
      ]);
    });
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  }
};
