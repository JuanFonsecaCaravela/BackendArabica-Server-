'use strict'

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([
        queryInterface.addColumn(
          "caravela_user",
          "total_rating",
          {
            type: Sequelize.DataTypes.DOUBLE,
            allowNull: true,
            defaultValue: 0,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "caravela_user",
          "count_rating",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: true,
            defaultValue: 0,
          },
          { transaction: t }
        ),
      ])
    })
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  }
}
