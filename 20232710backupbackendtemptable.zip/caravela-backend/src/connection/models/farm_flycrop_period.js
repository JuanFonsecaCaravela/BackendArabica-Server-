'use strict';
module.exports = (sequelize, DataTypes) => {
  const farm_flycrop_period = sequelize.define('farm_flycrop_period', {
    farm_id: DataTypes.INTEGER,
    start: DataTypes.DATEONLY,
    end: DataTypes.DATEONLY,
    unique_id: DataTypes.STRING,
    deleteAt: DataTypes.DATE,
    state_id: DataTypes.INTEGER
  }, {});
  farm_flycrop_period.associate = function(models) {
    farm_flycrop_period.belongsTo(models.farm, {
      foreignKey: { name: "farm_id", allowNull: false }
    });
  };
  return farm_flycrop_period;
};