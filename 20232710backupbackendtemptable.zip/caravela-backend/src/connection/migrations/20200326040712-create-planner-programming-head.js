"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("PlannerProgrammingHeads", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      unique_id: {
        type: Sequelize.STRING
      },
      date: {
        type: Sequelize.DATE
      },
      day: {
        type: Sequelize.INTEGER
      },
      month: {
        type: Sequelize.INTEGER
      },
      year: {
        type: Sequelize.INTEGER
      },
      week: {
        type: Sequelize.INTEGER
      },
      state: {
        type: Sequelize.INTEGER, // 1. Activo , 2. Terminada
        defaultValue: 1
      },
      farm_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "farm",
          key: "id"
        }
      },
      plot_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "plot",
          key: "id"
        }
      },
      flowering_qualities_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "FloweringQualities",
          key: "id"
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("PlannerProgrammingHeads");
  }
};
