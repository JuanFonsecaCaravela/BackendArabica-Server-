import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlSynchronizer from '../controllers/synchronizer.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.get('/last-version/:id' , ctrlSynchronizer.LastVersionByTypeService);

export default router;