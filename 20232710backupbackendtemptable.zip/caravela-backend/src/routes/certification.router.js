import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlCertification from '../controllers/certification.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', verifyToken, ctrlCertification.create);

router.put('/', verifyToken, ctrlCertification.update);

router.post('/all', verifyToken, ctrlCertification.findAll);

router.get('/:id', verifyToken, ctrlCertification.findById);

router.delete('/:id', verifyToken, ctrlCertification.deleteOne);

export default router;