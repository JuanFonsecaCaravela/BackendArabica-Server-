"use strict";

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("certification", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      certification_id: {
        type: Sequelize.STRING(255),
      },
      spanish_name: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("spanish_name");
        },
        set: function(value) {
          this.setDataValue("spanish_name", capitalize.words(value));
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("certification");
  }
};
