import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlAssociations from '../controllers/associations.controller';

const router = express.Router();
const verifyToken = jwtService.verifyToken;
router.get('/', verifyToken, ctrlAssociations.getAll);

export default router;