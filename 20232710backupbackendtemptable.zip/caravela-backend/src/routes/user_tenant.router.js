import express from "express";
import jwtService from "../services/jwt.service";
import ctrlUserTenant from "../controllers/user_tenant_controller";

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post("/", ctrlUserTenant.create);

router.put("/", verifyToken, ctrlUserTenant.update);

router.post("/all-Tenant", verifyToken, ctrlUserTenant.findAll);

router.get("/:id", verifyToken, ctrlUserTenant.findById);

router.delete("/:id", verifyToken, ctrlUserTenant.deleteOne);

export default router;
