//import moment from 'moment-timezone'
import db from '../connection/models/index'
import _TWILIO from '../services/twilio.service'
const Op = db.Sequelize.Op
const findProducerMessages = async (ids, type, messagge, user_id) => {
    try {
        const usersFounds = await db.caravela_user.findAll({
            attributes: ['cellphone'],
            include: [
                {
                    model: db.municipality,
                    attributes: ['id'],
                    required: true,
                    include: [
                        {
                            model: db.department,
                            attributes: ['id'],
                            required: true,
                            include: [
                                {
                                    model: db.country,
                                    required: true,
                                    attributes: ['country_code'],
                                }
                            ]
                        }
                    ]
                }
            ],
            where: {
                caravela_user_id: ids,
                cellphone: {
                    [Op.ne]: null
                },
                state_id: 1
            }
        })
        console.log("USUARIOS: ", ids, " LENGH: ", usersFounds.length, "type", type)
        for (let user of usersFounds) {
            switch (type) {
                case "1"://este sera para mensajes de texto
                    console.log("INGRESE A ENVIAR MENSAJE");
                    await _TWILIO.senMessage(messagge, `+${user.dataValues.municipality.department.country.country_code}${user.dataValues.cellphone.replace("+", "")}`, user_id)
                    break
                case "2"://este sera para mensajes de Whatsapp
                console.log("INGRESE A ENVIAR WHASTAPP");
                    await _TWILIO.senMessageWP(messagge, `+${user.dataValues.municipality.department.country.country_code}${user.dataValues.cellphone.replace("+", "")}`, user_id)
                    break
                default:
                    break
            }

        }
    } catch (error) {
        console.log('Hubo un error ', error)
        return null
    }
}

export default {
    findProducerMessages
}
