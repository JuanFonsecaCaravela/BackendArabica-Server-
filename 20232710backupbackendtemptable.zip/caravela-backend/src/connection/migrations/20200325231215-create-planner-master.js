'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('PlannerMasters', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      description: {
        type: Sequelize.STRING(100)
      },
      unique_id: {
        type: Sequelize.STRING(100)
      },
      starting_week: {
        type: Sequelize.INTEGER
      },
      final_week: {
        type: Sequelize.INTEGER
      },
      color: {
        type: Sequelize.STRING(20)
      },
      required: {
        type: Sequelize.BOOLEAN
      },
      visible: {
        type: Sequelize.BOOLEAN
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('PlannerMasters');
  }
};