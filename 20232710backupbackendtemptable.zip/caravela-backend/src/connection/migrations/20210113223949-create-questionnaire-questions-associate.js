'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('questionnaireQuestionsAssociates', {
            id: {
              allowNull: false,
              autoIncrement: true,
              primaryKey: true,
              type: Sequelize.INTEGER,
            },
            id_question: {
              type: Sequelize.INTEGER,
              allowNull: true,
              references: {
                model: "QuestionnaireQuestions",
                key: "id",
              },
            },
      
            id_question_create: {
              type: Sequelize.INTEGER,
              allowNull: false,
              references: {
                model: "QuestionnaireQuestions",
                key: "id",
              },
            },
            operation_type: {
              type: Sequelize.INTEGER,
            },
            number_operation: {
              type: Sequelize.STRING(25),
            },
            operation: {
              type: Sequelize.STRING(15),
            },
            createdAt: {
              allowNull: false,
              type: Sequelize.DATE, 
            },
            updatedAt: {
              allowNull: false,
              type: Sequelize.DATE,
            },
            parenthesisL:{
              type: Sequelize.DataTypes.BOOLEAN,
              allowNull: true,
            },
            parenthesisR:{
              type: Sequelize.DataTypes.BOOLEAN,
              allowNull: true
            },
            id_category:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true
            },
            id_question_id_device:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true
            },
            version:{
              type: Sequelize.DataTypes.INTEGER,
              allowNull: true,
              defaultValue: 0,
            }
             

          });
    },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('questionnaireQuestionsAssociates');
    }
};