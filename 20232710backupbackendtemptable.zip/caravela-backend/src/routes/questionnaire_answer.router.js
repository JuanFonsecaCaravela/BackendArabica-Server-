import express from 'express'
import jwtService from '../services/jwt.service'
import ctrlAnswer from '../controllers/questionnaire_answer.controller'

const router = express.Router()

// const verifyToken = jwtService.verifyToken;

router.post('/create', ctrlAnswer.create)
router.post('/v2/create', ctrlAnswer.createv2)
router.post('/v2/get-answers', ctrlAnswer.getAnswersv2)
router.get('/all', ctrlAnswer.findAll)
router.get('/get-answer/associate/:version/:uuid', ctrlAnswer.getAnswerbysurveyAssociate)
router.get('/get-answer/associate-pecaid/:id/:version/:uuid', ctrlAnswer.getAnswerbysurveyAssociateByIdpeca)
router.post('/get-answers', ctrlAnswer.getAnswers)
router.post('/get-answersTec', ctrlAnswer.getAnswersTec)
router.post('/get-answersPro', ctrlAnswer.getAnswersPro)
router.post('/update-answers', ctrlAnswer.setUpdateAnswerBody)
router.get('/find/:id', ctrlAnswer.getAnswerByUUID)
router.get('/v2/find/:id', ctrlAnswer.getAnswerByUUIDv2)
router.get('/pdf/:id/:token', ctrlAnswer.getPdfUuid)
router.post('/updateAnswerApp', ctrlAnswer.updateAnswerApp)


export default router