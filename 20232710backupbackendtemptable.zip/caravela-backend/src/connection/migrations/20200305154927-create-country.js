"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("country", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      country_id: {
        type: Sequelize.STRING(255)
      },
      spanish_name: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("spanish_name");
        },
        set: function(value) {
          this.setDataValue("spanish_name", capitalize.words(value));
        }
      },
      area_units: {
        type: Sequelize.STRING(30),
        defaultValue: "NOUNIT"
      },
      area_units_spanish_name: {
        type: Sequelize.STRING(30),
        defaultValue: "NOUNITNAME"
      },
      currency_type: {
        type: Sequelize.STRING(20),
        defaultValue: "NA"
      },
      weight_units: {
        type: Sequelize.STRING(30),
        defaultValue: "NA"
      },
      weight_units_spanish_name: {
        type: Sequelize.STRING(30),
        defaultValue: "NA"
      },
      iso_code: {
        type: Sequelize.STRING(10),
        defaultValue: "NA"
      },
      country_code: {
        type: Sequelize.STRING(10),
        defaultValue: "NA"
      },
      language: {
        type: Sequelize.STRING(20),
        defaultValue: "NA"
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("country");
  }
};
