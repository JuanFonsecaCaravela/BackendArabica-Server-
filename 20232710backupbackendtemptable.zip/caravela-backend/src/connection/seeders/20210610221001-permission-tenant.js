'use strict';
const uuid = require("uuid/v4")
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Crear Tenant",
          slug: "create_tenant",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );
    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Editar Tenant",
          slug: "edit_tenant",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );
    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Inhabilitar Tenant",
          slug: "delete_tenant",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );
    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Agregar Administrador Tenant",
          slug: "admin_tenant",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
};
