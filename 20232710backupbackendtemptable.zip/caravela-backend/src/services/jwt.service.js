import jwt from 'jsonwebtoken'
import moment from 'moment-timezone'
import config from '../config/config'

const createToken = (user) => {
    try {
        const now = moment()
        const payload = {
            id: user.caravela_user_id,
            id_user: user.id,
            dni: user.dni,
            first_name: user.first_name,
            second_name: user.second_name,
            first_surname: user.first_surname,
            second_surname: user.second_surname,
            role: user.role,
            role_id: user.role_id,
            gender: user.gender.spanish_name,
            profile_image_url: user.profile_image_url,
            profile_image_name: user.profile_image_name,
            iat: now.unix(),
            exp: now.add(10, 'years').unix()
        }
        const token = jwt.sign(payload, config.secretJWT)
        return token
    } catch (error) {
        console.log('Hubo un error generando el token: ', error)
        return null
    }
}

const verifyToken = (req, res, next) => {
    try {
        const authHeader = req.headers.authorization

        if (!authHeader || authHeader == '') return res.status(400).send({ message: 'No cuenta con la cabecera de autenticación.' })

        const isBearer = authHeader.split(' ')[0]
        if (isBearer != 'Bearer') return res.status(400).send({ message: 'La cabecera de autenticación no es válida.' })

        const authToken = authHeader.split(' ')[1]
        if (!authToken || authToken == '') return res.status(400).send({ message: 'La cabecera de autenticación no es válida.' })

        const payload = jwt.verify(authToken, config.secretJWT)
        if (!payload) return res.status(400).send({ message: 'No tiene permiso para realizar esta operación.' })

        const now = moment()
        if (payload.exp < now.unix) {
            return res.status(400).send({ message: 'El token ha expirado.' })
        }
        next()

    } catch (error) {
        console.log('Hubo un error verificando el token: ', error)
        return res.status(400).send({ message: 'Hubo un error verificando el token o ha expirado. Inicie sesión nuevamente e intente de nuevo.' })
    }
}

const createTokenUser = ( uuid , role , dni  ) => {

    try {
        const now = moment();
        const payload = {
            uuid,
            role,
            dni,
            iat : now.unix(),
            exp : now.add(30, 'years').unix()
        }
        const token = jwt.sign(payload , config.secretJWT)
        return token;
    } catch (error) {
        console.log(`Hubo un error generando el token`);
        return false;
    }
}


const createTokenFarm =  ( user_id , farm_uuid , user_uuid  ) => {
        try {
            const now  = moment();
            const payload = {
                user_id,
                farm_uuid,
                user_uuid,
                iat : now.unix(),
                exp : now.add(30 , 'years').unix()
            }
            const token = jwt.sign( payload , config.secretJWT )
            return token;
            
        } catch (e) {
            console.log(`Hubo un error generando el token`);
            return false;
        }
}


const createTokenCodeQr = ( {uuid  , role } ) => {
    try {
        const now  = moment();
        const payload = {
            uuid,
            role,
            iat: now.unix(),
            exp: now.add(10, 'years').unix(),

        }
        const token = jwt.sign( payload , config.secretJWT )
        return  token;
    } catch (error) {
        console.log('Hubo un error generando el token para el codigo Qr: ', error)
        return null
    }

}
export default { 
    createToken, 
    verifyToken, 
    createTokenUser,
    createTokenFarm,
    createTokenCodeQr
 }

