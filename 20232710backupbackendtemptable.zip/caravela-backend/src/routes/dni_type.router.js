import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlDniType from '../controllers/dni_type.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlDniType.create);

router.put('/', verifyToken, ctrlDniType.update);

router.post('/all', verifyToken, ctrlDniType.findAll);

router.post('/id', verifyToken, ctrlDniType.findById);

router.delete('/:id', verifyToken, ctrlDniType.deleteOne);

export default router;