"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const department = sequelize.define(
    "department",
    {
      department_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      department_code: DataTypes.STRING,
      area_code: DataTypes.STRING,
      country_id: DataTypes.INTEGER,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
    },
    {
      freezeTableName: true,
      name: {
        singular: "department",
        plural: "department"
      }
    }
  );

  department.associate = function(models) {
    // associations can be defined here

    department.belongsTo(models.country, {
      foreignKey: { name: "country_id", allowNull: true }
    });

    department.hasMany(models.municipality, {
      foreignKey: { name: "department_id", allowNull: false }
    });
    department.hasMany(models.SurveyApply, {
      foreignKey: { name: "id_deparment", allowNull: true },
    });
  };
  sequelizePaginate.paginate(department);
  return department;
};
