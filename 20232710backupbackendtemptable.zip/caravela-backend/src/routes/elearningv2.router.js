import express from 'express';
//import jwtService from '../services/jwt.service';
import ctrlElearningv2 from '../controllers/elearningv2.controller';

const router = express.Router();

//const verifyToken = jwtService.verifyToken;


//////////CURSOS//////////
router.post('/create', ctrlElearningv2.create);
router.get('/see', ctrlElearningv2.findAllCourse);
router.get('/see/:id', ctrlElearningv2.findIdCourse);
router.delete('/remove/:id', ctrlElearningv2.removeCourse);
router.put('/update/:id', ctrlElearningv2.updateCourse);

//////////OBJETIVOS//////////
router.post('/createO/:id', ctrlElearningv2.createObjetive);
router.delete('/removeO/:id', ctrlElearningv2.removeObjectives);


//////////SESIONES//////////
router.post('/createS/:id', ctrlElearningv2.createSession);
router.delete('/removeS/:id', ctrlElearningv2.removeSession);



//////////TAREAS//////////
router.post('/createT/:id', ctrlElearningv2.createTask);
router.delete('/removeT/:id', ctrlElearningv2.removeTask);


/////////////////////////
router.post('/filters', ctrlElearningv2.filtros);








export default router;