'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const replyQuestion = sequelize.define (
    'replyQuestion',
    {
      unique_id: DataTypes.STRING,
      reply: DataTypes.STRING,
      date: DataTypes.DATE,
      hour: DataTypes.TIME,
      id_cost_Body: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      description: DataTypes.STRING,
      id_department: DataTypes.INTEGER,
      state_id: DataTypes.INTEGER,
      typeQuestion: DataTypes.INTEGER,
      resultFormula:DataTypes.BOOLEAN,
    },
    {
      freezeTableName: true,
      name: {
        singular: 'replyQuestion',
        plural: 'replyQuestion',
      },
    }
  );

  replyQuestion.associate = function (models) {
    replyQuestion.belongsTo (models.caravela_user, {
      foreignKey: {name: 'user_id', allowNull: false},
    });
    replyQuestion.belongsTo (models.cost_Body, {
      foreignKey: {name: 'id_cost_Body', allowNull: false},
    });
    replyQuestion.belongsTo (models.department, {
      foreignKey: {name: 'id_department', allowNull: false},
    });

    replyQuestion.hasMany (models.replyLog, {
      foreignKey: {name: 'id_replyQuestion', allowNull: false},
    });
  };
  sequelizePaginate.paginate (replyQuestion);
  return replyQuestion;
};
