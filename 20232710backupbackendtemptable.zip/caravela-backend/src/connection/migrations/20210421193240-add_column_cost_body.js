"use strict";

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([

        queryInterface.addColumn(
          "cost_Body",
          "measure_id",
          {
            type: Sequelize.DataTypes.INTEGER,
            references: {
              model: 'measure',
              key: 'id'
            },
            allowNull: true,
          },
          { transaction: t }
        ),

      ]);
    });
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  },
};
