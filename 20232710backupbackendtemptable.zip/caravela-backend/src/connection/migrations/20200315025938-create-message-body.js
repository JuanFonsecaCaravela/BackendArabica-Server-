"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("MessageBodies", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      unique_id: {
        type: Sequelize.STRING
      },
      message_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "MessageHeads",
          key: "id"
        }
      },
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },
      type_message: {
        type: Sequelize.INTEGER // 1- Text, 2- Img
      },
      type: {
        type: Sequelize.INTEGER // 1- Ingreso prodcutor, 2- Ingreso técnico, 3 - 
      },
      message: {
        type: Sequelize.STRING(500),
        allowNull: false
      },
      view_user_producer: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      date_view_user_producer: {
        type: Sequelize.DATE,
        allowNull: true
      },
      view_user_technical: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      date_view_user_technical: {
        type: Sequelize.DATE,
        allowNull: true
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("MessageBodies");
  }
};
