"use strict";

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("cost_Head", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      cost_Head_id: {
        type: Sequelize.STRING(255),
      },
      year: {
        type: Sequelize.STRING,


      },
      state_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'state',
          key: 'id'
        }
      },

      deleteAt: {
        allowNull: true,
        type: Sequelize.DATE
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("cost_Head");
  }
};
