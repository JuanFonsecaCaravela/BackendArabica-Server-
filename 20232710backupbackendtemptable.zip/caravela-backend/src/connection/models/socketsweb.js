'use strict';
module.exports = (sequelize, DataTypes) => {
  const SocketsWeb = sequelize.define('SocketsWeb', {
    unique_id: DataTypes.STRING,
    status: DataTypes.INTEGER,
    user_id: DataTypes.INTEGER,
    websocket: DataTypes.STRING,
  }, {});
  SocketsWeb.associate = function(models) {
    // associations can be defined here
  };
  return SocketsWeb;
};