"use strict"
import sequelizePaginate from "sequelize-paginate"
import capitalize from 'capitalize'
module.exports = (sequelize, DataTypes) => {
    const survey_type = sequelize.define(
        "survey_type", {
            survey_type_id: DataTypes.STRING,
            name: {
                type: DataTypes.STRING,
                set(value) {
                    this.setDataValue('name', value.toLowerCase())
                },
                get() {
                    const name = this.getDataValue('name')
                    return capitalize.words(name)
                },
            },
            state_id: DataTypes.INTEGER,
            deleteAt: DataTypes.DATE,
            id_tenant:DataTypes.INTEGER,
        }, {
            freezeTableName: true,
            name: {
                singular: "survey_type",
                plural: "survey_type"
            }
        }
    )
    survey_type.associate = function(models) {
        survey_type.hasMany(models.survey, {
            foreignKey: {
                name: "survey_type_id",
                allowNull: true
            },
        })
    }
    sequelizePaginate.paginate(survey_type)
    return survey_type
}