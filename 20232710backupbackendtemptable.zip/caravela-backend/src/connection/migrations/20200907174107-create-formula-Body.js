"use strict";

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("formula_Body", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },

      uuid: {
        type: Sequelize.STRING,
        defaultValue: "NA",

      },
      operator: {
        type: Sequelize.STRING,
        defaultValue: "NA",

      },
      term: {
        type: Sequelize.INTEGER,
        references: {
          model: 'cost_Body',
          key: 'id'
        }
      },
      id_formula_Head: {
        type: Sequelize.INTEGER,
        references: {
          model: 'formula_Head',
          key: 'id'
        }
      },

      state_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'state',
          key: 'id'
        }
      },
      deleteAt: {
        allowNull: true,
        type: Sequelize.DATE
      },

      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("formula_Body");
  }
};
