'use strict';
module.exports = (sequelize, DataTypes) => {
  const elearningv2 = sequelize.define('elearningv2', {
    course_id: DataTypes.STRING,
    title: DataTypes.STRING,
    category: DataTypes.STRING,
    elearningv2_session_id: DataTypes.INTEGER,
    maximumCapacity: DataTypes.STRING,
    trainingCycle: DataTypes.STRING,
    consecutiveCourse: DataTypes.STRING,
    TypeCourse: DataTypes.STRING,
    nameWhoOffers: DataTypes.STRING,
    accessLink: DataTypes.STRING,
    courseValidity: DataTypes.STRING,
    modality: DataTypes.STRING,
    Hourlyintensity: DataTypes.STRING,
    numberStars: DataTypes.STRING,
    strengthenKnowledge: DataTypes.STRING,
    description: DataTypes.STRING,
    loadFile: DataTypes.STRING,
    version: DataTypes.STRING,
    state_id: DataTypes.INTEGER,
    userCreate: DataTypes.INTEGER
  }, {});
  elearningv2.associate = function(models) {
    elearningv2.hasMany(models.elearningv2session, {
      foreignKey: { name: "course_id", allowNull: false }
}); 
elearningv2.hasMany(models.elearningv2Objetive, {
  foreignKey: { name: "course_id", allowNull: false }
});

  };
  return elearningv2;
};