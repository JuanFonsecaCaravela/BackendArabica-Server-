'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {

    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([
        queryInterface.addColumn(
          "question",
          "observation",
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "question",
          "descriptionPhotos",
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "question",
          "entrytext",
          {
            type: Sequelize.DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "question",
          "order_section",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: true
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "question",
          "section",
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true
          },
          { transaction: t }
        )
        
      ]);
    });
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  }
};
