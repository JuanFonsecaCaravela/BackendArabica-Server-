'use strict';
module.exports = (sequelize, DataTypes) => {
  const elearningv2session = sequelize.define('elearningv2session', {
    elearningv2_session_id: DataTypes.STRING,
    titleStage: DataTypes.STRING,
    description: DataTypes.STRING,
    id_elearningv2_Task_type: DataTypes.INTEGER,
    duration: DataTypes.INTEGER,
    typeduration: DataTypes.STRING,
    course_id: DataTypes.INTEGER,
    version: DataTypes.STRING,
    state_id: DataTypes.INTEGER,
    attached: DataTypes.STRING,
    video: DataTypes.STRING,
    img: DataTypes.STRING,
    text: DataTypes.STRING,
    questionnaire_id: DataTypes.INTEGER,
    questionnaire: DataTypes.STRING,
  }, {});
  elearningv2session.associate = function(models) {
    elearningv2session.belongsTo(models.elearningv2, {
      foreignKey: { name: "course_id", allowNull: false }
    });
    elearningv2session.hasMany(models.elearningv2Attached, {
      foreignKey: { name: "elearningv2_session_id", allowNull: false }
    });
  elearningv2session.hasMany(models.elearningv2Task, {
    foreignKey: { name: "elearningv2_session_id", allowNull: false }
  });
  elearningv2session.belongsTo(models.elearningv2TaskType, {
    foreignKey: { name: "id_elearningv2_Task_type", allowNull: true }
  });
  /*elearningv2session.hasMany(models.questionnaire, {
    foreignKey: { name: "questionnaire_id", allowNull: true }
  });*/


  };
  return elearningv2session;
};