import express from "express";
import jwtService from "../services/jwt.service";
import ctrlUser from "../controllers/user.controller";

//const { changePasswordUser } = require('../validations/user.validations.js');
import userValidations from "../validations/user.validations.js";

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.get(
  "/get-producer-technician/:version/:uuid",
  verifyToken,
  ctrlUser.getProducersTechv2
); // getProducersTech
router.get(
  "/get-producer-technicianv2/:version/:uuid",
  verifyToken,
  ctrlUser.getProducersTechv2
);

//coordinador
router.get(
  "/get-technician-coor/:version/:uuid/:coordid?",
  verifyToken,
  ctrlUser.getTechnicianCoor
);

router.get(
  "/get-producer-technician-id/:version/:uuid/:id",
  verifyToken,
  ctrlUser.getProducersTechByidV2
);

router.post("/caravela-creation-do-not-share", ctrlUser.createSuperadmin);

router.post("/producer", ctrlUser.createProducer);

router.post(
  "/change-password",
  [verifyToken, userValidations.changePasswordUser()],
  ctrlUser.changePasswordUser
);
router.post("/sendSMS", [verifyToken], ctrlUser.sendSMS);

router.post("/change-password-caravela-do-not-share", ctrlUser.changePassword);

router.post("/peca-tech", ctrlUser.createPecaTech);

router.post("/peca-coord", ctrlUser.createPecaCoord);

router.get(
  "/producer-profile/:id",
  verifyToken,
  ctrlUser.findProducerProfileById
);

router.get(
  "/producer-full-data/:id/:version/:uuid",
  verifyToken,
  ctrlUser.findProducerFullData
);

router.get(
  "/pecatech-profile/:id",
  verifyToken,
  ctrlUser.findPecaTechProfileById
);

router.post(
  "/search-user-dni",
  [userValidations.searchUserDNIValidation()],
  ctrlUser.searchUserDNI
);

router.get(
  "/pecatech-full-data/:id/:pecaPage/:pecaPageSize",
  verifyToken,
  ctrlUser.findPecaTechFullData
);
// coordinador
router.post(
  "/pecacoord-full-data/:id",
  verifyToken,
  ctrlUser.findPecaCoordFullData
);

router.get(
  "/pecacoord-full-data-byCountry/:id/:version/:uuid",
  verifyToken,
  ctrlUser.findPecaCoordFullDatabyCountry
);

router.get(
  "/pecatech-producers/:id/:pecaPage/:pecaPageSize",
  verifyToken,
  ctrlUser.findPecaTechProducers
);

router.get("/find-by-name", verifyToken, ctrlUser.findProducerByName);

router.get("/latest-producers", verifyToken, ctrlUser.findLatestProducers);

router.post("/save-users", verifyToken, ctrlUser.saveUsers);
router.post("/save-users-tech", verifyToken, ctrlUser.saveUsersTechnichian);

router.post("/save-familymembers", verifyToken, ctrlUser.saveFamilyMembers);

router.put("/", verifyToken, ctrlUser.update);

router.get("/all", verifyToken, ctrlUser.findAll);

router.get("/:id", verifyToken, ctrlUser.findById);

router.post("/login", ctrlUser.login);

router.post("/loginweb", ctrlUser.loginWeb);

router.delete("/:id", verifyToken, ctrlUser.deleteOne);

router.post(
  "/recovery-password",
  [userValidations.recoveryPasswordEmail()],
  ctrlUser.recoveryPasswordEmail
);

router.post(
  "/change-profle-picture",
  [verifyToken],
  ctrlUser.changeProfilePicture
);

router.post("/savetoken", [verifyToken], ctrlUser.saveTokenFirebase);

router.get("/get-user-by-auth/auth", [verifyToken], ctrlUser.getUserByAuth);

router.get("/dashboard/user", [verifyToken], ctrlUser.dashboard);

router.get("/atlas/save", [verifyToken], ctrlUser.AtlasService);

router.put("/total-points", verifyToken, ctrlUser.updateTotalPoints);

router.get("/microblink/get-config", verifyToken, ctrlUser.getMicroblink);
router.get("/get/codeQR", verifyToken, ctrlUser.getCodeQr);

router.get(
  "/getInformationToSyncProducer/:id",
  verifyToken,
  ctrlUser.getInformationToSyncProducer
);
router.post(
  "/getProducersTechSync",
  verifyToken,
  ctrlUser.getProducersTechSync
);
router.post("/restoreSync", [verifyToken], ctrlUser.restoreInformationSync);
router.post("/updateAjustes", ctrlUser.updateAjustes);
router.get("/getversion/appversionuser", ctrlUser.appVersionUserById);
router.put("/getversion/updateappversionuser", ctrlUser.updateAppVersion);

export default router;
