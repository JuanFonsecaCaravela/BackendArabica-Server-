"use strict"
import sequelizePaginate from "sequelize-paginate"
module.exports = (sequelize, DataTypes) => {
  const survey = sequelize.define(
    "survey",
    {
      categoria: DataTypes.STRING,
      version: DataTypes.INTEGER,
      estado: DataTypes.INTEGER,
      creator_user_id: DataTypes.STRING,
      description: DataTypes.STRING,
      unique_id: DataTypes.STRING,
      delete_user_id: DataTypes.STRING,
      delete_at: DataTypes.DATE,
      title: DataTypes.STRING,
      image: DataTypes.STRING,
      iddispositivo: DataTypes.STRING,
      date_ini: DataTypes.DATE,
      date_end: DataTypes.DATE,
      state_id: DataTypes.INTEGER,
      survey_type_id: DataTypes.INTEGER,
      restoreData: DataTypes.BOOLEAN,
      id_tenant:DataTypes.INTEGER,
      months_to_download:DataTypes.INTEGER
    },
    {
      freezeTableName: true,
      name: {
        singular: "survey",
        plural: "survey",
      },
    }
  )
  survey.associate = function (models) {
    // associations can be defined here

    this.hasMany(models.category, {
      foreignKey: { name: "surveyId", allowNull: true }
    })
    survey.hasMany(models.question, {
      foreignKey: { name: "survey_id", allowNull: false },
    })
    survey.hasMany(models.SurveyApply, {
      foreignKey: { name: "id_survey", allowNull: false },
    })

    survey.hasMany(models.answer_survey, {
      foreignKey: { name: "id_survey", allowNull: false },
    })

    survey.belongsTo(models.survey_type, {
      foreignKey: {
        name: "survey_type_id",
        allowNull: true
      },
    })
    survey.belongsTo(models.caravela_user, {
      foreignKey: {
        name: "creator_user_id",
        allowNull: false,
        as: "creator_survey",
      },
    })
  }
  sequelizePaginate.paginate(survey)
  return survey
}
