'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('QuestionnaireQuestionOptions', {
            id: {
              allowNull: false,
              autoIncrement: true,
              primaryKey: true,
              type: Sequelize.INTEGER
            },
            order: {
              type: Sequelize.INTEGER,
              allowNull: false
            },
            description: {
              type: Sequelize.STRING(200),
              allowNull: false,
              get: function() {
                return this.getDataValue("description");
              },
              set: function(value) {
                if (value && value != "")
                  this.setDataValue("description", capitalize.words(value));
              }
            },
            unique_id: {
              type: Sequelize.STRING(255), 
              allowNull: false
            },
            delete_user_id: {
              type: Sequelize.INTEGER,
              allowNull: true,
              references: {
                model: "caravela_user",
                key: "id"
              }
            },
            question_id: {
              type: Sequelize.INTEGER,
              allowNull: false,
              references: {
                model: "QuestionnaireQuestions",
                key: "id"
              }
            },
            delete_at: {
              type: Sequelize.DATE,
              allowNull: true
            },
            createdAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            updatedAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            version:{
              type: Sequelize.DataTypes.INTEGER,
              allowNull: true,
            },

          });
    },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('QuestionnaireQuestionOptions');
    }
};