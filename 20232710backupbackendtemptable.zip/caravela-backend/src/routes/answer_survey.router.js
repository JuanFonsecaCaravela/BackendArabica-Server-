import express from "express";
import jwtService from "../services/jwt.service";
import answer_survey from "../controllers/answer_survey.controller";

const router = express.Router();

// const verifyToken = jwtService.verifyToken;

router.post("/create", answer_survey.create);
router.post("/v2/create", answer_survey.createv2);
router.post("/v2/get-answers", answer_survey.getAnswersv2);
router.get("/all", answer_survey.findAll);
router.get(
  "/get-answer/associate/:version/:uuid",
  answer_survey.getAnswerbysurveyAssociate
);
router.get(
  "/get-answer/associate-pecaid/:id/:version/:uuid",
  answer_survey.getAnswerbysurveyAssociateByIdpeca
);
router.post("/get-answers", answer_survey.getAnswers);
router.post("/getSQL", answer_survey.getAnswersSQL);

router.post("/get-answersTec", answer_survey.getAnswersTec);

router.post("/get-answersPro", answer_survey.getAnswersPro);

router.post("/update-answers", answer_survey.setUpdateAnswerBody);

router.get("/find/:id", answer_survey.getAnswerByUUID);
router.get("/v2/find/:id", answer_survey.getAnswerByUUIDv2);
router.post("/v2/findBody", answer_survey.getAnswerBodyV2);
router.get("/v3/find/:id", answer_survey.getAnswerByUUIDv3);


router.get("/pdf/:id/:token/:tZ", answer_survey.getPdfUuidweb);
router.get("/pdf/:id/:token", answer_survey.getPdfUuid);

router.post("/updateAnswerApp", answer_survey.updateAnswerApp);

router.post("/missingAnswer", answer_survey.getAnswerMissing);

router.get("/getAllNotMandatoryQuestion/:id", answer_survey.getNotMandatoryquestion)
router.get("/updateMandatoryQuestion/:id", answer_survey.updateMandatoryquestion)
//get one year non-mandatory data
router.get("/getOneYearAllNotMandatoryQuestion/:id", answer_survey.getOneNotMandatoryquestion)
router.get("/updateOneYearMandatoryQuestion/:id", answer_survey.updateOneYearMandatoryquestion)

export default router;
