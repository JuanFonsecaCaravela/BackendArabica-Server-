'use strict';
module.exports = (sequelize, DataTypes) => {
  const SocketsWebConnection = sequelize.define('SocketsWebConnection', {
    unique_id: DataTypes.STRING,
    status: DataTypes.INTEGER,
    message_id: DataTypes.INTEGER,
    producer_ws_id: DataTypes.STRING,
    technical_ws_id: DataTypes.STRING,
  }, {});
  SocketsWebConnection.associate = function(models) {
    // associations can be defined here
  };
  return SocketsWebConnection;
};