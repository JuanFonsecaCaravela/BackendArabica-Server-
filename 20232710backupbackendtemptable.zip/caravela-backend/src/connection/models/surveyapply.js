'use strict';
module.exports = (sequelize, DataTypes) => {
  const SurveyApply = sequelize.define('SurveyApply', {
    id_country: DataTypes.INTEGER,
    id_deparment: DataTypes.INTEGER,
    id_survey: DataTypes.INTEGER
  }, {});
  SurveyApply.associate = function(models) {
    SurveyApply.belongsTo(models.survey, {
      foreignKey: { name: "id_survey", allowNull: false },
    });
    SurveyApply.belongsTo(models.country, {
      foreignKey: { name: "id_country", allowNull: false },
    });
    SurveyApply.belongsTo(models.department, {
      foreignKey: { name: "id_deparment", allowNull: true },
    });
  };
  return SurveyApply;
};