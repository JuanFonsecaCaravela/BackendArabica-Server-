import express from 'express'
import jwtService from '../services/jwt.service'
import ctrlVisit from '../controllers/visit.controller'

const router = express.Router()

const verifyToken = jwtService.verifyToken

router.post('/create', verifyToken, ctrlVisit.createVisits)

router.post('/', verifyToken, ctrlVisit.create)

router.get('/my-producer-visit-data/:id', verifyToken, ctrlVisit.getMyProducerVisitData)

router.get('/my-pecas-visit-data/:id', verifyToken, ctrlVisit.getMyPecasVisitData)

router.get('/producer-visit-data-peca-tech/:id', verifyToken, ctrlVisit.getProducerVisitDataFromPecaTech)

router.get('/my-visit-data-as-peca-tech/:id/:version/:uuid', verifyToken, ctrlVisit.getMyVisitDataAsPecaTech)

router.get('/my-visit-data-as-peca-pro/:id/:version/:uuid', verifyToken, ctrlVisit.getMyVisitDataAsPecaProducer)

router.post('/peca-tech', verifyToken, ctrlVisit.createAsPecaTech)

router.get('/rate/:id', verifyToken, ctrlVisit.getVisitsForRateAsProducer)

router.post('/ratings', verifyToken, ctrlVisit.saveVisitsRatingsAsProducer)
router.post('/save-visits', verifyToken, ctrlVisit.saveVisits)

router.get('/all/:id', verifyToken, ctrlVisit.findAllbyUser)

router.get('/all', verifyToken, ctrlVisit.findAll)

router.post('/by-producer-technical', verifyToken, ctrlVisit.FilterByProducerTechnical)

router.get('/user-visit/:id', verifyToken, ctrlVisit.UserVisitById)

router.post('/codeqr', verifyToken , ctrlVisit.FarmVisitQR);

export default router

