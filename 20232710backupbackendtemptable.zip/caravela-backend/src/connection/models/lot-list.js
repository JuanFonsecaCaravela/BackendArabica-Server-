'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const LotList = sequelize.define ('LotList', {
    unique_id: DataTypes.STRING,
    numberProducerBags: DataTypes.INTEGER,
    weigth: DataTypes.INTEGER,
    idLot: DataTypes.STRING,
    mainIdentifier: DataTypes.STRING,
    localIdentifier: DataTypes.STRING,
    weigthString: DataTypes.STRING,
    cuppingScore: DataTypes.STRING,
    rejectingReason: DataTypes.STRING,
    user_id: DataTypes.INTEGER,
    deleteAt: DataTypes.DATE,
  });
  LotList.associate = function (models) {
    LotList.belongsTo (models.caravela_user, {
      foreignKey: {name: 'user_id', allowNull: true},
    });
  };
  sequelizePaginate.paginate (LotList);
  return LotList;
};
