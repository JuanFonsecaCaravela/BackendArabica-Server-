"use strict";

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([
        queryInterface.addColumn(
          "question",
          "condicionation",
          {
            type: Sequelize.DataTypes.BOOLEAN,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "question",
          "id_condicionation",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: true,
            // references: {
            //   model: "question",
            //   key: "id",
            // },
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "question",
          "id_option_condicionation",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: true,
            // references: {
            //   model: "option_question",
            //   key: "id",
            // },
          },
          { transaction: t }
        ),
      ]);
    });
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  },
};
