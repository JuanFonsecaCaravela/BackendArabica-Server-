'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => { 
    return queryInterface.createTable('Producer_Location_Infos', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        // unique:true,
        type: Sequelize.INTEGER
      },
      producer_location_id: {
        type: Sequelize.STRING(255),  
        
      },
      wareHouse_Name: {
        type: Sequelize.STRING,
        
      },
      factor_base: {
        type: Sequelize.STRING
      },
      humidity: {
        type: Sequelize.STRING
      },
      contact1: {
        type: Sequelize.STRING
      },
      contact2: {
        type: Sequelize.STRING
      },
      wareHouseLocation_id: {
        type: Sequelize.INTEGER,
        onDelete: 'CASCADE',
        allowNull: true,   
        references: {
          model: "wareHouses",
          key: "id"
        }
      
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('Producer_Location_Infos');
  }
};