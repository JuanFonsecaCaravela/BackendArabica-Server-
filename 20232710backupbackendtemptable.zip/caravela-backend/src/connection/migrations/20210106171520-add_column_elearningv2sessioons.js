'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction (t => {
      return Promise.all ([
        queryInterface.addColumn (
          'elearningv2sessions',
          'video',
          {
            type: Sequelize.DataTypes.STRING
          },
          {transaction: t}
        ),
        
        queryInterface.addColumn (
          'elearningv2sessions',
          'img',
          {
            type: Sequelize.DataTypes.STRING(500.000)
          },
          {transaction: t}
        ),
        queryInterface.addColumn (
          'elearningv2sessions',
          'text',
          {
            type: Sequelize.DataTypes.STRING
          },
          {transaction: t}
        )

      ])
    })
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  }
};
