"use strict";
const uuid = require("uuid/v4");
module.exports = {
  up: async (queryInterface, Sequelize) => {
 


    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Control Arvenses",
          starting_week: 3,
          final_week: 5,
          color: "#D5B49E",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Fertilización",
          starting_week: 6,
          final_week: 8,
          color: "#EBC500",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Requerimiento Hídrico",
          starting_week: 7,
          final_week: 24,
          color: "#55C5E5",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Monitoreo Broca",
          starting_week: 8,
          final_week: 15,
          color: "#C7BCBB",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Mal rosado",
          starting_week: 8,
          final_week: 16,
          color: "#FFB1BB",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Monitoreo Roya",
          starting_week: 9,
          final_week: 13,
          color: "#FF9350",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Crítico Roya",
          starting_week: 13,
          final_week: 16,
          color: "#FF6D2D",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Mancha de hierro",
          starting_week: 15,
          final_week: 17,
          color: "#C86F58",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Crítico Broca",
          starting_week: 16,
          final_week: 22,
          color: "#938B8A",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Monitoreo de Roya",
          starting_week: 17,
          final_week: 23,
          color: "#FF9350",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );


    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Control Arvences",
          starting_week: 21,
          final_week: 23,
          color: "#D5B49E",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );



    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Monitoreo Broca",
          starting_week: 23,
          final_week: 27,
          color: "#C7BCBB",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Fertilización",
          starting_week: 24,
          final_week: 26,
          color: "#EBC500",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Ojo de gallo",
          starting_week: 28,
          final_week: 32,
          color: "#AF5C66",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Adecuación y Mantenimiento de Infraestructura Beneficio Húmedo",
          starting_week: 28,
          final_week: 32,
          color: "#D9C97F",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Monitoreo y control Araña Roja",
          starting_week: 28,
          final_week: 32,
          color: "#FF6F4A",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PlannerMasters",
      [
        {
          unique_id: uuid(),
          description: "Cosecha",
          starting_week: 32,
          final_week: 36,
          color: "#CE3D8E",
          required: true,
          visible: true,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
};
