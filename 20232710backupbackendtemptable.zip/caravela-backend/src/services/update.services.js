//import moment from 'moment-timezone'
import Sequelize from 'sequelize'
import db from '../connection/models/index'
const User = db.caravela_user
const Farm = db.farm
const refreshUser = async id => {
  try {
    const userFound = await User.findOne({ where: { id: id } })

    let date = new Date()

    userFound.set(
      {
        updatedAt: date
      },
      { raw: true }
    )
    await userFound.changed('updatedAt', true)
    const userUp = await userFound.save()
  } catch (error) {
    console.log('Hubo un error ', error)
    return null
  }
}

const refreshFarm = async id => {
  try {
    console.log('test entra')
    const farmFound = await Farm.findOne({ where: { id: id } })
  
    let date = new Date()

    farmFound.set(
      {
        updatedAt: date
      },
      { raw: true }
    )
    await farmFound.changed('updatedAt', true)
    const farmUp = await farmFound.save()
  } catch (error) {
    console.log('Hubo un error ', error)
    return null
  }
}

export default {
  refreshUser,
  refreshFarm
}
