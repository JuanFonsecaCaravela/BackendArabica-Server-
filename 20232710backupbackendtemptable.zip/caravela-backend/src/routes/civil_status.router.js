import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlCivilStatus from '../controllers/civil_status.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlCivilStatus.create);

router.put('/', verifyToken, ctrlCivilStatus.update);

router.post('/all', verifyToken, ctrlCivilStatus.findAll);

router.get('/:id', verifyToken, ctrlCivilStatus.findById);

router.delete('/:id', verifyToken, ctrlCivilStatus.deleteOne);

export default router;