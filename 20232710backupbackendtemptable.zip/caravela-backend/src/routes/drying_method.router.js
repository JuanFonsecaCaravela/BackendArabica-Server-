import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlDryingMethod from '../controllers/drying_method.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlDryingMethod.create);

router.put('/', verifyToken, ctrlDryingMethod.update);

router.post('/all', verifyToken, ctrlDryingMethod.findAll);

router.get('/:id', verifyToken, ctrlDryingMethod.findById);

router.delete('/:id', verifyToken, ctrlDryingMethod.deleteOne);

export default router;