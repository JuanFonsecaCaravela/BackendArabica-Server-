'use strict';
module.exports = (sequelize, DataTypes) => {
  const Productor_PECA = sequelize.define('Productor_PECA', {
    uuid: DataTypes.STRING,
    description_spanish: DataTypes.STRING,
    description_english: DataTypes.STRING,
    state_id: DataTypes.INTEGER
  }, {});
  Productor_PECA.associate = function(models) {
    // associations can be defined here
  };
  return Productor_PECA;
};