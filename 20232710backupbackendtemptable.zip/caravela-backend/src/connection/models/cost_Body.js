'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const cost_Body = sequelize.define (
    'cost_Body',
    {
      cost_Body_id: DataTypes.STRING,
      description: DataTypes.STRING,
      id_costCategory: DataTypes.INTEGER,
      id_cost_Head: DataTypes.INTEGER,
      colombia: DataTypes.STRING,
      ecuador: DataTypes.STRING,
      salvador: DataTypes.STRING,
      guatemala: DataTypes.STRING,
      mexico: DataTypes.STRING,
      nicaragua: DataTypes.STRING,
      peru: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      createdAt: DataTypes.DATE,
      deleteAt: DataTypes.DATE,
      orderBy: DataTypes.INTEGER,
      askProducer: DataTypes.BOOLEAN,
      required: DataTypes.BOOLEAN,
      typeReply: DataTypes.INTEGER,
      formula_Head_id: DataTypes.INTEGER,
      adder: DataTypes.BOOLEAN,
      validation: DataTypes.BOOLEAN,
      measure_id: DataTypes.INTEGER,
      observation: DataTypes.STRING,
    },
    {
      freezeTableName: true,
      name: {
        singular: 'cost_Body',
        plural: 'cost_Body',
      },
    }
  );

  cost_Body.associate = function (models) {
    cost_Body.belongsTo (models.measure, {
      foreignKey: {name: 'measure_id', allowNull: true},
    });
    cost_Body.belongsTo (models.costCategory, {
      foreignKey: {name: 'id_costCategory', allowNull: false}, 
    });
    cost_Body.belongsTo (models.cost_Head, {
      foreignKey: {name: 'id_cost_Head', allowNull: false},
    });
    cost_Body.belongsTo (models.formula_Head, {
      foreignKey: {name: 'formula_Head_id', allowNull: true},
    });
    cost_Body.hasOne (models.formula_Body, {
      foreignKey: {name: 'term', allowNull: false},
    });
    cost_Body.belongsToMany (models.caravela_user, {
      through: 'replyQuestion',
      foreignKey: {name: 'id_cost_Body', allowNull: false},
    });
    // cost_Body.belongsTo(models.state, {
    //   foreignKey: { name: "state_id", allowNull: false }
    // });
  };
  sequelizePaginate.paginate (cost_Body);
  return cost_Body;
};
