'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('elearningv2Tasks', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      elearningv2_Task_id: {
        type: Sequelize.STRING
      },
      title: {
        type: Sequelize.STRING
      },
      id_elearningv2_Task_type: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "elearningv2TaskTypes",
          key: "id",
        },
      },
      elearningv2_session_id: {
        type: Sequelize.INTEGER,
       references: {
          model: 'elearningv2sessions',
          key: 'id'
        }
      },
      description: {
        type: Sequelize.STRING
      },
      version: {
        type: Sequelize.STRING
      },
      state_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'state',
          key: 'id'
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('elearningv2Tasks');
  }
};