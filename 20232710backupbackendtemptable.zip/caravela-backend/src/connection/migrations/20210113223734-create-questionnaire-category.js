'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('questionnaire_categories', {
            id: {
              allowNull: false,
              autoIncrement: true,
              primaryKey: true,
              type: Sequelize.INTEGER
            },
            name: {
              type: Sequelize.STRING
            },
            description: {
              type: Sequelize.STRING
            },
            order: {
              type: Sequelize.INTEGER
            }, 
            surveyId: {
              type: Sequelize.INTEGER,
              allowNull: false,
              references: {
                model: "questionnaires",
                key: "id"
              }
            },
            createdAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            updatedAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            version:{
              type: Sequelize.DataTypes.INTEGER,
              allowNull: true,
            },
            id_category:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true,
            },
            uuid:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true,
            },
            id_condicionation:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true,
            },
            id_option_condicionation:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true,
            },
            condicionation:{
              type: Sequelize.DataTypes.BOOLEAN,
              allowNull: true,
            }
            

          })
        },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('questionnaire_categories');
    }
};