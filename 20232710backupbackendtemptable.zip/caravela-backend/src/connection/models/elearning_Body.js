"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const elearning_Body = sequelize.define(
    "elearning_Body",
    {
      elearning_Body_id: DataTypes.STRING,
      title: DataTypes.STRING,
      description: DataTypes.STRING,
      id_elearning_Head: DataTypes.INTEGER,
      createdAt: DataTypes.DATE,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      version: DataTypes.STRING,
     
    },
    {
      freezeTableName: true,
      name: {
        singular: "elearning_Body",
        plural: "elearning_Body"
      }
    }
  );

  elearning_Body.associate = function (models) {

     elearning_Body.belongsTo(models.elearning_Head, {
       foreignKey: { name: "id_elearning_Head", allowNull: false }
     });
     elearning_Body.hasMany(models.elearning_Task, {
       foreignKey: { name: "id_elearning_Body", allowNull: false }
     });
     elearning_Body.hasMany(models.elearning_Attached, {
      foreignKey: { name: "id_elearning_Body", allowNull: false }
    });
  };
  sequelizePaginate.paginate(elearning_Body);
  return elearning_Body;
};
