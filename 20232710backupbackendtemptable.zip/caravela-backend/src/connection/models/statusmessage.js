"use strict";
module.exports = (sequelize, DataTypes) => {
  const StatusMessage = sequelize.define(
    "StatusMessage",
    {
      unique_id: DataTypes.STRING,
      description: DataTypes.STRING
    },
    {}
  );
  StatusMessage.associate = function(models) {
    // associations can be defined here

    StatusMessage.hasMany(models.MessageHead, {
      foreignKey: { name: "status_id", allowNull: true }
    });

  };
  return StatusMessage;
};
