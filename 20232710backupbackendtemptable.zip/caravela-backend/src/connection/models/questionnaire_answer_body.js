'use strict';
module.exports = (sequelize, DataTypes) => {
    const questionnaire_answer_body = sequelize.define('questionnaire_answer_body', {
        unique_id: DataTypes.STRING,
        type: DataTypes.STRING,
        version: DataTypes.INTEGER,
        answer: DataTypes.STRING,
        id_answer: DataTypes.INTEGER,
        id_question: DataTypes.INTEGER,
      }, {});
      questionnaire_answer_body.associate = function(models) {
        // associations can be defined here
        questionnaire_answer_body.belongsTo(models.questionnaire_answer, {
          foreignKey: { name: "id_answer", allowNull: false }
        });
        questionnaire_answer_body.belongsTo(models.QuestionnaireQuestion, {
          foreignKey: { name: "id_question", allowNull: false }
        });
    };
    return questionnaire_answer_body;
};