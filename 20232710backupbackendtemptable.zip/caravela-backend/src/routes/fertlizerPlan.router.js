import express from "express";
import FertilizerPlanController from "../controllers/fertilizerPlan_controller";
const router = express.Router();
router.post('/addFertilizerAdjusta', FertilizerPlanController.addFertlzerAdjusta)
router.post('/getAllFertilizerAdjusta', FertilizerPlanController.getAllFertilizerAdjusta)
router.delete('/deleteFertiPlanAdjustaById/:fertiPlan_id', FertilizerPlanController.deleteFertilizerAdjusta)
router.get('/getFertilizerAdjustaById/:fertiPlan_id', FertilizerPlanController.getFertilizerAdjustaById)
router.put('/updateFertiAdjustaById', FertilizerPlanController.updateFertiAdjustaById)
router.post('/filterFertiAdjusta',FertilizerPlanController.filterFertiAdjusta)
router.get('/getFilterFertilizerAdjustaById/:ano', FertilizerPlanController.getFilterFertilizerAdjustaById)


router.post('/addRequirementFerti', FertilizerPlanController.addRequirementFerti)
router.post('/getAllRequirementFertiPaginate', FertilizerPlanController.getAllRequirementFertiPaginate)
router.get('/getAllRequirementFertiById/:requieFerti_id', FertilizerPlanController.getRequirementFertiById)
router.delete('/deleteRequirementFertiById/:requieFerti_id', FertilizerPlanController.deleteRequirementFerti)
router.put('/UpdateRequirementFerti', FertilizerPlanController.UpdateRequirementFerti)
//mobile
router.get("/getAllAgregarRequiremento/:id/:version/:uuid", FertilizerPlanController.getAllAgregarRequiremento)
router.post('/filterAgregarRequiremento',FertilizerPlanController.filterAgregarRequiremento)

//test
// router.get("/getAllAgregarRequiremento/:id/:version/:uuid", FertilizerPlanController.getAllAgregarRequirementoTest)

export default router;