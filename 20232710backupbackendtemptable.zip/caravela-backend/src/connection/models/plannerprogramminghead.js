"use strict"
import sequelizePaginate from "sequelize-paginate"
module.exports = (sequelize, DataTypes) => {
  const PlannerProgrammingHead = sequelize.define(
    "PlannerProgrammingHead",
    {
      date: DataTypes.DATEONLY,
      week: DataTypes.INTEGER,
      state: DataTypes.INTEGER,
      day: DataTypes.INTEGER,
      farm_id: DataTypes.INTEGER,
      plot_id: DataTypes.INTEGER,
      unique_id: DataTypes.STRING,
      month: DataTypes.INTEGER,
      year: DataTypes.INTEGER,
      version: DataTypes.INTEGER,
      flowering_qualities_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER
    },
    {}
  )
  PlannerProgrammingHead.associate = function (models) {
    // associations can be defined here

    PlannerProgrammingHead.hasMany(models.PlannerProgrammingBody, {
      foreignKey: { name: "planner_programming_head_id", allowNull: false }
    })

    PlannerProgrammingHead.belongsTo(models.FloweringQuality, {
      foreignKey: { name: "flowering_qualities_id", allowNull: false }
    })

    PlannerProgrammingHead.belongsTo(models.plot, {
      foreignKey: { name: "plot_id", allowNull: true }
    })

    PlannerProgrammingHead.belongsTo(models.farm, {
      foreignKey: { name: "farm_id", allowNull: false }
    })
  }
  sequelizePaginate.paginate(PlannerProgrammingHead)
  return PlannerProgrammingHead
}
