var moment = require("moment-timezone");


module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("visit", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      visit_id: {
        type: Sequelize.STRING
      },
      visit_date: {
        type: Sequelize.DATE,
        defaultValue: moment('01/01/1800', 'DD/MM/YYYY').toISOString()
      },
      not_want_rate: {
        type: Sequelize.BOOLEAN,
        defaultValue: null
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      visit_type_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "visit_type",
          key: "id"
        }
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("visit");
  }
};
