"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const log = sequelize.define(
    "log",
    {
      unique_id: DataTypes.STRING,
      uuid_user: DataTypes.INTEGER,
      type_log_id: DataTypes.INTEGER,
      date_log: DataTypes.STRING,
      log: DataTypes.STRING,
      id_element: DataTypes.STRING,
    },
    {}
  );
  log.associate = function (models) {
    log.belongsTo(models.type_log, {
      foreignKey: { name: "type_log_id", allowNull: false },
    });
    log.belongsTo(models.caravela_user, {
      foreignKey: { name: "uuid_user", allowNull: false },
    });
  };
  sequelizePaginate.paginate(log);
  return log;
};
