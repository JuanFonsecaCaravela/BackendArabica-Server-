import express from "express";
import FertilizerController from "../controllers/fertilizer.controller";
const router = express.Router();

 router.post('/addFertilizer', FertilizerController.addFertilizer)
 router.get('/getAllFertilizer', FertilizerController.getAllFertilizer)
 router.post('/getAllFertilizerPaginate', FertilizerController.getAllFertilizerPagenate)
 router.delete('/deleteFertilizerById/:ferti_id', FertilizerController.deleteFertilizerById)
 router.put("/updateFerlizer", FertilizerController.updateFertilzer)
 router.get("/getFertilizerByID/:ferti_id",FertilizerController.getfertilizerById)
 router.get("/getFilterFertilizerByID/:ferti_id",FertilizerController.getFilterFertilizerByID)
 router.post('/filterFertilizer',FertilizerController.filterFertilizer)
//mobile
 router.get("/getAllFertilizerMob/:id/:version/:uuid", FertilizerController.getAllFertilizerMob)
 router.get("/getAllFertilizerAdjustaMob/:id/:version/:uuid", FertilizerController.getAllFertilizerAdjustaMob)

export default router;