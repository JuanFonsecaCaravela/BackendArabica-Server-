'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('logs', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      unique_id: {
        type: Sequelize.STRING
      },
      uuid_user:{
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      type_log_id:{
        type: Sequelize.INTEGER
      },
      date_log:{
        type: Sequelize.STRING
      },
      log:{
        type: Sequelize.STRING(3000),
      },
      id_element:{
        type: Sequelize.STRING,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('logs');
  }
};