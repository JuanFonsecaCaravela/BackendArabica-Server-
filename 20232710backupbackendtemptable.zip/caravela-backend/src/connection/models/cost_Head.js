"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const cost_Head = sequelize.define(
    "cost_Head",
    {
      cost_Head_id: DataTypes.STRING,
      //title: DataTypes.STRING,
      year: DataTypes.STRING,
      deleteAt: DataTypes.DATE,
      state_id: DataTypes.INTEGER,
      orderBy :DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "cost_Head",
        plural: "cost_Head"
      }
    }
  );

  cost_Head.associate = function (models) {


    cost_Head.hasMany(models.cost_Body, {
      foreignKey: { name: "id_cost_Head", allowNull: false }
    });

  };
  sequelizePaginate.paginate(cost_Head);
  return cost_Head;
};
