"use strict";
module.exports = (sequelize, DataTypes) => {
  const farm_procces_type = sequelize.define(
    "farm_procces_type",
    {
      farm_id: DataTypes.INTEGER,
      process_type_id: DataTypes.INTEGER,
      unique_id : DataTypes.STRING,
      state_id: DataTypes.INTEGER
    },
    {
      freezeTableName: true,
      name: {
        singular: "farm_procces_type",
        plural: "farm_procces_type"
      }
    }
  );
  farm_procces_type.associate = function(models) {
    farm_procces_type.belongsTo(models.farm, {
      foreignKey: { name: "farm_id", allowNull: false }
    });
    farm_procces_type.belongsTo(models.process_type, {
      foreignKey: { name: "process_type_id", allowNull: false }
    });
  };
  return farm_procces_type;
};
