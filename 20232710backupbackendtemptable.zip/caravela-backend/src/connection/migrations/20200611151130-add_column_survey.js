'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.sequelize.transaction((t) => {
            return Promise.all([
                queryInterface.addColumn(
                    "survey",
                    "state_id", {
                        type: Sequelize.DataTypes.INTEGER,
                        defaultValue: 1,
                        allowNull: true,
                        references: {
                            model: "state",
                            key: "id",
                        },
                    }, { transaction: t }
                ),
                queryInterface.addColumn(
                    "survey",
                    "deleteAt", {
                        type: Sequelize.DataTypes.DATE,
                        allowNull: true,

                    }, { transaction: t }
                )
            ]);
        });
    },

    down: (queryInterface, Sequelize) => {
        /*
          Add reverting commands here.
          Return a promise to correctly handle asynchronicity.

          Example:
          return queryInterface.dropTable('users');
        */
    }
};