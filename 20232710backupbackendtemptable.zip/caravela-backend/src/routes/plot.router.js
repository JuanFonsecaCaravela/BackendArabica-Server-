import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlPlot from '../controllers/plot.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', verifyToken, ctrlPlot.create);

router.delete('/:id', verifyToken, ctrlPlot.deleteOne);

router.get('/all/:id', verifyToken, ctrlPlot.findAllByFarmId);

router.get('/producer_id/:id', verifyToken, ctrlPlot.findAllByUserId);

router.get('/:id', verifyToken, ctrlPlot.findById);

router.post('/save-plots', verifyToken, ctrlPlot.savePlots);

router.post('/save-plotsshadetrees', verifyToken, ctrlPlot.savePlotShareTree);

router.post('/save-plotrenovation', verifyToken, ctrlPlot.savePlotRenovationType);

router.put('/', verifyToken, ctrlPlot.update);

router.delete("/remove/:id", verifyToken, ctrlPlot.Remove);

export default router;