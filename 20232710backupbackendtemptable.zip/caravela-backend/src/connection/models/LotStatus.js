'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const StateLot = sequelize.define (
    'StateLot',
    {
      StatusLot: DataTypes.STRING,
    },
    {
      freezeTableName: true,
      name: {
        singular: 'StateLot',
        plural: 'StateLot',
      },
    }
  );
  StateLot.associate = function (models) {
    // associations can be defined here
  };

  sequelizePaginate.paginate (StateLot);

  return StateLot;
};
