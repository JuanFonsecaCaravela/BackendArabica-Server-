"use strict"
module.exports = (sequelize, DataTypes) => {
  const option_question = sequelize.define(
    "option_question",
    {
      order: DataTypes.INTEGER,
      description: DataTypes.STRING,
      unique_id: DataTypes.STRING,
      question_id: DataTypes.INTEGER,
      version: DataTypes.INTEGER
    },
    {
      freezeTableName: true,
      name: {
        singular: "option_question",
        plural: "option_question"
      }
    }
  )
  option_question.associate = function (models) {
    // associations can be defined here

    option_question.belongsTo(models.question, {
      foreignKey: { name: "question_id", allowNull: false }
    })

  }
  return option_question
}
