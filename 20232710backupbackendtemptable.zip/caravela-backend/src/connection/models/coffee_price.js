'use strict';
module.exports = (sequelize, DataTypes) => {
  const coffee_price = sequelize.define('coffee_price', {
    coffee_prices_id: DataTypes.STRING,
    quality: DataTypes.STRING,
    score_cup: DataTypes.STRING,
    price: DataTypes.STRING,
    location_id: DataTypes.INTEGER
  }, {});
  coffee_price.associate = function(models) {
    coffee_price.belongsTo(models.Producer_Location_Info,{
      foreignKey: { name: "location_id", allowNull: false },
      onDelete: "CASCADE",
    })
  };
  return coffee_price;
};

//nitish