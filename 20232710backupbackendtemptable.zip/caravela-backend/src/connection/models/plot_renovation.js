"use strict";
module.exports = (sequelize, DataTypes) => {
  const plot_renovation = sequelize.define(
    "plot_renovation",
    {
      unique_id: DataTypes.STRING,
      dates: DataTypes.STRING,
      plot_id: DataTypes.INTEGER,
      renovation_type_id: DataTypes.INTEGER,      
      deleteAt: DataTypes.DATE,
    },
    {
      freezeTableName: true,
      name: {
        singular: "plot_renovation",
        plural: "plot_renovation"
      }
    }
  );
  plot_renovation.associate = function(models) {
    plot_renovation.belongsTo(models.plot , {
      foreignKey: { name: "plot_id", allowNull: false }
    });
    plot_renovation.belongsTo(models.renovation_type , {
      foreignKey: { name: "renovation_type_id", allowNull: false }
    });
  };
  return plot_renovation;
};
