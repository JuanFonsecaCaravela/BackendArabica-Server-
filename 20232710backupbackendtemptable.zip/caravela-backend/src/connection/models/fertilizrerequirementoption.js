'use strict';
module.exports = (sequelize, DataTypes) => {
  const fertilizreRequirementOption = sequelize.define('fertilizreRequirementOption', {
    option: DataTypes.STRING,
    fertilizreRequirement_id: DataTypes.INTEGER
  }, {});
  fertilizreRequirementOption.associate = function(models) {
    fertilizreRequirementOption.belongsTo(models.fertilizreRequirement,{
      foreignKey: { name: "fertilizreRequirement_id", allowNull: false },
      onDelete: "CASCADE",
    })
  };
  return fertilizreRequirementOption;
};