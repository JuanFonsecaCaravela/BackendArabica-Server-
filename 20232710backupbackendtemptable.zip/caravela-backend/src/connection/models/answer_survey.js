"use strict"
import sequelizePaginate from "sequelize-paginate"
module.exports = (sequelize, DataTypes) => {
  const answer_survey = sequelize.define(
    "answer_survey",
    {
      unique_id: DataTypes.STRING,
      producer: DataTypes.STRING,
      version: DataTypes.INTEGER,
      farm: DataTypes.STRING,
      plot: DataTypes.STRING,
      location: DataTypes.STRING,
      date: DataTypes.STRING,
      id_survey: DataTypes.INTEGER,
      id_producer: DataTypes.INTEGER,
      id_technician: DataTypes.INTEGER,
      versionApp: DataTypes.STRING,
      creatorRoleType: DataTypes.STRING
    },
    {}
  )
  answer_survey.associate = function (models) {
    // associations can be defined here
    answer_survey.belongsTo(models.survey, {
      foreignKey: { name: "id_survey", allowNull: false },
    })
    answer_survey.hasMany(models.AnswerBody, {
      foreignKey: { name: "id_answer", allowNull: false },
    })

    answer_survey.belongsTo(models.caravela_user, {
      as: 'Producer',
      foreignKey: { name: "id_producer", allowNull: false },
    })

    answer_survey.belongsTo(models.caravela_user, {
      as: 'Technician',
      foreignKey: { name: "id_technician", allowNull: false },
    })
  }
  sequelizePaginate.paginate(answer_survey)
  return answer_survey
}
