import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlOptionsList from '../controllers/optionslist.controller';
import OptionsListValidations from '../validations/optionslist.validations';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/create',[verifyToken,OptionsListValidations.create()], ctrlOptionsList.create);
router.put('/update',[verifyToken,OptionsListValidations.update()], ctrlOptionsList.update);
router.delete('/delete/:uuid',[verifyToken], ctrlOptionsList.deleteFuntion);
router.post('/list',[verifyToken,OptionsListValidations.findAll()], ctrlOptionsList.findAll);
router.get('/find/:uuid',[verifyToken], ctrlOptionsList.find);
router.post('/filterCtrlOptionsList',ctrlOptionsList.filterCtrlOptionsList)


export default router;

