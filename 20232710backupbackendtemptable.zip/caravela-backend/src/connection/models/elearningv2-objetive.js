'use strict';
module.exports = (sequelize, DataTypes) => {
  const elearningv2Objetive = sequelize.define('elearningv2Objetive', {
    elearningv2_Objective_id: DataTypes.STRING,
    objective: DataTypes.STRING,
    course_id: DataTypes.INTEGER,
    version: DataTypes.STRING,
    state_id: DataTypes.INTEGER
  }, {});
  elearningv2Objetive.associate = function(models) {
    elearningv2Objetive.belongsTo(models.elearningv2, {
      foreignKey: { name: "course_id", allowNull: false }
    });

  };
  return elearningv2Objetive;
};