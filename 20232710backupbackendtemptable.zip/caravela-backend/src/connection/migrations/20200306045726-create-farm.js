"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("farm", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      farm_id: {
        type: Sequelize.STRING(255),
      },
      name: {
        type: Sequelize.STRING(100),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("name");
        },
        set: function(value) {
          this.setDataValue("name", capitalize.words(value));
        }
      },
      location: {
        type: Sequelize.STRING(100),
        defaultValue: "NA"
      },
      gps_longitude: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
      },
      gps_latitude: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
      },
      masl_height: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
      },
      total_area: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
      },
      total_coffee_area: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
      },
      total_coffee_productive_area: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
      },
      total_coffee_renovation_area: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
      },
      has_certifications: {
        type: Sequelize.BOOLEAN,
        defaultValue: false
      },
      harvest_period: {
        type: Sequelize.ARRAY(Sequelize.RANGE(Sequelize.DATE)),
        defaultValue: []
      },
      flycrop_period: {
        type: Sequelize.ARRAY(Sequelize.RANGE(Sequelize.DATE)),
        defaultValue: []
      },
      village: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("village");
        },
        set: function(value) {
          this.setDataValue("village", capitalize.words(value));
        }
      },
      notes: {
        type: Sequelize.TEXT,
        defaultValue: "NA"
      },
      media: {
        type: Sequelize.JSONB,
        defaultValue: {}
      },
      plots_number: {
        type: Sequelize.INTEGER,
        defaultValue: 0
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "caravela_user",
          key: "id"
        }
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("farm");
  }
};
