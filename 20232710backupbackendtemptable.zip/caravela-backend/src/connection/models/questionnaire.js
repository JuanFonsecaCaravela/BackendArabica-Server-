'use strict';
import sequelizePaginate from 'sequelize-paginate';

module.exports = (sequelize, DataTypes) => {
    const questionnaire = sequelize.define('questionnaire',   {
      categoria: DataTypes.STRING,
      version: DataTypes.INTEGER,
      estado: DataTypes.INTEGER,
      creator_user_id: DataTypes.STRING,
      description: DataTypes.STRING,
      unique_id: DataTypes.STRING,
      delete_user_id: DataTypes.STRING,
      delete_at: DataTypes.DATE,
      title: DataTypes.STRING,
      image: DataTypes.STRING,
      iddispositivo: DataTypes.STRING,
      date_ini: DataTypes.DATE,
      date_end: DataTypes.DATE,
      state_id: DataTypes.INTEGER,
      survey_type_id: DataTypes.INTEGER,
      restoreData: DataTypes.BOOLEAN
    },
    {
      /*freezeTableName: true,
      name: {
        singular: "questionnaire",
        plural: "questionnaire",
      },*/
    }
  )
  questionnaire.associate = function (models) {
    // associations can be defined here

    questionnaire.hasMany(models.questionnaire_category, {
      foreignKey: { name: "surveyId", allowNull: true }
    })
    questionnaire.hasMany(models.QuestionnaireQuestion, {
      foreignKey: { name: "survey_id", allowNull: false },
    })
    questionnaire.hasMany(models.questionnaireApply, {
      foreignKey: { name: "id_survey", allowNull: false },
    })

    questionnaire.hasMany(models.questionnaire_answer, {
      foreignKey: { name: "id_survey", allowNull: false },
    })

    questionnaire.belongsTo(models.questionnaire_type, {
      foreignKey: { name: "survey_type_id", allowNull: true},
    })
    questionnaire.belongsTo(models.caravela_user, {
      foreignKey: {
        name: "creator_user_id",
        allowNull: false,
        as: "creator_survey",
      },
    })
    questionnaire.hasMany(models.elearningv2session, {
      foreignKey: { name: "questionnaire_id", allowNull: true }
    });

    };
    sequelizePaginate.paginate(questionnaire);

    return questionnaire;
};