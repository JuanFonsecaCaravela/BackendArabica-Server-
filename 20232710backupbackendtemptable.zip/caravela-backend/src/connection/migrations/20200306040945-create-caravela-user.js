"use strict";
var moment = require("moment");
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("caravela_user", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      caravela_user_id: {
        type: Sequelize.STRING(255)
      },
      dni: {
        type: Sequelize.STRING(50),
        defaultValue: "NA"
      },
      role: {
        type: Sequelize.STRING(100),
        defaultValue: "NA"
      },
      first_name: {
        type: Sequelize.STRING(30),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("first_name");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("first_name", capitalize.words(value));
        }
      },
      second_name: {
        type: Sequelize.STRING(30),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("second_name");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("second_name", capitalize.words(value));
        }
      },
      first_surname: {
        type: Sequelize.STRING(30),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("first_surname");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("first_surname", capitalize.words(value));
        }
      },
      second_surname: {
        type: Sequelize.STRING(30),
        defaultValue: "NA",
        get: function() {
          return this.getDataValue("second_surname");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("second_surname", capitalize.words(value));
        }
      },
      password: {
        type: Sequelize.STRING(255),
        defaultValue: "NA"
      },
      birthdate: {
        type: Sequelize.DATEONLY
      },
      address: {
        type: Sequelize.STRING(255),
        defaultValue: "NA"
      },
      cellphone: {
        type: Sequelize.STRING(30),
        defaultValue: "NA"
      },
      email: {
        type: Sequelize.STRING(150),
        defaultValue: "NA"
      },
      has_assigned_technician: {
        type: Sequelize.BOOLEAN,
        defaultValue: false
      },
      has_association: {
        type: Sequelize.BOOLEAN,
        defaultValue: false
      },
      society_name: {
        type: Sequelize.STRING(255),
        defaultValue: "NA"
      },
      user_approved: {
        type: Sequelize.BOOLEAN,
        defaultValue: false
      },
      terms_accepted: {
        type: Sequelize.BOOLEAN,
        defaultValue: false
      },
      tokenFirebase: {
        type: Sequelize.Sequelize.STRING(255),
        allowNull: true,
      },
      profile_image_url: {
        type: Sequelize.STRING(500),
        defaultValue: null
      },
      profile_image_name: {
        type: Sequelize.STRING(500),
        defaultValue: null
      },
      status: {
        type: Sequelize.INTEGER,
        defaultValue: 1
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      civil_status_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "civil_status",
          key: "id"
        }
      },

      dni_type_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "dni_type",
          key: "id"
        }
      },

      gender_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "gender",
          key: "id"
        }
      },

      municipality_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "municipality",
          key: "id"
        }
      },

      user_type_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "user_type",
          key: "id"
        }
      },

      boss: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },

      technician_assigned_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "caravela_user",
          key: "id"
        }
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("caravela_user");
  }
};
