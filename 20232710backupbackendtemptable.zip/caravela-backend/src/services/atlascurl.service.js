var axios = require("axios");
import momentTimezone from "moment-timezone/moment-timezone";
import db from "../connection/models/index";
import jwtServiceAtlas from "./jwt.atlas.service";
import moment from "moment-timezone";
import uuid from "uuid/v4";

//production
let url = "https://atlas.caravela.coffee/api/arabica/";

const url2 =
  "https://atlas.caravela.coffee/api/business/statistics/v1/purchased_lots/";
//development
// const url = 'https://atlas-beta.9e-staging.cloud/api/arabica/'
const Op = db.Sequelize.Op;
const Country = db.country;
const NicLots = db.NicLot;
const Users = db.caravela_user;
const Department = db.department;
const Municipality = db.municipality;

const methodAxios = async (url, token, params, method) => {
  try {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    var config = {
      method: method,
      url: url,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        "Accept-Language": "es",
      },
      data: params,
    };

    return await axios(config)
      .then(async function (response) {
        let res = {
          statusCode: response.status,
          data: JSON.stringify(response.data.data),
          headers: JSON.stringify(response.headers),
          token,
          type: method,
          params: JSON.stringify(params),
        };
        await saveData(res);
        //   console.log (response);
        return {
          statusCode: response.status,
          date: JSON.stringify(response.data), // para  https://atlas.caravela.coffee/api/business/statistics/v1/purchased_lots
          data: JSON.stringify(response.data.data),
        };
      })
      .catch(async function (error) {
        console.log({ error }, "methodAxios");
        if (error.response.status === 403) {
          let res = {
            statusCode: error.response.status,
            data: JSON.stringify(error.request.data),
            headers: JSON.stringify(error.response.headers),
            token,
            type: method,
            params: JSON.stringify(params),
          };
          saveData(res);
          await db.TokenAtlas.update(
            { expirationDate: db.Sequelize.fn("NOW") },
            {
              where: {
                expirationDate: {
                  [Op.is]: null,
                },
              },
            }
          );
          let tokenNew = await getToken();
          methodAxios(url, tokenNew, params, method);
        }
        if (error.response.status === 400) {
          let res = {
            statusCode: error.response.status,
            data: JSON.stringify(error.response.data),
            headers: JSON.stringify(error.response.headers),
            token,
            type: method,
            params: JSON.stringify(params),
          };
          saveData(res);
        }
        if (error.response.status === 500) {
          console.log(error);
        }
        return {
          statusCode: error.response.status,
          data: JSON.stringify(error.request.data),
        };
      });
  } catch (error) {
    console.log(error);
    return false;
  }
};

const saveData = async (rta) => {
  await db.DataResponseAtlas.create({
    token: rta.token,
    type: rta.type,
    datasend: rta.params,
    dataresponse: rta.data,
    statuscode: rta.statusCode,
  });
};
const getToken = async () => {
  try {
    const TokenActive = await db.TokenAtlas.findOne({
      where: {
        expirationDate: {
          [Op.is]: null,
        },
      },
    });
    if (!TokenActive) {
      await db.TokenAtlas.update(
        { expirationDate: db.Sequelize.fn("NOW") },
        {
          where: {
            expirationDate: {
              [Op.is]: null,
            },
          },
        }
      );
      let token = await jwtServiceAtlas.createTokenAtlas();
      const SaveTokenActive = await db.TokenAtlas.create({
        token,
      });
      if (!SaveTokenActive) throw new Error("No se guardo el token");
      return token;
    } else {
      return TokenActive.token;
    }
  } catch (error) {
    console.log({ error });
    return false;
  }
};

const getProducer = async () => {
  try {
    let token = await getToken();
    if (token === false) {
      throw new Error("No se guardo el token");
    }
    return await methodAxios(
      "https://atlas.caravela.coffee/api/arabica/v1/producers/1",
      token,
      "",
      "get"
    );
  } catch (error) {
    console.log(error);
    return error;
  }
};

const setProducer = async (params, token) => {
  try {
    console.log("${url}", url);
    let showproducer = await showProducer(params.producer.arabicaId, token);
    console.log("REPONSE show-", showproducer);
    if (showproducer === 404) {
      console.log("CREATE PRO");
      let createProducer = await methodAxios(
        `${url}v1/producers`,
        token,
        params,
        "post"
      );
      return createProducer.statusCode;
    } else if (showproducer === 200) {
      console.log("UPDATE PRO");
      let updateProducer = await methodAxios(
        `${url}v1/producers/${params.producer.arabicaId}`,
        token,
        params,
        "put"
      );
      return updateProducer.statusCode;
    }
  } catch (error) {
    return error;
  }
};

const showProducer = async (idproducer, token) => {
  let Peticion = await methodAxios(
    `${url}v1/producers/${idproducer}`,
    token,
    "",
    "get"
  );
  return Peticion.statusCode;
};
const showFarm = async (idFarm, token) => {
  let Peticion = await methodAxios(
    `${url}v1/farms/${idFarm}`,
    token,
    "",
    "get"
  );
  return Peticion.statusCode;
};
const setFarmAndProducer = async (idFarm, idProducer, farmAssociateBoolean, idProducerAssociate) => {
  try {
    // Consulta la URl a publicar
    const isTest = await db.Configuration.findOne({
      attributes: ["value"],
      where: {
        name: {
          [Op.like]: "atlasTEST",
        },
      },
    });
    console.log("VALUE TEST:" + isTest.value);
    if (isTest.value) {
      console.log("------------------------------------ ATLAS TEST");
      const urlSta = await db.Configuration.findOne({
        attributes: ["valueText"],
        where: {
          name: {
            [Op.like]: "urlAtlasSTAGING",
          },
        },
      });
      url = urlSta.valueText;
    } else {
      console.log("------------------------------------ NOT ----- ATLAS TEST");
      const usrProd = await db.Configuration.findOne({
        attributes: ["valueText"],
        where: {
          name: {
            [Op.like]: "urlAtlasPROD",
          },
        },
      });
      url = usrProd.valueText;
    }
    console.log(url);

    let paramsFarm = await getParamsFarmAtlas(idFarm, idProducer , farmAssociateBoolean, idProducerAssociate);
    console.log('DATA', paramsFarm);
    if (paramsFarm.data == "farm") {
      console.log("-------------------- Error name farm ------------");
      const data = {
        error: "Error name farm",
        data: paramsFarm,
      };
      return data;
    } else {
      if (!isEmptyObject(paramsFarm)) {

        let paramsProducer = null;
        if(farmAssociateBoolean) {
          paramsProducer = await getParamsProducerAtlas(idProducerAssociate);
        } else {
          paramsProducer = await getParamsProducerAtlas(idProducer);
        }
         
        let token = await getToken();
        if (token === false) {
          throw new Error("No se guardo el token");
        }
        if (paramsProducer == null) {
          let res = {
            statusCode: 401,
            data: "---- Error prodcuer ------",
            token: token,
            type: "ERROR",
            params: JSON.stringify({
              producer: {
                id_prodcuer: idProducer,
              },
            }),
          };
          saveData(res);
          console.log("-------------------- Error producer ------------");
          return "Error producer";
        } else {
          let ProducerStatus = await setProducer(paramsProducer, token);
          if (ProducerStatus === 200) {
            let FarmStatus = await setFarm(paramsFarm, token);
            if (FarmStatus === 200) {
              return "ok todo";
            } else {
              return "Error con la farm";
            }
          } else {
            return "Error con el producer";
          }
        }
      } else {
        console.log("-------------------- Error name farm ------------");
        const data = {
          error: "Error name farm",
          data: isEmptyObject(paramsFarm),
        };
        return data;
      }
    }
  } catch (error) {
    console.log(error);
  }
};
const setFarm = async (params, token) => {
  try {
    let showfarm = await showFarm(params.farm.arabicaId, token);
    if (showfarm === 200) {
      let updateFarm = await methodAxios(
        `${url}v1/farms/${params.farm.arabicaId}`,
        token,
        params,
        "put"
      );
      return updateFarm.statusCode;
    } else if (showfarm === 404) {
      let createFarm = await methodAxios(
        `${url}v1/farms`,
        token,
        params,
        "post"
      );
      return createFarm.statusCode;
    }
  } catch (error) {
    return error;
  }
};
const fermentationName = (name) => {
  switch (name) {
    case "Agua":
      return "Water";
      break;

    default:
      return name;
      break;
  }
};
const ProcessName = (name) => {
  switch (name) {
    case "Semi Lavado":
      return "Semiwashed";
      break;
    case "Lavado":
      return "Washed";
      break;

    default:
      return name;
      break;
  }
};
const getParamsProducerAtlas = async (id_user) => {
  try {
    db.sequelize.options.logging = true;
    const userFound = await db.caravela_user.findOne({
      where: { id: id_user, state_id: 1, from_technician: true },
      include: [
        {
          model: db.municipality,
          attributes: ["codigo"],
          required: false,
          include: [
            {
              model: db.department,
              attributes: ["id"],
              include: [
                {
                  model: db.country,
                  attributes: ["id", "country_code", "iso_code"],
                },
              ],
            },
          ],
        },
        {
          model: db.gender,
          attributes: ["spanish_name"],
          required: false,
        },
      ],
    });

    if (!userFound.municipality) {
      return null;
    } else {
      if (
        userFound.municipality.codigo &&
        userFound.municipality.codigo != ""
      ) {
        let params = {
          producer: {
            arrivalReasonName:
              userFound.how_did_you_find_out == 1
                ? "PECA"
                : userFound.how_did_you_find_out == 2
                ? "Voz a Voz"
                : userFound.how_did_you_find_out == 3
                ? "Asociación"
                : userFound.how_did_you_find_out == 4
                ? "Otro"
                : "",
            dateOfBirth: userFound.birthdate ? userFound.birthdate : "",
            emailAddress: userFound.email ? userFound.email : "",
            firstName: userFound.first_name
              ? userFound.first_name.toUpperCase()
              : "",
            fiscalIdNumber: "",
            fiscalIdTypeId: "",
            gender: !userFound.gender
              ? ""
              : userFound.gender.spanish_name === "Masculino"
              ? "male"
              : "female",
            middleName: userFound.second_name
              ? userFound.second_name.toUpperCase()
              : "",
            mobileNumber: userFound.cellphone
              ? "+" +
                userFound.municipality.department.country.country_code +
                userFound.cellphone
              : "",
            personalIdNumber: userFound.dni,
            personalIdType: "DNI",
            status: userFound.state_id,
            phoneNumber: "",
            countryIsoCode: userFound.municipality.department.country.iso_code,
            secondSurname: userFound.second_surname
              ? userFound.second_surname.toUpperCase()
              : "",
            surname: userFound.first_surname
              ? userFound.first_surname.toUpperCase()
              : "",
            municipalityCode: !userFound.municipality
              ? "1018"
              : userFound.municipality.codigo &&
                userFound.municipality.codigo != ""
              ? userFound.municipality.codigo
              : "1018",
            arabicaId: id_user,
          },
        };
        return params;
      } else {
        return null;
      }
    }
  } catch (error) {
    console.log(error);
  }
};
const getParamsFarmAtlas = async (id_farm, id_producer, farmAssociateBoolean, idProducerAssociate) => {
  try {
    const farmFound = await db.farm.findOne({
      attributes: ["name", "location", "id", "user_id", "village", "state_id"],
      include: [
        {
          model: db.certification,
          attributes: ["spanish_name"],
          through: {
            attributes: ["certification_id"],
            where: { state_id: 1 },
          },
        },
        {
          model: db.fermentation_type,
          attributes: ["spanish_name"],
          through: {
            attributes: ["farm_id"],
            where: { state_id: 1 },
          },
        },
        {
          model: db.process_type,
          attributes: ["spanish_name"],
          through: {
            attributes: ["farm_id"],
            where: { state_id: 1 },
          },
        },
        {
          model: db.municipality,
          attributes: ["id", "codigo"],
          required: false,
          include: [
            {
              model: db.department,
              attributes: ["id"],
              include: [
                {
                  model: db.country,
                  attributes: ["id", "country_code", "iso_code"],
                },
              ],
            },
          ],
        },
        {
          model: db.plot,
          required: false,
          include: [{ model: db.coffee_variety, required: false }],
          where: {
            deleteAt: null,
          },
        },
      ],
      where: {
        farm_id: id_farm,
        state_id: 1,
        user_id: id_producer,
      },
    });
    let arrayFermentations = [];

    
    for (let fermentation of farmFound.fermentation_type) {
      arrayFermentations.push(fermentation.spanish_name.toUpperCase());
    }
    let arrayCertifications = [];
    for (let certification of farmFound.certification) {
      arrayCertifications.push(certification.spanish_name.toUpperCase());
    }
    let arrayProcessType = [];
    for (let ProcessType of farmFound.process_type) {
      arrayProcessType.push(
        ProcessType.spanish_name.replace(/\s/g, "").toUpperCase()
      );
    }
    let arrayCoffeeVarieties = [];
    for (let plot of farmFound.plot) {
      if (!arrayCoffeeVarieties.includes(plot.coffee_variety.spanish_name))
        arrayCoffeeVarieties.push(
          plot.coffee_variety.spanish_name.toUpperCase()
        );
    }

    //Consultar Locación
    const codMinu = await db.municipality.findOne({
      attributes: ["id"],
      where: {
        municipality_id: farmFound.location,
      },
    });
    let verifyName = farmFound.name.toUpperCase().trim();
    if (
      verifyName === "SINFINCA" ||
      verifyName === "SINVEREDA" ||
      verifyName === "SINFICA" ||
      verifyName === "SN" ||
      verifyName === "NOMBREFINCA"
    ) {
      let res = {
        statusCode: 401,
        data: "---- Error name farm ------",
        token: "SIN",
        type: "ERROR",
        params: JSON.stringify({
          farm: {
            name: farmFound.name.toUpperCase(),
            farm_id: farmFound.farm_id,
            status: farmFound.state_id,
            address: farmFound.village.toUpperCase(),
            certificateNames: arrayCertifications,
            fermentationTypeNames: arrayFermentations,
            varietyNames: arrayCoffeeVarieties,
            processTypesNames: arrayProcessType,
            producerArabicaId: farmAssociateBoolean ?  idProducerAssociate : farmFound.user_id,
            municipalityCode: !farmFound.municipality
              ? "1018"
              : farmFound.municipality.codigo &&
                farmFound.municipality.codigo != ""
              ? farmFound.municipality.codigo
              : "1018",
            arabicaId: farmFound.id,
          },
        }),
      };
      saveData(res);
      var dataFarm= {
        data: "farm",
        res: res.params,
      };

      console.log('INFORMACIÓN A ENVIAR');
      return {}
    } else {
      if (!farmFound.municipality) {
        let res = {
          statusCode: 401,
          data: "---- Error municipality 1 farm ------",
          token: "SIN",
          type: "ERROR",
          params: JSON.stringify({
            farm: {
              name: farmFound.name.toUpperCase(),
              status: farmFound.state_id,
              address: farmFound.village.toUpperCase(),
              certificateNames: arrayCertifications,
              fermentationTypeNames: arrayFermentations,
              varietyNames: arrayCoffeeVarieties,
              processTypesNames: arrayProcessType,
              producerArabicaId: farmAssociateBoolean ?  idProducerAssociate : farmFound.user_id,
              municipalityCode: !farmFound.municipality
                ? "1018"
                : farmFound.municipality.codigo &&
                  farmFound.municipality.codigo != ""
                ? farmFound.municipality.codigo
                : "1018",
              arabicaId: farmFound.id,
            },
          }),
        };
        saveData(res);
        return {};
      } else {
        if (
          farmFound.municipality.codigo &&
          farmFound.municipality.codigo != ""
        ) {
          return {
            farm: {
              name: farmFound.name.toUpperCase(),
              address: farmFound.village.toUpperCase(),
              certificateNames: arrayCertifications,
              fermentationTypeNames: arrayFermentations,
              status: farmFound.state_id,
              varietyNames: arrayCoffeeVarieties,
              processTypesNames: arrayProcessType,
              producerArabicaId: farmAssociateBoolean ?  idProducerAssociate : farmFound.user_id,
              countryIsoCode:
                farmFound.municipality.department.country.iso_code,
              municipalityCode: !farmFound.municipality
                ? "1018"
                : farmFound.municipality.codigo &&
                  farmFound.municipality.codigo != ""
                ? farmFound.municipality.codigo
                : "1018",
              arabicaId: farmFound.id,
            },
          };
        } else {
          let res = {
            statusCode: 401,
            data: "---- Error municipality 2 farm ------",
            token: "SIN",
            type: "ERROR",
            params: JSON.stringify({
              farm: {
                name: farmFound.name.toUpperCase(),
                address: farmFound.village.toUpperCase(),
                certificateNames: arrayCertifications,
                fermentationTypeNames: arrayFermentations,
                varietyNames: arrayCoffeeVarieties,
                processTypesNames: arrayProcessType,
                producerArabicaId: farmAssociateBoolean ?  idProducerAssociate : farmFound.user_id,
                municipalityCode: !farmFound.municipality
                  ? "1018"
                  : farmFound.municipality.codigo &&
                    farmFound.municipality.codigo != ""
                  ? farmFound.municipality.codigo
                  : "1018",
                arabicaId: farmFound.id,
              },
            }),
          };
          saveData(res);
          return {};
        }
      }
    }
  } catch (error) {
    console.log(error);
  }
};

const GetLotList = async (params, token) => {
  try {
    const userFound = await db.caravela_user.findAll({
      attributes: ["id"],
      // raw: true,
      include: [
        {
          model: Municipality,
          required: true,
          attributes: ["id"],
          include: [
            {
              model: Department,
              required: true,
              attributes: ["id"],
              include: [
                {
                  model: Country,
                  required: true,
                  attributes: ["spanish_name"],
                },
              ],
            },
          ],
        },
      ],
      where: { role_id: 4 },
    });

    const date = moment(
      moment().format("YYYY-MM-DD") + " " + "23:59:59z",
      "YYYY-MM-DD HH:mm:ssz"
    ).format("YYYY-MM-DDTHH:mm:ssz");

    console.log(date);

    for (let i = 0; i < userFound.length; i++) {
      const element = userFound[i];

      const IdElement = element.id;
      if (element.municipality.department.country.spanish_name == "Nicaragua") {
        console.log(element.municipality.department.country.spanish_name);
      } else {
        let Peticion = await methodAxios(
          `${url}v1/lots/?producerArabicaId=${IdElement}&since=${date}Z`,
          token,
          "",
          "get"
        );
        console.log(Peticion);
      }

      if (i >= 500) {
        break;
      }
    }

    //  console.log (userFound);
    return userFound;
  } catch (error) {
    console.log(error);
    return error;
  }
};

const GetlotsNIC = async (params) => {
  console.log("tes2t");
  let datein = "01/09/2020";
  let dateout = "31/12/2021";
  try {
    const countryFound = await Country.findAll({});

    for (let i = 0; i < countryFound.length; i++) {
      let params = {
        start_date: datein,
        end_date: dateout,
        country_iso_code: countryFound[i].iso_code,
        apikey: "2cf7f5bc-8a57-4711-99d2-d24873d72a62",
      };

      let request = await methodAxios(`${url2}`, "", params, "get");

      let respuestResponce = JSON.parse(request.date);
      console.log(respuestResponce.length);
      for (let k = 0; k < respuestResponce.length; k++) {
        const item = respuestResponce[k];
        // console.log (item);

        const userFound = await Users.findOne({
          //    attributes: ['id'],
          raw: true,

          where: { id: item.producer_id },
        });

        if (userFound) {
          console.log("existe");

          const NiclotsCreate = await NicLots.create({
            unique_id: uuid(),
            turned_dry_at: item.turned_dry_at,
            local_identifier: item.local_identifier,
            created_at: item.created_at,
            quality_code: item.quality_code,
            grade: item.grade,
            warehouse: item.warehouse,
            country: item.country,
            department: item.department,
            municipality: item.municipality,
            price_accepted_at: item.price_accepted_at,
            producer_id: item.producer_id,
            producer_name: item.producer_name,
            total_weight: item.total_weight,
            unit_purchase_price: item.unit_purchase_price,
            coffee_type: item.coffee_type,
            certificate: item.certificate,
            fermentation_type: item.fermentation_type,
            variety: item.variety,
            process_type: item.process_type,
            factor_14: item.factor_14,
            factor_15: item.factor_15,
            yield_14: item.yield_14,
            yield_15: item.yield_15,
            density: item.density,
            green: item.green,
            merma: item.merma,
            sieve_0: item.sieve_0,
            sieve_12: item.sieve_12,
            sieve_14: item.sieve_14,
            sieve_15: item.sieve_15,
            group_1: item.group_1,
            group_2: item.group_2,
            broca: item.broca,
            paloteo: item.paloteo,
            ripio: item.ripio,
            guayabas: item.guayabas,
            caracol: item.caracol,
            physical_analysis_observations: item.physical_analysis_observations,
            accepting_reason: item.accepting_reason,
            farm_name: item.farm_name,
            association: item.association,
            humidity_green: item.humidity_green,
            humidity_dry_parchment: item.humidity_dry_parchment,
            water_activity: item.water_activity,
            initial_weight: item.initial_weight,
            roasted_weight: item.roasted_weight,
            time_roasting: item.time_roasting,
            time_to_first_crack: item.time_to_first_crack,
            development: item.development,
            pppt: item.pppt,
            final_score: item.final_score,
            descriptor_overall: item.descriptor_overall,
            descriptor_body: item.descriptor_body,
            descriptor_roast: item.descriptor_roast,
            descriptor_flavours: item.descriptor_flavours,
            alternatives: item.alternatives,
            defects: item.defects,
            sensorial_analysis_observation: item.sensorial_analysis_observation,
            sensorial_accepting_reason: item.sensorial_accepting_reason,
            deleteAt: null,
          });

          // console.log (NiclotsCreate);
        } else {
          console.log({ status: "no existe productor" }, { item });
        }
      }
    }

    return;
  } catch (error) {
    console.log(error);
    return error;
  }
};

function isEmptyObject(obj) {
  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      return false;
    }
  }
  return true;
}
export default {
  setFarmAndProducer,
  GetLotList,
  GetlotsNIC,
};
