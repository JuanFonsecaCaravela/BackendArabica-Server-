import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlCountry from '../controllers/country.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlCountry.create);

router.put('/', verifyToken, ctrlCountry.update);

router.post('/all', ctrlCountry.findAll);

router.get('/:id', verifyToken, ctrlCountry.findById);

router.delete('/:id', verifyToken, ctrlCountry.deleteOne);

export default router;