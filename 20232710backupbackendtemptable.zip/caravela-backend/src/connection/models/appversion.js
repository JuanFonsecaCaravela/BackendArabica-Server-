'use strict';
module.exports = (sequelize, DataTypes) => {
  const appVersion = sequelize.define('appVersion', {
    version: DataTypes.STRING
  }, {});
  appVersion.associate = function(models) {
    // associations can be defined here
  };
  return appVersion;
};