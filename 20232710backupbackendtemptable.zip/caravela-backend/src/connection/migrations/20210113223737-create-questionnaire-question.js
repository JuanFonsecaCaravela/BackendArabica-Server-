'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('QuestionnaireQuestions', {
            id: {
              allowNull: false,
              autoIncrement: true,
              primaryKey: true,
              type: Sequelize.INTEGER
            },
            order: {
              type: Sequelize.INTEGER,
              allowNull: false
            },
            version: {
              type: Sequelize.INTEGER,
              allowNull: false
            },
      
            min: {
              type: Sequelize.INTEGER,
              allowNull: false
            },
      
            max: {
              type: Sequelize.INTEGER,
              allowNull: false
            },
            required: {
              type: Sequelize.BOOLEAN,
              allowNull: false,
              defaultValue: true
            },
            date: {
              type: Sequelize.BOOLEAN,
              allowNull: false,
              defaultValue: true
            },
            time: {
              type: Sequelize.BOOLEAN,
              allowNull: false,
              defaultValue: true
            },
            pdf: {
              type: Sequelize.BOOLEAN,
              allowNull: false,
              defaultValue: true
            },
            png: {
              type: Sequelize.BOOLEAN,
              allowNull: false,
              defaultValue: true
            },
            jpg: {
              type: Sequelize.BOOLEAN,
              allowNull: false,
              defaultValue: true
            },
            doc: {
              type: Sequelize.BOOLEAN,
              allowNull: false,
              defaultValue: true
            },
            excel: {
              type: Sequelize.BOOLEAN,
              allowNull: false,
              defaultValue: true
            },
            description: {
              type: Sequelize.STRING(1000),
              allowNull: false,
              get: function() {
                return this.getDataValue("description");
              },
              set: function(value) {
                if (value && value != "")
                  this.setDataValue("description", capitalize.words(value));
              }
            },
            unique_id: {
              type: Sequelize.STRING(255),
              allowNull: false
            },
            iddispositivo: {
              type: Sequelize.STRING(100),
              allowNull: false
            },
            delete_user_id: {
              type: Sequelize.INTEGER,
              allowNull: true,
              references: {
                model: "caravela_user",
                key: "id"
              }
            },
            survey_id: {
              type: Sequelize.INTEGER,
              allowNull: false,
              references: {
                model: "questionnaires",
                key: "id"
              }
            },
            type_question_id: {
              type: Sequelize.INTEGER,
              allowNull: false,
              references: {
                model: "QuestionnaireQuestionTypes",
                key: "id"
              }
            },
            delete_at: {
              type: Sequelize.DATE,
              allowNull: true
            },
            createdAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            updatedAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            condicionation:{
              type: Sequelize.DataTypes.BOOLEAN, 
            },
            id_condicionation:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true,
            },
            id_category_condicionation:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true,
            },
            id_option_condicionation:{
              type: Sequelize.DataTypes.INTEGER,
              allowNull: true,
            },
            observation:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true
            },
            descriptionPhotos:{
              type: Sequelize.DataTypes.STRING, 
              allowNull: true
            },
            entrytext:{
              type: Sequelize.DataTypes.BOOLEAN,
              allowNull: false,
              defaultValue: false,
            },
            order_section:{
              type: Sequelize.DataTypes.INTEGER,
              allowNull: true
            },
            section:{
              type: Sequelize.DataTypes.STRING, 
              allowNull: true
            },
            operationText:{
              type: Sequelize.DataTypes.STRING(2000),
              allowNull: true,
            },
            state_id:{
              type: Sequelize.DataTypes.INTEGER,
              defaultValue: 1,
              allowNull: true,
              references: {
                model: "state",
                key: "id",
              },
            },
            categoryId:{
              type: Sequelize.DataTypes.INTEGER,
              allowNull: true,
              references: {
                model: "questionnaire_categories",
                key: "id",
              },
            },
            

          });
    },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('QuestionnaireQuestions');
    }
};