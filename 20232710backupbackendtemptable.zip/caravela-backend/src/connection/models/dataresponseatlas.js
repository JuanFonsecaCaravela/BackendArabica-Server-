'use strict';
module.exports = (sequelize, DataTypes) => {
  const DataResponseAtlas = sequelize.define('DataResponseAtlas', {
    token: DataTypes.STRING,
    type: DataTypes.STRING,
    datasend: DataTypes.STRING,
    dataresponse: DataTypes.STRING,
    statuscode: DataTypes.INTEGER
  }, {});
  DataResponseAtlas.associate = function(models) {
    // associations can be defined here
  };
  return DataResponseAtlas;
};