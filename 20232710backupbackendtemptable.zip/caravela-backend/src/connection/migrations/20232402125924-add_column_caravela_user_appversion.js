'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction ((t) => {
      return Promise.all ([
        queryInterface.addColumn(
          "caravela_user",
          "app_version",
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true,
            defaultValue: '0.0.0',
          },
          { transaction: t }
        ),     
      ]);
    });
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};
