"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const renovation_type = sequelize.define(
    "renovation_type",
    {
      renovation_type_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      i18n: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "renovation_type",
        plural: "renovation_type"
      }
    }
  );
  renovation_type.associate = function(models) {
    renovation_type.belongsToMany(models.plot, { 
      through: models.plot_renovation, foreignKey: 'renovation_type_id' 
    });
  };
  sequelizePaginate.paginate(renovation_type);
  return renovation_type;
};
