"use strict"
module.exports = (sequelize, DataTypes) => {
  const visit = sequelize.define(
    "visit",
    {
      visit_id: DataTypes.STRING,
      visit_date: DataTypes.DATE,
      not_want_rate: DataTypes.BOOLEAN,
      visit_type_id: DataTypes.INTEGER,
      visited: DataTypes.INTEGER,
      average_rating: DataTypes.DOUBLE,
      answer: DataTypes.STRING,
      creatorRoleType: DataTypes.STRING,
    },
    {
      freezeTableName: true,
      name: {
        singular: "visit",
        plural: "visit"
      }
    }
  )
  visit.associate = function (models) {
    // associations can be defined here
    visit.hasMany(models.user_visit, {
      foreignKey: { name: 'visit_id', allowNull: false }
    })
    visit.belongsTo(models.visit_type, {
      foreignKey: { name: 'visit_type_id', allowNull: false }
    })

  }
  return visit
}
