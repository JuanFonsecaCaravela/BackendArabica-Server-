import express from "express";
import jwtService from "../services/jwt.service";
import ctrlUserWeb from "../controllers/userWeb.controller";
import userValidations from "../validations/user.validations.js";

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post("/", ctrlUserWeb.create);

router.put("/", verifyToken, ctrlUserWeb.update);

router.put("/enable", verifyToken, ctrlUserWeb.updateEnable);

router.put("/enableFarm", verifyToken, ctrlUserWeb.updateEnableFarm);

router.put("/enableParcel", verifyToken, ctrlUserWeb.updateEnableParcel);

router.post("/all", verifyToken, ctrlUserWeb.findAll);

//router.post("/code", verifyToken , ctrlUserWeb.createCodeQr);

router.post("/img_PDF", verifyToken, ctrlUserWeb.updateImgPDF);

router.post("/all_Farm", verifyToken, ctrlUserWeb.findAllFarms);

router.post("/all_filter", verifyToken, ctrlUserWeb.findAllFilter);

router.post("/all_filterTech", verifyToken, ctrlUserWeb.findAllFilterTech);

router.post("/all_technical", verifyToken, ctrlUserWeb.findAllByTechnical);

router.post("/all_producer", verifyToken, ctrlUserWeb.findAllByProducer);

router.post("/all_Admin", verifyToken, ctrlUserWeb.findAllByAdmin);

router.post("/byid", verifyToken, ctrlUserWeb.findById);

router.delete("/:id", verifyToken, ctrlUserWeb.deleteOne);

router.post("/allProducerCost", verifyToken, ctrlUserWeb.findAllProducerCost);

router.post(
  "/recovery-password",
  [userValidations.recoveryPasswordEmail()],
  ctrlUserWeb.recoveryPasswordEmail
);

router.post("/resetPassword", ctrlUserWeb.resetPassword) //nitish
router.put("/UpdatePasswrod",[userValidations.RecoveryPasswordValidation()],  ctrlUserWeb.updatePassword)  //nitish
router.post("/createLoaderTime", ctrlUserWeb.insertTimeLoader)  //nitish
router.get("/getLoaderTime", ctrlUserWeb.getTimeLoader)  //nitish

router.get("/getTimeLoaderById/:id", ctrlUserWeb.getTimeLoaderById)  //nitish

router.post("/updateLoaderbyId", ctrlUserWeb.updateLoaderById)  //nitish
router.delete("/deleteLoaderById/:id", ctrlUserWeb.DeleteLoaderById)  //nitish


router.get("/byidTec/:id", verifyToken, ctrlUserWeb.findByTecId);

router.post('/code_qr', verifyToken, ctrlUserWeb.createCodeQrUser);
router.post('/code_qr/farm', verifyToken, ctrlUserWeb.CodeQRUserFarm);
router.post('/code_qr/farm/one/:id', ctrlUserWeb.CodeQRFarm);
router.post('/userCheck' , verifyToken , ctrlUserWeb.userCheck );


export default router;
