'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable ('replyLog', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },

      uuid_movil: {
        type: Sequelize.STRING,
      },
      uuid: {
        type: Sequelize.STRING,
      },
      description: {
        type: Sequelize.STRING,
      },

      value: {
        type: Sequelize.STRING,
      },

      date: {
        type: Sequelize.DATE,
      },

      hour: {
        type: Sequelize.TIME,
      },

      id_replyQuestion: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'replyQuestion',
          key: 'id',
        },
      },
      state_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'state',
          key: 'id',
        },
      },
      deleteAt: {
        allowNull: true,
        type: Sequelize.DATE,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable ('replyLog');
  },
};
