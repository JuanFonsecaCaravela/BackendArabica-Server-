"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const caravela_user = sequelize.define(
    "caravela_user",
    {
      caravela_user_id: DataTypes.STRING,
      dni: DataTypes.STRING,
      role: DataTypes.STRING,
      first_name: {
        type: DataTypes.STRING,
        set(value) {
          if (value) this.setDataValue("first_name", value.toUpperCase());
          else this.setDataValue("first_name", value);
        },
        get() {
          return this.getDataValue("first_name");
        },
      },
      second_name: {
        type: DataTypes.STRING,
        set(value) {
          if (value) this.setDataValue("second_name", value.toUpperCase());
          else this.setDataValue("second_name", value);
        },
        get() {
          return this.getDataValue("second_name");
        },
      },
      first_surname: {
        type: DataTypes.STRING,
        set(value) {
          if (value) this.setDataValue("first_surname", value.toUpperCase());
          else this.setDataValue("first_surname", value);
        },
        get() {
          return this.getDataValue("first_surname");
        },
      },
      second_surname: {
        type: DataTypes.STRING,
        set(value) {
          if (value) this.setDataValue("second_surname", value.toUpperCase());
          else this.setDataValue("second_surname", value);
        },
        get() {
          return this.getDataValue("second_surname");
        },
      },
      password: DataTypes.STRING,
      birthdate: DataTypes.DATE,
      address: DataTypes.STRING,
      cellphone: DataTypes.STRING,
      email: DataTypes.STRING,
      has_assigned_technician: DataTypes.BOOLEAN,
      has_association: DataTypes.BOOLEAN,
      society_name: DataTypes.STRING,
      user_approved: DataTypes.BOOLEAN,
      terms_accepted: DataTypes.BOOLEAN,
      profile_image_url: DataTypes.STRING,
      profile_image_name: DataTypes.STRING,
      status: DataTypes.INTEGER,
      civil_status_id: DataTypes.INTEGER,
      dni_type_id: DataTypes.INTEGER,
      gender_id: DataTypes.INTEGER,
      municipality_id: DataTypes.INTEGER,
      user_type_id: DataTypes.INTEGER,
      boss: DataTypes.INTEGER,
      technician_assigned_id: DataTypes.INTEGER,
      role_id: DataTypes.INTEGER,
      scholarship_id: DataTypes.INTEGER,
      creatorRoleType: DataTypes.STRING,
      tokenFirebase: DataTypes.STRING,
      dni_associated: DataTypes.STRING,
      check_coffee: DataTypes.BOOLEAN,
      how_did_you_find_out: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      from_producer: DataTypes.BOOLEAN,
      from_technician: DataTypes.BOOLEAN,
      total_rating: DataTypes.DOUBLE,
      count_rating: DataTypes.INTEGER,
      updatedAt: DataTypes.DATE,
      creatorRoleType: DataTypes.STRING,
      total_points: DataTypes.INTEGER,
      img_pdf: DataTypes.STRING,
      id_user_tenant: DataTypes.INTEGER,
      QRCodeIn : DataTypes.STRING,
      producer_peca: DataTypes.INTEGER,
      agroforestry: DataTypes.INTEGER,
      land_uses: DataTypes.INTEGER,
      contact_subTypes: DataTypes.INTEGER,
      land_ownerships: DataTypes.INTEGER,
      privacypolicies_accepted:DataTypes.BOOLEAN,
      ip_privacypolicies_accepted:DataTypes.STRING,
      date_privacypolicies_accepted:DataTypes.STRING,
      app_version:DataTypes.STRING,
    },
    {
      freezeTableName: true,
      name: {
        singular: "caravela_user",
        plural: "caravela_user",
      },
    }
  );
  caravela_user.associate = function (models) {
    this.hasMany(models.twilioResponse, {
      foreignKey: { name: "user_id", allowNull: false },
    });
    caravela_user.hasMany(models.user_visit, {
      as: "Producervisit",
      foreignKey: { name: "producer_visited_id", allowNull: false },
    });
    caravela_user.hasMany(models.user_visit, {
      as: "Technicianvisit",
      foreignKey: { name: "visiting_technician_id", allowNull: false },
    });
    caravela_user.belongsTo(models.gender, {
      foreignKey: { name: "gender_id", allowNull: false },
    });
    caravela_user.hasMany(models.user_tenant, {
      as: "UserTenant",
      foreignKey: { name: "id_user_tenant", allowNull: false },
    });
    caravela_user.belongsTo(models.civil_status, {
      foreignKey: { name: "civil_status_id", allowNull: false },
    });

    caravela_user.belongsTo(models.scholarship, {
      foreignKey: { name: "scholarship_id", allowNull: true },
    });

    caravela_user.hasMany(models.family_member, {
      foreignKey: { name: "user_id", allowNull: false },
    });
    caravela_user.hasMany(models.farm, {
      foreignKey: { name: "user_id", allowNull: false },
    });
    caravela_user.hasMany(models.current_versionservice, {
      foreignKey: { name: "id_user", allowNull: true },
    });
    caravela_user.belongsTo(models.dni_type, {
      foreignKey: { name: "dni_type_id", allowNull: false },
    });

    caravela_user.belongsTo(models.municipality, {
      foreignKey: { name: "municipality_id", allowNull: false },
    });

    // caravela_user.hasMany(models.user_visit, {
    //   foreignKey: { name: "municipality_id", allowNull: false }
    // });

    caravela_user.hasMany(models.survey, {
      foreignKey: {
        name: "creator_user_id",
        allowNull: false,
        as: "creator_survey",
      },
    });

    caravela_user.hasMany(models.MessageHead, {
      foreignKey: { name: "user_id", allowNull: true },
      as: "producer",
    });

    caravela_user.hasMany(models.MessageHead, {
      foreignKey: { name: "technicial_id", allowNull: true },
      as: "technicial",
    });

    caravela_user.hasMany(models.MessageBody, {
      foreignKey: { name: "view_user_producer", allowNull: true },
      as: "producer_body",
    });

    caravela_user.hasMany(models.MessageBody, {
      foreignKey: { name: "view_user_technical", allowNull: true },
      as: "technicial_body",
    });

    caravela_user.belongsTo(models.Role, {
      foreignKey: { name: "role_id", allowNull: true },
    });

    caravela_user.hasMany(models.Point, {
      foreignKey: { name: "user_id", allowNull: true },
    });

    caravela_user.belongsToMany(models.cost_Body, {
      through: "replyQuestion",
      foreignKey: { name: "user_id", allowNull: false },
    });

    // caravela_user.hasMany(models.ModifyUser, {
    //   foreignKey: { name: "producer", allowNull: false }
    // })
  };
  sequelizePaginate.paginate(caravela_user);
  return caravela_user;
};
