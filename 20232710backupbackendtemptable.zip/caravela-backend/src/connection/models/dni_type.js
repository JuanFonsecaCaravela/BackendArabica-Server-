"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const dni_type = sequelize.define(
    "dni_type",
    {
      dni_type_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      i18n: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "dni_type",
        plural: "dni_type"
      }
    }
  );

  dni_type.associate = function(models) {
    // associations can be defined here
    dni_type.belongsToMany(models.country, {
      through: "dni_type_country",
      foreignKey: "dni_type_id"
    });

    dni_type.hasMany(models.dni_type, {
      foreignKey: { name: "dni_type_id", allowNull: false }
    });
  };
  sequelizePaginate.paginate(dni_type);
  return dni_type;
};
