'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction (t => {
      return Promise.all ([
        queryInterface.addColumn (
          'replyQuestion',
          'id_department',
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: true,
            defaultValue: null,
            references: {
              model: 'department',
              key: 'id',
            },
          },
          {transaction: t}
        ),
        queryInterface.addColumn (
          'replyQuestion',
          'description',
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true,
            defaultValue: null,
    
          },
          {transaction: t}
        ),
      ]);
    });
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  },
};
