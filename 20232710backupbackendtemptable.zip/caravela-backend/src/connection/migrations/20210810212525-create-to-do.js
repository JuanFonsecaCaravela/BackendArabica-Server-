'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('ToDos', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING
      },
      description: {
        type: Sequelize.STRING
      },
      id_producer: {
        type: Sequelize.INTEGER,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },
      unique_id: {
        type: Sequelize.STRING
      },
      id_peca: {
        type: Sequelize.INTEGER,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },
      date: {
        type: Sequelize.STRING
      },
      state: {
        type: Sequelize.STRING
      },
      type: {
        type: Sequelize.INTEGER
      },
      hour: {
        type: Sequelize.STRING
      },
      priority: {
        type: Sequelize.STRING
      },
      status: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('ToDos');
  }
};