"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("plot_renovation", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      unique_id: {
        type: Sequelize.STRING(255),
        allowNull: false,
        unique: true
      },
      dates: {
        type: Sequelize.STRING,
      },
      plot_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "plot",
          key: "id"
        }
      },
      renovation_type_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "renovation_type",
          key: "id"
        }
      },
      deleteAt: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("plot_renovation");
  }
};
