import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlFormula_head from '../controllers/formulaHead.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', verifyToken, ctrlFormula_head.create);

router.put('/', verifyToken, ctrlFormula_head.update);

router.post('/all', verifyToken, ctrlFormula_head.findAll);

router.get('/:id', verifyToken, ctrlFormula_head.findById);

router.delete('/:id',  ctrlFormula_head.deletes)

router.delete('/body/:id', verifyToken, ctrlFormula_head.deleteOneBody);

router.delete('/head/:id', verifyToken, ctrlFormula_head.deleteOneHead);

export default router;