'use strict';
module.exports = (sequelize, DataTypes) => {
  const AnswerBody = sequelize.define('AnswerBody', {
    unique_id: DataTypes.STRING,
    type: DataTypes.STRING,
    version: DataTypes.INTEGER,
    answer: DataTypes.STRING,
    id_answer: DataTypes.INTEGER,
    id_question: DataTypes.INTEGER,
  }, {});
  AnswerBody.associate = function(models) {
    // associations can be defined here
    AnswerBody.belongsTo(models.answer_survey, {
      foreignKey: { name: "id_answer", allowNull: false }
    });
    AnswerBody.belongsTo(models.question, {
      foreignKey: { name: "id_question", allowNull: false }
    });
  };
  return AnswerBody;
};