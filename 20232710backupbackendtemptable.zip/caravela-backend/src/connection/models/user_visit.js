"use strict";
module.exports = (sequelize, DataTypes) => {
  const user_visit = sequelize.define(
    "user_visit",
    {
      user_visit_id: DataTypes.STRING,
      visit_rating: DataTypes.DOUBLE,
      done_user: DataTypes.BOOLEAN,
      done_peca: DataTypes.BOOLEAN,
      skills: DataTypes.JSONB,
      producer_visited_id: DataTypes.INTEGER,
      visiting_technician_id: DataTypes.INTEGER,
      visit_id: DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "user_visit",
        plural: "user_visit"
      }
    }
  );
  user_visit.associate = function(models) {
    user_visit.belongsTo(models.caravela_user, { 
      as: 'Producervisit',
      foreignKey: { name: 'producer_visited_id', allowNull: false } 
    });
    user_visit.belongsTo(models.caravela_user, { 
      as: 'Technicianvisit',
      foreignKey: { name: 'visiting_technician_id', allowNull: false } 
    });
    
    user_visit.belongsTo(models.visit, { 
      foreignKey: { name: 'visit_id', allowNull: false } 
    });
  };
  return user_visit;
};
