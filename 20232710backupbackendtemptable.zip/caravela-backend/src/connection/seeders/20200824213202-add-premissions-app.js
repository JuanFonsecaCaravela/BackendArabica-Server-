'use strict'
const uuid = require("uuid/v4")
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "App producer",
          slug: "app_producer",
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          unique_id: uuid(),
          description: "App technical",
          slug: "app_technical",
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          unique_id: uuid(),
          description: "App coordinator",
          slug: "app_coordinator",
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          unique_id: uuid(),
          description: "App global coordinator",
          slug: "app_global_coordinator",
          createdAt: new Date(),
          updatedAt: new Date()
        }

      ],
      {}
    )
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
}
