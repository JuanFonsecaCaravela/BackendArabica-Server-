"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const fermentation_type = sequelize.define(
    "fermentation_type",
    {
      fermentation_type_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      i18n: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "fermentation_type",
        plural: "fermentation_type"
      }
    }
  );
  fermentation_type.associate = function(models) {
    
    fermentation_type.belongsToMany(models.farm, { 
      through: models.farm_fermentation_type, foreignKey: 'fermentation_type_id' 
    });
  };
  sequelizePaginate.paginate(fermentation_type);
  return fermentation_type;
};
