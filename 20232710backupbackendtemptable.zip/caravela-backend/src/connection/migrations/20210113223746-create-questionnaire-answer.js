'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('questionnaire_answers', {
            id: {
              allowNull: false,
              autoIncrement: true,
              primaryKey: true,
              type: Sequelize.INTEGER
            },
            unique_id: {
              type: Sequelize.STRING(100),
              allowNull: false
            },      
            producer: {
              type: Sequelize.STRING,
              allowNull: true,
            },   
            version: { 
              type: Sequelize.INTEGER
            },   
            farm: {
              type: Sequelize.STRING,
              allowNull: true,
            },
            plot: {
              type: Sequelize.STRING,
              allowNull: true,
            },
            id_survey: {
              type: Sequelize.INTEGER,
              allowNull: false,
              references: {
                model: "questionnaires",
                key: "id"
              }
            },   
            createdAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            updatedAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            location:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true
            },
            date:{
              type: Sequelize.DataTypes.STRING,
              allowNull: true
            },
            id_producer:{
              type: Sequelize.DataTypes.INTEGER,
              allowNull: false,
              references: {
              model: "caravela_user",
              key: "id",
              },
            },
            id_technician:{
              type: Sequelize.DataTypes.INTEGER,
              allowNull: true,
              references: {
                model: "caravela_user",
                key: "id",
              },
            },
            creatorRoleType:{
              type: Sequelize.DataTypes.STRING(1),
              allowNull: true,
            },

          });
    },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('questionnaire_answers');
    }
};