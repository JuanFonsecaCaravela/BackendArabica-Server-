'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('elearningv2s', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      course_id: {
        type: Sequelize.STRING
      },
      title: {
        type: Sequelize.STRING
      },
      category: {
        type: Sequelize.STRING
      },
      elearningv2_session_id: {
        type: Sequelize.INTEGER
      },
      maximumCapacity: {
        type: Sequelize.STRING
      },
      trainingCycle: {
        type: Sequelize.STRING
      },
      consecutiveCourse: {
        type: Sequelize.STRING
      },
      TypeCourse: {
        type: Sequelize.STRING
      },
      nameWhoOffers: {
        type: Sequelize.STRING
      },
      accessLink: {
        type: Sequelize.STRING
      },
      courseValidity: {
        type: Sequelize.STRING
      },
      modality: {
        type: Sequelize.STRING
      },
      Hourlyintensity: {
        type: Sequelize.STRING
      },
      numberStars: {
        type: Sequelize.STRING
      },
      strengthenKnowledge: {
        type: Sequelize.STRING
      },
      description: {
        type: Sequelize.STRING
      },
      loadFile: {
        type: Sequelize.STRING
      },
      version: {
        type: Sequelize.STRING
      },
      state_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'state',
          key: 'id',
        },
      },
      userCreate: {
        type: Sequelize.INTEGER,
        references: {
          model: 'caravela_user',
          key: 'id',
        },
      },

      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('elearningv2s');
  }
};