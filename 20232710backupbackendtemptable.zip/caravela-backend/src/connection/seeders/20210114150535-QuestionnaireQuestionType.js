'use strict';
const uuid = require("uuid/v4");
module.exports = {
    up: async(queryInterface, Sequelize) => {
        await queryInterface.bulkInsert(
            'QuestionnaireQuestionTypes', [{
                id: 2,
                description: 'Respuesta de Texto',
                unique_id: uuid(),
                createdAt: new Date(),
                updatedAt: new Date(),
            }, ], {}
        );
        await queryInterface.bulkInsert(
            'QuestionnaireQuestionTypes', [{
                id: 13,
                description: 'Respuesta Numerica',
                unique_id: uuid(),
                createdAt: new Date(),
                updatedAt: new Date(),
            }, ], {}
        );
        await queryInterface.bulkInsert(
            'QuestionnaireQuestionTypes', [{
                id: 8,
                description: 'Lista Desplegable',
                unique_id: uuid(),
                createdAt: new Date(),
                updatedAt: new Date(),
            }, ], {}
        );

    },

    down: (queryInterface, Sequelize) => {
        /*
          Add reverting commands here.
          Return a promise to correctly handle asynchronicity.

          Example:
          return queryInterface.bulkDelete('People', null, {});
        */
    }
};