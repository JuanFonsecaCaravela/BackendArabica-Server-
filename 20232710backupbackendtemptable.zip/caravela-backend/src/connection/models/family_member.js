"use strict"
module.exports = (sequelize, DataTypes) => {
  const family_member = sequelize.define(
    "family_member",
    {
      family_member_id: DataTypes.STRING,
      name: DataTypes.STRING,
      lastname: DataTypes.STRING,
      birthdate: DataTypes.DATE,
      user_id: DataTypes.INTEGER,
      gender_id: DataTypes.INTEGER,
      relationship_id: DataTypes.INTEGER,
      scholarship_id: DataTypes.INTEGER,
      typeDni_id: DataTypes.INTEGER,
      dni: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      state_id: DataTypes.INTEGER
    },
    {
      freezeTableName: true,
      name: {
        singular: "family_member",
        plural: "family_member"
      }
    }
  )
  family_member.associate = function (models) {
    family_member.belongsTo(models.caravela_user, {
      foreignKey: { name: "user_id", allowNull: false }
    })
    family_member.belongsTo(models.gender, {
      foreignKey: { name: "gender_id", allowNull: false }
    })
    family_member.belongsTo(models.relationship, {
      foreignKey: { name: "relationship_id", allowNull: false }
    })
    family_member.belongsTo(models.scholarship, {
      foreignKey: { name: "scholarship_id", allowNull: false }
    })
    family_member.belongsTo(models.dni_type, {
      foreignKey: { name: "typeDni_id", allowNull: false },
    });
    family_member.hasMany(models.farmAssociate, {
      foreignKey: { name: "family_id", allowNull: true },
    });
  }
  return family_member
}
