'use strict';
const uuid = require("uuid/v4");
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert("PermissionModels", [
        {
          unique_id: uuid(),
          description: "Ver costos",
          slug: "costs_view",
          createdAt: new Date(),
          updatedAt: new Date()
        },{
          unique_id: uuid(),
          description: "Ver categoria de costos",
          slug: "categoryCosts_view",
          createdAt: new Date(),
          updatedAt: new Date()
        },{
          unique_id: uuid(),
          description: "Ver formulas",
          slug: "formulas_view",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],{});

  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  }
};
