"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("PlannerProgrammingBodies", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      planner_programming_head_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "PlannerProgrammingHeads",
          key: "id"
        }
      },
      planner_master_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "PlannerMasters",
          key: "id"
        }
      },
      check: {
        type: Sequelize.BOOLEAN
      },
      starting_week: {
        type: Sequelize.INTEGER
      },
      final_week: {
        type: Sequelize.INTEGER
      },
      starting_week_real: {
        type: Sequelize.INTEGER
      },
      starting_week_real_year: {
        type: Sequelize.INTEGER
      },
      final_week_real: {
        type: Sequelize.INTEGER
      },
      final_week_real_year: {
        type: Sequelize.INTEGER
      },
      color: {
        type: Sequelize.INTEGER
      },
      date_initial: {
        type: Sequelize.DATE
      },
      date_limit: {
        type: Sequelize.DATE
      },
      date_app_movil: {
        type: Sequelize.DATE
      },
      date_app_movil_check: {
        type: Sequelize.DATE
      },
      unique_id: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("PlannerProgrammingBodies");
  }
};
