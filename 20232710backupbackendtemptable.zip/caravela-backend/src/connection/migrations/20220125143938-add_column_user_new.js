'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction( ( t ) => {
    return Promise.all([
      queryInterface.addColumn(
        "caravela_user",
        "producer_peca",
        {
          type: Sequelize.INTEGER,
          allowNull: true
          },
        { transaction: t }
      ),
      queryInterface.addColumn(
        "caravela_user",
        "agroforestry",
        {
          type: Sequelize.INTEGER,
          allowNull: true
        },
        { transaction: t }
      ),
      queryInterface.addColumn(
        "caravela_user",
        "land_uses",
        {
          type: Sequelize.INTEGER,
          allowNull: true
        },
        { transaction: t }
      ),
      queryInterface.addColumn(
        "caravela_user",
        "contact_subTypes",
        {
          type: Sequelize.INTEGER,
          allowNull: true
        },
        { transaction: t }
      ),
      queryInterface.addColumn(
        "caravela_user",
        "land_ownerships",
        {
          type: Sequelize.INTEGER,
          allowNull: true
        },
        { transaction: t }
      )
    ]);
  })
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  }
};
