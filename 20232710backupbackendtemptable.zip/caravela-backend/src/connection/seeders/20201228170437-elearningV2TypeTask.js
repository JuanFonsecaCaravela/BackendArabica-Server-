'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert (
      'elearningv2TaskTypes',
      [
        {
          id: 1,
          typesResponses: 'Imagen',
          createdAt: new Date (),
          updatedAt: new Date (),
        },
      ],
      {}
    );
    await queryInterface.bulkInsert (
      'elearningv2TaskTypes',
      [
        {
          id: 2,
          typesResponses: 'Texto',
          createdAt: new Date (),
          updatedAt: new Date (),
        },
      ],
      {}
    );
    await queryInterface.bulkInsert (
      'elearningv2TaskTypes',
      [
        {
          id: 3,
          typesResponses: 'PDF',
          createdAt: new Date (),
          updatedAt: new Date (),
        },
      ],
      {}
    );
    await queryInterface.bulkInsert (
      'elearningv2TaskTypes',
      [
        {
          id: 4,
          typesResponses: 'Video',
          createdAt: new Date (),
          updatedAt: new Date (),
        },
      ],
      {}
    );
    await queryInterface.bulkInsert (
      'elearningv2TaskTypes',
      [
        {
          id: 5,
          typesResponses: 'Cuestionario',
          createdAt: new Date (),
          updatedAt: new Date (),
        },
      ],
      {}
    );


  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
};
