"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const relationship = sequelize.define(
    "relationship",
    {
      relationship_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      i18n: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "relationship",
        plural: "relationship"
      }
    }
  );
  relationship.associate = function(models) {
    
    relationship.belongsTo(models.family_member, {
      foreignKey: { name: "relationship_id", allowNull: false }
    });
  };
  sequelizePaginate.paginate(relationship);
  return relationship;
};
