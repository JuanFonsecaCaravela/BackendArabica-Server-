'use strict';
module.exports = (sequelize, DataTypes) => {
  const serviceVersion = sequelize.define('serviceVersion', {
    version: DataTypes.INTEGER,
    type_service_id: DataTypes.INTEGER
  }, {});
  serviceVersion.associate = function(models) {
    serviceVersion.belongsTo(models.typeService, {
      foreignKey: { name: "type_service_id", allowNull: true }
    });
  };
  return serviceVersion;
};