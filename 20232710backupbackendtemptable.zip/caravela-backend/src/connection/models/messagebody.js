"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const MessageBody = sequelize.define(
    "MessageBody",
    {
      unique_id: DataTypes.STRING,
      message_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      type_message: DataTypes.INTEGER, // 1- Text, 2- Img, 3- Conectado técnico
      message: DataTypes.STRING,
      view_user_producer: DataTypes.INTEGER,
      date_view_user_producer: DataTypes.DATE,
      view_user_technical: DataTypes.INTEGER,
      date_view_user_technical: DataTypes.DATE,
      type: DataTypes.INTEGER
    },
    {}
  );
  MessageBody.associate = function(models) {
    MessageBody.belongsTo(models.MessageHead, {
      foreignKey: { name: "message_id", allowNull: true }
    });

    MessageBody.belongsTo(models.caravela_user, {
      foreignKey: { name: "view_user_producer", allowNull: true },
      as: "producer_body"
    });

    MessageBody.belongsTo(models.caravela_user, {
      foreignKey: { name: "view_user_technical", allowNull: true },
      as: "technicial_body"
    });
  };
  sequelizePaginate.paginate(MessageBody);
  return MessageBody;
};
