import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlScholarship from '../controllers/scholarship.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlScholarship.create);

router.put('/', verifyToken, ctrlScholarship.update);

router.post('/all', verifyToken, ctrlScholarship.findAll);

router.get('/:id', verifyToken, ctrlScholarship.findById);

router.delete('/:id', verifyToken, ctrlScholarship.deleteOne);

export default router;