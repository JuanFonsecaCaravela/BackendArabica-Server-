import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlLog from '../controllers/log.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlLog.create);

router.put('/', verifyToken, ctrlLog.update);

router.post('/all', verifyToken, ctrlLog.findAll);

router.get('/:id', verifyToken, ctrlLog.findById);

router.delete('/:id', verifyToken, ctrlLog.deleteOne);

export default router;