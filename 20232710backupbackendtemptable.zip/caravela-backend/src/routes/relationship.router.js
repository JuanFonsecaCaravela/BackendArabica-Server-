import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlRelationship from '../controllers/relationship.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlRelationship.create);

router.put('/', verifyToken, ctrlRelationship.update);

router.post('/all', verifyToken, ctrlRelationship.findAll);

router.get('/:id', verifyToken, ctrlRelationship.findById);

router.delete('/:id', verifyToken, ctrlRelationship.deleteOne);

export default router;