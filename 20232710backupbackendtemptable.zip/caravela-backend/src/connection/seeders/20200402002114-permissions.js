"use strict";
const uuid = require("uuid/v4");

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Ver parametrización",
          slug: "parametizer_view",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );



    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Crear parametrización",
          slug: "parametizer_create",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Editar parametrización",
          slug: "parametizer_edit",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Ver usuarios",
          slug: "user_view",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Crear usuarios",
          slug: "user_create",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Editar usuarios",
          slug: "user_edit",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Ver visitas",
          slug: "visit_view",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Editar visitas",
          slug: "visit_edit",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Crear visitas",
          slug: "visit_create",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Ver encuestas creadas",
          slug: "survey_view",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Crear encuestas",
          slug: "survey_create",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Editar encuestas creadas",
          slug: "survey_edit",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Eliminar encuestas creadas",
          slug: "survey_delete",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Ver encuestas diligenciadas",
          slug: "survey_completed_view",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

    await queryInterface.bulkInsert(
      "PermissionModels",
      [
        {
          unique_id: uuid(),
          description: "Editar encuestas diligenciadas",
          slug: "survey_completed_edit",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    );

  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
};
