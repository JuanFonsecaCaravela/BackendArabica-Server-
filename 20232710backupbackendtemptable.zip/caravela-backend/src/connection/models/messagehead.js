"use strict"
import sequelizePaginate from "sequelize-paginate"
module.exports = (sequelize, DataTypes) => {
  const MessageHead = sequelize.define(
    "MessageHead",
    {
      // unique_id: DataTypes.STRING,
      // subject: DataTypes.STRING,
      // content: DataTypes.STRING,
      // img: DataTypes.STRING,
      // user_id: DataTypes.INTEGER,
      // status_id: DataTypes.INTEGER,
      // technicial_id: DataTypes.INTEGER

      // message_id: DataTypes.INTEGER,
      unique_id: DataTypes.STRING,      
      subject: DataTypes.STRING,      
      //producer: DataTypes.STRING,      
      //technicial: DataTypes.STRING,      
      content: DataTypes.STRING,
      img: DataTypes.STRING,
      user_id: DataTypes.INTEGER,
      technicial_id: DataTypes.INTEGER,
      status_id: DataTypes.INTEGER
    },
    {}
  )

  MessageHead.associate = function (models) {
    MessageHead.hasMany(models.MessageBody, {
      foreignKey: { name: "message_id", allowNull: true }
    })

    MessageHead.belongsTo(models.StatusMessage, {
      foreignKey: { name: "status_id", allowNull: true }
    })

    MessageHead.belongsTo(models.caravela_user, {
      foreignKey: { name: "user_id", allowNull: true },
      as: "producer"
    })

    MessageHead.belongsTo(models.caravela_user, {
      foreignKey: { name: "technicial_id", allowNull: true },
      as: "technicial"
    })
  }
  sequelizePaginate.paginate(MessageHead)
  return MessageHead
}
