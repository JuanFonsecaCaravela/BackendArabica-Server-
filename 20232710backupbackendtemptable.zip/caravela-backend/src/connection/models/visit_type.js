"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const visit_type = sequelize.define(
    "visit_type",
    {
      visit_type_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      i18n: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.INTEGER,
      color:DataTypes.STRING,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "visit_type",
        plural: "visit_type"
      }
    }
  );
  visit_type.associate = function(models) {
    
    visit_type.hasMany(models.visit, { 
      foreignKey: { name: 'visit_type_id', allowNull: false } 
    });
  };
  sequelizePaginate.paginate(visit_type);
  return visit_type;
};
