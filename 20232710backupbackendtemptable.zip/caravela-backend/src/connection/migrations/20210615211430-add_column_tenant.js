"use strict";

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([
        queryInterface.addColumn(
          "process_type",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "relationship",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "visit_type",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "coffee_variety",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "drying_method",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "civil_status",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "certification",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "renovation_type",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "scholarship",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "dni_type",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "fermentation_type",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "survey_type",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "gender",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "OptionsListHeadModels",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "PlannerMasters",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "costCategory",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "type_logs",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
        queryInterface.addColumn(
          "survey",
          "id_tenant",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1,
          },
          { transaction: t }
        ),
      ]);
    });
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  },
};
