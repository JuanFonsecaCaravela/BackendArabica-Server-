'use strict';
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const tenant = sequelize.define('tenant', {
    uuid: DataTypes.STRING,
    description: DataTypes.STRING,
    active: DataTypes.INTEGER
  }, {});
  tenant.associate = function(models) {
    // associations can be defined here
  };
  sequelizePaginate.paginate(tenant);
  return tenant;
};