import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlCostCategory from '../controllers/costCategory.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', verifyToken, ctrlCostCategory.create);

router.put('/', verifyToken, ctrlCostCategory.update);

router.post('/all', verifyToken, ctrlCostCategory.findAll);

router.get('/:id', verifyToken, ctrlCostCategory.findById);

router.get('/cost/sync', verifyToken, ctrlCostCategory.findSync);

router.delete('/:id', verifyToken, ctrlCostCategory.deleteOne);

export default router;