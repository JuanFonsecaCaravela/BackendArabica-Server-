"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const process_type = sequelize.define(
    "process_type",
    {
      process_type_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      i18n: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "process_type",
        plural: "process_type"
      }
    }
  );
  process_type.associate = function(models) {
    process_type.belongsToMany(models.farm, { 
      through: models.farm_procces_type, foreignKey: 'process_type_id'
     });
  };
  sequelizePaginate.paginate(process_type);
  return process_type;
};
