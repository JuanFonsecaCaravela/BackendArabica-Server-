import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlVisitType from '../controllers/visit_type.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlVisitType.create);

router.put('/', verifyToken, ctrlVisitType.update);

router.post('/all', verifyToken, ctrlVisitType.findAll);

router.get('/:id', verifyToken, ctrlVisitType.findById);

router.delete('/:id', verifyToken, ctrlVisitType.deleteOne);

export default router;