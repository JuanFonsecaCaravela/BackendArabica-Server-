"use strict"
import sequelizePaginate from "sequelize-paginate"
module.exports = (sequelize, DataTypes) => {
  const municipality = sequelize.define(
    "municipality",
    {
      municipality_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      department_id: DataTypes.INTEGER,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      codigo: DataTypes.STRING
    },
    {
      freezeTableName: true,
      name: {
        singular: "municipality",
        plural: "municipality"
      }
    }
  )
  municipality.associate = function (models) {
    municipality.belongsTo(models.department, {
      foreignKey: { name: "department_id", allowNull: true }
    })

    municipality.hasMany(models.farm, {
      foreignKey: { name: "id_municipality", allowNull: true }
    })
    municipality.hasMany(models.caravela_user, {
      foreignKey: { name: "municipality_id", allowNull: false }
    })

  }
  sequelizePaginate.paginate(municipality)
  return municipality
}
