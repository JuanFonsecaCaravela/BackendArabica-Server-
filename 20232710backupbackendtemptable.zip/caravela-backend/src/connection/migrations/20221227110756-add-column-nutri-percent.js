'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([
        queryInterface.addColumn(
          "NutriPercents",
          "NutriRef",
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: true,                      
            references: {
              model: "Nutrition",
              key: "id"
            }
          },
          { transaction: t }
        ),
        
        // queryInterface.removeColumn('fertiPlanAdjusta', 'isDeleted')  //delete column
      ])
    })
  },  
  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  }
};
