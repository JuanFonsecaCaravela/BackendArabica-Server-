import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlLot from '../controllers/lot.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', verifyToken, ctrlLot.create);

router.put('/', verifyToken, ctrlLot.update);

router.get('/all/:id', verifyToken, ctrlLot.findAllByPlotId);

router.get('/:id', verifyToken, ctrlLot.findById);

router.get('/', verifyToken, ctrlLot.testlotList);

router.get('/test/lots', verifyToken, ctrlLot.testlotlist2);

router.delete('/:id', verifyToken, ctrlLot.deleteOne);

router.get('/LotProducer/all', verifyToken, ctrlLot.findAllLotProducer);

router.get('/LotStatus/all', verifyToken, ctrlLot.findAllLotStatus);


router.get('/LotProducer/allV2/:version/:uuid', verifyToken, ctrlLot.findAllLotProducerv2);
export default router;