'use strict';
module.exports = (sequelize, DataTypes) => {
  const fertiPlanAdjustaCountry = sequelize.define('fertiPlanAdjustaCountry', {
    country_id: DataTypes.INTEGER,
    country: DataTypes.STRING,
    fertiPlanCountryRef_id: DataTypes.INTEGER
  }, {});
  fertiPlanAdjustaCountry.associate = function(models) {
    // associations can be defined here
    fertiPlanAdjustaCountry.belongsTo(models.fertiPlanAdjusta,{
      foreignKey: { name: "fertiPlanCountryRef_id", allowNull: false },
      onDelete: "CASCADE",
    })
  };
  return fertiPlanAdjustaCountry;
};