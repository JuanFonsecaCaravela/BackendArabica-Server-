"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("plot", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      plot_id: {
        type: Sequelize.STRING(255)
      },
      total_area: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
      },
      total_trees: {
        type: Sequelize.DOUBLE,
        defaultValue: 0
      },
      planting_distance: {
        type: Sequelize.STRING(50),
        defaultValue: "NA"
      },
      seed_date: {
        type: Sequelize.DATEONLY,
        allowNull: true,
      },
      flowering_registry: {
        type: Sequelize.DATEONLY,
        allowNull: true,
      },
      farm_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "farm",
          key: "id"
        }
      },
      coffee_variety_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "coffee_variety",
          key: "id"
        }
      },
      deleteAt: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("plot");
  }
};
