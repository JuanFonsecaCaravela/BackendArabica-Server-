'use strict'

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('photoFarms', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      uuid: {
        type: Sequelize.STRING,
        defaultValue: 'NA'
      },
      unique_id: {
        type: Sequelize.STRING,
        defaultValue: 'NA'
      },
      photo: {
        type: Sequelize.STRING(500),
        defaultValue: 'NA'
      },

      farm_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'farm',
          key: 'id'
        }
      },

      date: {
        allowNull: true,
        type: Sequelize.DATE
      },
      state_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'state',
          key: 'id'
        }
      },
      deleteAt: {
        allowNull: true,
        type: Sequelize.DATE
      },

      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    })
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('photoFarms')
  }
}
