'use strict';
module.exports = (sequelize, DataTypes) => {
    const QuestionnaireQuestionType = sequelize.define('QuestionnaireQuestionType', {
        description: DataTypes.STRING,
        unique_id: DataTypes.STRING,
        delete_at: DataTypes.DATE
      },
      {
        /*freezeTableName: true,
        name: {
          singular: "QuestionnaireQuestionType",
          plural: "QuestionnaireQuestionType"
        }*/
      }
    );
    QuestionnaireQuestionType.associate = function(models) {
      // associations can be defined here
    };
    return QuestionnaireQuestionType;
};