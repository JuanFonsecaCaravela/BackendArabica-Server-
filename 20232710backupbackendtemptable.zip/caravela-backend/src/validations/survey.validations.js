const { body } = require("express-validator");

const findAll = () => {
  return [
    body("page")
      .exists()
      .withMessage("page doesn't exists")
      .not()
      .isEmpty()
      .withMessage("page isEmpty"),
    body("paginate")
      .exists()
      .withMessage("paginate doesn't exists")
      .not()
      .isEmpty()
      .withMessage("paginate isEmpty")
  ];
};

export default { findAll };
