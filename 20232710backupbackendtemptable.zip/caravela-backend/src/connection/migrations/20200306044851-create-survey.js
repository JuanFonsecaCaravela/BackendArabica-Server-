"use strict";
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("survey", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      categoria: {
        type: Sequelize.STRING(30),
        allowNull: false,
        get: function() {
          return this.getDataValue("categoria");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("categoria", capitalize.words(value));
        }
      },
      version: {
        type: Sequelize.INTEGER,
        allowNull: false
      },

      estado: {
        type: Sequelize.INTEGER,
        allowNull: false
      },

      creator_user_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        // references: {
        //   model: "caravela_user",
        //   key: "id"
        // }
      },

      title: {
        type: Sequelize.STRING(200),
        allowNull: false
      },

      iddispositivo: {
        type: Sequelize.STRING(100),
        allowNull: false
      },

      departament_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "department",
          key: "id"
        }
      },

      date_ini: {
        type: Sequelize.DATEONLY,
        allowNull: false
      },

      date_end: {
        type: Sequelize.DATEONLY,
        allowNull: false
      },

      description: {
        type: Sequelize.STRING(1000),
        allowNull: false,
        get: function() {
          return this.getDataValue("description");
        },
        set: function(value) {
          if (value && value != "")
            this.setDataValue("description", capitalize.words(value)); 
        }
      },
      unique_id: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      delete_user_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: "caravela_user",
          key: "id"
        }
      },
      delete_at: {
        type: Sequelize.DATE,
        allowNull: true
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("survey");
  }
};
