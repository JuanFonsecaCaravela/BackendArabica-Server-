'use strict';
module.exports = (sequelize, DataTypes) => {
  const user_tenant = sequelize.define('user_tenant', {
    id_tenant: DataTypes.INTEGER,
    id_user: DataTypes.INTEGER,
    admin: DataTypes.BOOLEAN,
    type_admin: DataTypes.INTEGER
  }, {});
  user_tenant.associate = function(models) {
    // associations can be defined here
  };
  return user_tenant;
};