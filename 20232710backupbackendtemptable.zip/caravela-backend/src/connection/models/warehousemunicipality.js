'use strict';
module.exports = (sequelize, DataTypes) => {
  const wareHouseMunicipality = sequelize.define('wareHouseMunicipality', {
    wareHouseMuniciId:DataTypes.STRING,
    country_id: DataTypes.INTEGER,
    department_id: DataTypes.INTEGER,
    muncipality_id: DataTypes.INTEGER,
    wareHouse_id: DataTypes.INTEGER
  }, {});
  wareHouseMunicipality.associate = function(models) {
    wareHouseMunicipality.belongsTo(models.wareHouse,{
      foreignKey: { name: "wareHouse_id", allowNull: false },
      onDelete: "CASCADE",
    })
    // associations can be defined here
  };
  return wareHouseMunicipality;
};


// 'use strict';
// module.exports = (sequelize, DataTypes) => {
//   const wareHouseMunicipality = sequelize.define('wareHouseMunicipality', {
//     wareHouseMuniciId:DataTypes.STRING,
//     muncipality_id: DataTypes.INTEGER,
//     wareHouse_id: DataTypes.INTEGER
//   }, {});
//   wareHouseMunicipality.associate = function(models) {
//     wareHouseMunicipality.belongsTo(models.wareHouse,{
//       foreignKey: { name: "wareHouse_id", allowNull: false },
//       onDelete: "CASCADE",
//     })

//     wareHouseMunicipality.hasMany(models.wareHouseDepartment,{
//       foreignKey: { name: "wareHouseMunici_id", allowNull: false },
//       onDelete: 'CASCADE'
//     })
    
//     // associations can be defined here
//   };
//   return wareHouseMunicipality;
// };



