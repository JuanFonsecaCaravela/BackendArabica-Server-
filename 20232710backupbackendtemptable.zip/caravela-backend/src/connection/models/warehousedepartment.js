'use strict';
module.exports = (sequelize, DataTypes) => {
  const wareHouseDepartment = sequelize.define('wareHouseDepartment', {
    department_id: DataTypes.INTEGER,
    wareHouseMunici_id: DataTypes.INTEGER
  }, {});
  wareHouseDepartment.associate = function(models) {
    // associations can be defined here
    wareHouseDepartment.belongsTo(models.wareHouseMunicipality,{
      foreignKey: { name: "wareHouseMunici_id", allowNull: false },
      onDelete: "CASCADE",
    })
    wareHouseDepartment.hasMany(models.wareHouseCountry,{
      foreignKey: { name: "wareHouseCountry_id", allowNull: false },
      onDelete: 'CASCADE'
    })
  };
  return wareHouseDepartment;
};