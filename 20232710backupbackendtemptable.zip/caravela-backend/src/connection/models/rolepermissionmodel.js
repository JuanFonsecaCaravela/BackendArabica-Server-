"use strict";
module.exports = (sequelize, DataTypes) => {
  const RolePermissionModel = sequelize.define(
    "RolePermissionModel",
    {
      id_role: DataTypes.INTEGER,
      id_permission: DataTypes.INTEGER
    },
    {}
  );
  RolePermissionModel.associate = function(models) {
    RolePermissionModel.belongsTo(models.Role, {
      foreignKey: { name: "id_role", allowNull: false }
    });
    RolePermissionModel.belongsTo(models.PermissionModel, {
      foreignKey: { name: "id_permission", allowNull: false }
    });
  };
  return RolePermissionModel;
};
