import jwt from 'jsonwebtoken'
// import moment from 'moment-timezone'
const createTokenAtlas = (user) => {
  try {
    const privateKeyStagin = '-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIO5PyP4aviYXveiioaor03R9RXPIUqH7jsZnijF9ak/poAoGCCqGSM49\nAwEHoUQDQgAE7QyZM+/139H65KyzUIkX08hwUtE1alNhDfOFA9ucR8NGQsbWK4M9\nn9aShGgKCTrbnK0OZVfJ9xdmw/gmSAZ07Q==\n-----END EC PRIVATE KEY-----\n';
    const privateKey = '-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIOlWkIFTRdA32Fl5q+cag2lKpFjZJ7EahExuQddEm+RsoAoGCCqGSM49\nAwEHoUQDQgAEV+aSp2lyq7pc1xPotwz0Ok+P4WRMJcCAzGizrmQ8Pf/RzInYzyMP\nhTajSGQKnAfRUeVkxhbf+UkM0zd02nrsww==\n-----END EC PRIVATE KEY-----\n';
    // const now = moment()
    const payload = {
      iss: 'arabica',
      exp: Math.floor(Date.now() / 1000) + (60 * 60) * 4 // expiring in 4 hour
    }
    const token = jwt.sign(payload, privateKey, { algorithm: 'ES256' })
    return token
  } catch (error) {
    console.log('Hubo un error generando el token de ATLAS: ', error)
    return null
  }
}


export default {
  createTokenAtlas
}
