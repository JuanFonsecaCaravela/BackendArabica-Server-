import express from "express";
import nutritionController from "../controllers/nutrition.controller";
const router = express.Router()

router.post('/addnutri', nutritionController.addNutrition)
router.get('/getnutri', nutritionController.getNutrition)
router.post('/getNutritionPaginate', nutritionController.getNutritionPaginate)
router.get('/getNutriByid/:id', nutritionController.getNutritionByid)
router.put('/updateNutri', nutritionController.updateNutrition)
router.put('/updateNutriById', nutritionController.updateNutriById)
router.delete('/deleteNutri/:id', nutritionController.deleteNutrition)
router.post('/filterNutrient',nutritionController.filterNutrient)

export default router;
