'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction((t) => {
      return Promise.all([
        queryInterface.changeColumn(
          "Nutrition",
          "maximum_excess",
          {
            type: Sequelize.DataTypes.STRING(50),
            allowNull: true,
          },
          { transaction: t }
        )
      ])
    })
  },  
  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  }
};
