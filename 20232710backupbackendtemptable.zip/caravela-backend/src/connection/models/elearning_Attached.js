"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const elearning_Attached = sequelize.define(
    "elearning_Attached",
    {
      elearning_Attached_id: DataTypes.STRING,
      name: DataTypes.STRING,
      id_elearning_Task_type: DataTypes.INTEGER,
      id_elearning_Body: DataTypes.INTEGER,
      version: DataTypes.STRING,
      createdAt: DataTypes.DATE,
      state_id: DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "elearning_Attached",
        plural: "elearning_Attached"
      }
    }
  );

  elearning_Attached.associate = function (models) {

    elearning_Attached.belongsTo(models.elearning_Body, {
      foreignKey: { name: "id_elearning_Body", allowNull: true }
    });
    elearning_Attached.belongsTo(models.elearning_Task_Type, {
      foreignKey: { name: "id_elearning_Task_type", allowNull: true }
    });

  };
  sequelizePaginate.paginate(elearning_Attached);
  return elearning_Attached;
};
