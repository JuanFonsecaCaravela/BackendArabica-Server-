'use strict'
module.exports = (sequelize, DataTypes) => {
  const category = sequelize.define(
    'category',
    {
      name: DataTypes.STRING,
      uuid: DataTypes.STRING,
      description: DataTypes.STRING,
      order: DataTypes.INTEGER,
      version: DataTypes.INTEGER,
      surveyId: DataTypes.INTEGER,
      id_category: DataTypes.STRING,
      id_condicionation: DataTypes.STRING,
      id_option_condicionation: DataTypes.STRING,
      condicionation: DataTypes.BOOLEAN
    },
    {}
  )
  category.associate = function (models) {
    this.belongsTo(models.survey, {
      foreignKey: { name: 'surveyId', allowNull: true }
    })
    this.hasMany(models.question, {
      foreignKey: { name: 'categoryId', allowNull: true }
    })
  }
  return category
}
