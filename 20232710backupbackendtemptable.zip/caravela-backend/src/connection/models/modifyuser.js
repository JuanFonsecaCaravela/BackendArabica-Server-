'use strict';
module.exports = (sequelize, DataTypes) => {
  const ModifyUser = sequelize.define('ModifyUser', {
    tech_from: DataTypes.INTEGER,
    tech_to: DataTypes.INTEGER,
    producer: DataTypes.INTEGER
  }, {});
  ModifyUser.associate = function(models) {
    ModifyUser.belongsTo(models.caravela_user, {
      foreignKey: { name: "producer", allowNull: false }
    })
  };
  return ModifyUser;
};