"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const type_log = sequelize.define(
    "type_log",
    {
      unique_id: DataTypes.STRING,
      type_log: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      id_tenant:DataTypes.INTEGER,
    },
    {
    
    }
  );
  type_log.associate = function (models) {
   
  };
  sequelizePaginate.paginate(type_log);
  return type_log;
};
