'use strict';
module.exports = (sequelize, DataTypes) => {
  const Loadertable = sequelize.define('Loadertable', {
    loaderTime: DataTypes.INTEGER
  }, {});
  Loadertable.associate = function(models) {
    // associations can be defined here
  };
  return Loadertable;
};