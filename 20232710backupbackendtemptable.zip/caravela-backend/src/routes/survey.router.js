import express from 'express'
import jwtService from '../services/jwt.service'
import ctrlSurvey from '../controllers/survey.controller'
import SurveyValidations from '../validations/survey.validations'

const router = express.Router()

// const verifyToken = jwtService.verifyToken;


router.post('/v2/create', ctrlSurvey.createv2)
router.post('/v2/filter', ctrlSurvey.filterSurvey)
router.put('/v2/update', ctrlSurvey.updatev2)
router.get('/v2/find/:id', ctrlSurvey.findByIdv2)

router.get('/v3/find/:id', ctrlSurvey.findByIdv3)
// router.get('/get-survey/create', ctrlSurvey.getSurveyCreate)

router.post('/create', ctrlSurvey.create)
router.put('/', ctrlSurvey.update)

router.put('/enable', ctrlSurvey.updateEnable)

router.post('/all', [SurveyValidations.findAll()], ctrlSurvey.findAll)

router.post('/allFilter', [SurveyValidations.findAll()], ctrlSurvey.findAllFilter)

router.get('/:id', ctrlSurvey.findById)

router.delete('/:id', ctrlSurvey.deleteSurvey)

router.post('/associate', ctrlSurvey.associate)

router.get('/get-survey/create', ctrlSurvey.getSurveyCreate)
router.get('/get-survey/associate/:version/:uuid', ctrlSurvey.geSurveyAssociate)
router.get('/v2/get-survey/associate/:version/:uuid', ctrlSurvey.geSurveyAssociatev2)
router.post('/get-survey/associatebypeca/:version/:uuid', ctrlSurvey.geSurveyAssociatebyIdPeca)

router.post('/v2/get-survey/associatebypeca/:version/:uuid', ctrlSurvey.geSurveyAssociatebyIdPecav2)

router.get('/v2/regularizationDataSurvey', ctrlSurvey.regularizationDataSurveyv2)
router.get('/v2/regularizationVersionOptions', ctrlSurvey.versionOptionQuestion)

router.post("/multiplePdf", ctrlSurvey.getMultiPdfUuid);
router.post("/deleteDirPublicFolder", ctrlSurvey.deleteDirPublicFolder);


export default router