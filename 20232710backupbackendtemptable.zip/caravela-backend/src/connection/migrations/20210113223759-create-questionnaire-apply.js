'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('questionnaireApplies', {
            id: {
              allowNull: false,
              autoIncrement: true,
              primaryKey: true,
              type: Sequelize.INTEGER
            },
            id_country: {
              type: Sequelize.INTEGER,
              allowNull:false,
              references: {
                model: "country",
                key: "id"
              }
            },
            id_deparment: {
              type: Sequelize.INTEGER,
              allowNull:true,
              references: {
                model: "department",
                key: "id"
              }
            },
            id_survey: {
              type: Sequelize.INTEGER,
              allowNull:false,
              references: {
                model: "questionnaires",
                key: "id" 
              }
            },
            createdAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            updatedAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            version:{
              type: Sequelize.DataTypes.INTEGER,
              allowNull: true,
              defaultValue: 0,
            },


          });
    },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('questionnaireApplies');
    }
};