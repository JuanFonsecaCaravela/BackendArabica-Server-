'use strict';
module.exports = (sequelize, DataTypes) => {
  const elearningv2Attached = sequelize.define('elearningv2Attached', {
    elearningv2_Attached_id: DataTypes.INTEGER,
    name: DataTypes.STRING,
    elearningv2TaskTypes_id: DataTypes.INTEGER,
    elearningv2_session_id: DataTypes.INTEGER,
    version: DataTypes.STRING,
    state_id: DataTypes.INTEGER
  }, {});
  elearningv2Attached.associate = function(models) {
    // associations can be defined here


    elearningv2Attached.belongsTo(models.elearningv2session, {
      foreignKey: { name: "elearningv2_session_id", allowNull: true }
    });
    elearningv2Attached.belongsTo(models.elearningv2TaskType, {
      foreignKey: { name: "elearningv2TaskTypes_id", allowNull: true }
    });
  };
  return elearningv2Attached;
};