'use strict';
module.exports = (sequelize, DataTypes) => {
  const Land_Use = sequelize.define('Land_Use', {
    uuid: DataTypes.STRING,
    description_spanish: DataTypes.STRING,
    description_english: DataTypes.STRING,
    state_id: DataTypes.INTEGER
  }, {});
  Land_Use.associate = function(models) {
    // associations can be defined here
  };
  return Land_Use;
};