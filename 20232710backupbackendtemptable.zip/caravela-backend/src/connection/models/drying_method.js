"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const drying_method = sequelize.define(
    "drying_method",
    {
      drying_method_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      i18n: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "drying_method",
        plural: "drying_method"
      }
    }
  );

  drying_method.associate = function(models) {    
    drying_method.belongsToMany(models.farm, { 
      through: models.farm_drying_method, foreignKey: 'drying_method_id' 
    });
  };
  sequelizePaginate.paginate(drying_method);
  return drying_method;
};
