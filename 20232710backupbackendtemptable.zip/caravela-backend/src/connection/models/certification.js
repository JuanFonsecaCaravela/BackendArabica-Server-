"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const certification = sequelize.define(
    "certification",
    {
      certification_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      i18n: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "certification",
        plural: "certification"
      }
    }
  );

  certification.associate = function(models) {
    
    certification.belongsToMany(models.farm, { 
      through: models.farm_certification, foreignKey: 'certification_id' , allowNull: false
    });
  };
  sequelizePaginate.paginate(certification);
  return certification;
};
