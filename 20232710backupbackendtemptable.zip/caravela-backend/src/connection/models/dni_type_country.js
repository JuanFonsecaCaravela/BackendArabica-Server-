"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const dni_type_country = sequelize.define(
    "dni_type_country",
    {
      dni_type_country_id: DataTypes.STRING,
      country_id: DataTypes.STRING,
      dni_type_id: DataTypes.STRING
    },
    {
      freezeTableName: true,
      name: {
        singular: "dni_type_country",
        plural: "dni_type_country"
      }
    }
  );

  dni_type_country.associate = function(models) {
    // associations can be defined here

    dni_type_country.belongsTo(models.dni_type, {
      foreignKey: "dni_type_id"
    });
    dni_type_country.belongsTo(models.country, {
      foreignKey: "country_id"
    });
  };
  sequelizePaginate.paginate(dni_type_country);
  return dni_type_country;
};
