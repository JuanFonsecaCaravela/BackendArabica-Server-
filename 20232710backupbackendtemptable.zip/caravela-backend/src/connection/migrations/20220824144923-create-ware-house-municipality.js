'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('wareHouseMunicipalities', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      wareHouseMuniciId: {
        type: Sequelize.STRING
      },
      country_id: {
        type: Sequelize.INTEGER
      },
      department_id: {
        type: Sequelize.INTEGER
      },
      muncipality_id: {
        type: Sequelize.INTEGER
      },
      wareHouse_id: {
        type: Sequelize.INTEGER,
        onDelete: 'CASCADE',
        allowNull: true,   
        references: {
          model: "wareHouses",
          key: "id"
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('wareHouseMunicipalities');
  }
};







// 'use strict';
// module.exports = {
//   up: (queryInterface, Sequelize) => {
//     return queryInterface.createTable('wareHouseMunicipalities', {
//       id: {
//         allowNull: false,
//         autoIncrement: true,
//         primaryKey: true,
//         type: Sequelize.INTEGER
//       },
//       wareHouseMuniciId: {
//         type: Sequelize.STRING
//       },
//       muncipality_id: {
//         type: Sequelize.INTEGER
//       },
//       wareHouse_id: {
//         type: Sequelize.INTEGER,
//         onDelete: 'CASCADE',
//         allowNull: true,   
//         references: {
//           model: "wareHouses",
//           key: "id"
//         }
//       },
//       createdAt: {
//         allowNull: false,
//         type: Sequelize.DATE
//       },
//       updatedAt: {
//         allowNull: false,
//         type: Sequelize.DATE
//       }
//     });
//   },
//   down: (queryInterface, Sequelize) => {
//     return queryInterface.dropTable('wareHouseMunicipalities');
//   }
// };




