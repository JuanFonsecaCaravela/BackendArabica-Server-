"use strict";
module.exports = (sequelize, DataTypes) => {
  const farm_drying_method = sequelize.define(
    "farm_drying_method",
    {
      drying_time: DataTypes.INTEGER,
      farm_id: DataTypes.INTEGER,
      drying_method_id: DataTypes.INTEGER,
      unique_id : DataTypes.STRING,
      state_id: DataTypes.INTEGER
    },
    {
      freezeTableName: true,
      name: {
        singular: "farm_drying_method",
        plural: "farm_drying_method"
      }
    }
  );
  farm_drying_method.associate = function(models) {
    farm_drying_method.belongsTo(models.farm, {
      foreignKey: { name: "farm_id", allowNull: false }
    });
    farm_drying_method.belongsTo(models.drying_method, {
      foreignKey: { name: "drying_method_id", allowNull: false }
    });
  };
  return farm_drying_method;
};
