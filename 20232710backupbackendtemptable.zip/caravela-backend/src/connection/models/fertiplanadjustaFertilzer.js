'use strict';
module.exports = (sequelize, DataTypes) => {
  const fertiPlanAdjustaFertilizer = sequelize.define('fertiPlanAdjustaFertilizer', {
    fertilizer_id: DataTypes.STRING,
    fertilizer: DataTypes.STRING, 
    cantidad: DataTypes.STRING,
    fertiPlanRef_id: DataTypes.INTEGER
  }, {});
  fertiPlanAdjustaFertilizer.associate = function(models) {
    fertiPlanAdjustaFertilizer.belongsTo(models.fertiPlanAdjusta,{
      foreignKey: { name: "fertiPlanRef_id", allowNull: false },
      onDelete: "CASCADE",
    })    
  };
  return fertiPlanAdjustaFertilizer;
};