"use strict"
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const farm = sequelize.define(
    "farm",
    {
      farm_id: DataTypes.STRING,
      name: {
        type: DataTypes.STRING,
        set(value) {
          if (value)
            this.setDataValue('name', value.toUpperCase())
          else
            this.setDataValue('name', value)
        },
        get() {
          return this.getDataValue('name')
        },
      },
      location: DataTypes.STRING,
      gps_longitude: DataTypes.DOUBLE,
      gps_latitude: DataTypes.DOUBLE,
      masl_height: DataTypes.DOUBLE,
      total_area: DataTypes.DOUBLE,
      total_coffee_area: DataTypes.DOUBLE,
      total_coffee_productive_area: DataTypes.DOUBLE,
      total_coffee_renovation_area: DataTypes.DOUBLE,
      has_certifications: DataTypes.BOOLEAN,
      harvest_period: DataTypes.DATE,
      flycrop_period: DataTypes.DATE,
      village: DataTypes.STRING,
      notes: DataTypes.STRING,
      media: DataTypes.TEXT,
      plots_number: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      id_municipality: DataTypes.INTEGER,
      updatedAt: DataTypes.DATE,
      state_id: DataTypes.INTEGER,
      story:DataTypes.STRING,
      QRCodeIn : DataTypes.STRING,
    },
    {
      freezeTableName: true,
      name: {
        singular: "farm",
        plural: "farm"
      }
    }
  )
  farm.associate = function (models) {
    farm.hasMany(models.farm_harvest_period, {
      foreignKey: { name: "farm_id", allowNull: false }
    })
    farm.hasMany(models.farm_flycrop_period, {
      foreignKey: { name: "farm_id", allowNull: false }
    })
    farm.hasMany(models.PlannerProgrammingHead, {
      foreignKey: { name: "farm_id", allowNull: false }
    })
    // associations can be defined here
    farm.hasMany(models.plot, {
      foreignKey: { name: "farm_id", allowNull: false }
    })
    farm.hasMany(models.photoFarm, {
      foreignKey: { name: "farm_id", allowNull: false }
    })
    farm.belongsTo(models.caravela_user, {
      foreignKey: { name: "user_id", allowNull: false }
    })
    farm.belongsTo(models.municipality, {
      foreignKey: { name: "id_municipality", allowNull: true }
    })
    farm.belongsToMany(models.certification, {
      through: models.farm_certification, foreignKey: 'farm_id', allowNull: false
    })
    farm.belongsToMany(models.drying_method, {
      through: models.farm_drying_method, foreignKey: 'farm_id'
    })
    farm.belongsToMany(models.fermentation_type, {
      through: models.farm_fermentation_type, foreignKey: 'farm_id'
    })
    farm.belongsToMany(models.process_type, {
      through: models.farm_procces_type, foreignKey: 'farm_id'
    })
  }
  sequelizePaginate.paginate (farm);
  return farm
}
