"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const scholarship = sequelize.define(
    "scholarship",
    {
      scholarship_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      i18n: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      id_tenant:DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: "scholarship",
        plural: "scholarship"
      }
    }
  );
  
  scholarship.associate = function(models) {
    
    scholarship.hasMany(models.family_member, {
      foreignKey: { name: "scholarship_id", allowNull: true }
    });
    
    
    scholarship.hasMany(models.caravela_user, {
      foreignKey: { name: "scholarship_id", allowNull: false }
    });
  };
  sequelizePaginate.paginate(scholarship);
  return scholarship;
};
