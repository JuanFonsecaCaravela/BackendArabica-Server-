'use strict';
module.exports = (sequelize, DataTypes) => {
    const questionnaireQuestionsAssociate = sequelize.define('questionnaireQuestionsAssociate', {
        id_question: DataTypes.INTEGER,
        id_question_create: DataTypes.INTEGER,
        operation_type: DataTypes.INTEGER,
        number_operation: DataTypes.STRING,
        operation: DataTypes.STRING,
        parenthesisL: DataTypes.BOOLEAN,
        parenthesisR: DataTypes.BOOLEAN,
        id_category: DataTypes.STRING,
        id_question_id_device: DataTypes.STRING
      },
      {}
    )
    questionnaireQuestionsAssociate.associate = function (models) {
        questionnaireQuestionsAssociate.belongsTo(models.QuestionnaireQuestion, {
        as: 'QuestionA',
        foreignKey: { name: 'id_question', allowNull: true }
      })
      questionnaireQuestionsAssociate.belongsTo(models.QuestionnaireQuestion, {
        as: 'QuestionC',
        foreignKey: { name: 'id_question_create', allowNull: false }
      })
    };
    return questionnaireQuestionsAssociate;
};