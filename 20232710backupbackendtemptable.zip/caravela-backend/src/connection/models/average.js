'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const Average = sequelize.define (
    'Average',
    {
      average: DataTypes.DECIMAL,
      description: DataTypes.STRING,
      id_department: DataTypes.INTEGER,
      id_CostCategory: DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: 'Average',
        plural: 'Average',
      },
    }
  );

  Average.associate = function (models) {

    Average.belongsTo (models.costCategory, {
      foreignKey: {name: 'id_CostCategory', allowNull: true},
    });

    
    Average.belongsTo (models.department, {
      foreignKey: {name: 'id_CostCategory', allowNull: false},
    });
  };
  sequelizePaginate.paginate (Average);
  return Average;
};
