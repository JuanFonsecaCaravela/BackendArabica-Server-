'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.transaction (t => {
      return Promise.all ([
        queryInterface.addColumn (
          'elearning_Head',
          'state_id',
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: true,
            defaultValue: null,
            references: {
              model: 'state',
              key: 'id',
            },
          },
          {transaction: t}
        ),
        queryInterface.addColumn (
          'elearning_Head',
          'userCreate',
          {
            type: Sequelize.DataTypes.INTEGER,
            allowNull: true,
            defaultValue: null,
            references: {
              model: 'caravela_user',
              key: 'id',
            },
          },
          {transaction: t}
        ),
        queryInterface.changeColumn (
          'elearning_Head',
          'deleteAt',
          {
            type: Sequelize.DataTypes.DATE,
            allowNull: true,
            defaultValue: null,
          },
          {transaction: t}
        ),
        queryInterface.addColumn (
          'elearning_Head',
          'version',
          {
            type: Sequelize.DataTypes.STRING,
            allowNull: true,
            defaultValue: null,
          },
          {transaction: t}
        ),
      ]);
    });
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.dropTable('users');
    */
  },
};
