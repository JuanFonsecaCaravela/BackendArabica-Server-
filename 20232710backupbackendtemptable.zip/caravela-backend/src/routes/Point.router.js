import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlPoint from '../controllers/Point.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', verifyToken, ctrlPoint.create);


router.put('/', verifyToken, ctrlPoint.update);

router.post('/all', verifyToken, ctrlPoint.findAll);

router.get('/:id', verifyToken, ctrlPoint.findById);

router.delete('/:id', verifyToken, ctrlPoint.deleteOne);

export default router;