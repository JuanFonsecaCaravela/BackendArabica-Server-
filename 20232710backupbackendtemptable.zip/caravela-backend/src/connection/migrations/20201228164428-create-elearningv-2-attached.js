'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('elearningv2Attacheds', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      elearningv2_Attached_id: {
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING
      },
      elearningv2TaskTypes_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "elearningv2TaskTypes",
          key: "id",
        },
      },
      elearningv2_session_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'elearningv2sessions',
          key: 'id'
        }
      },
      version: {
        type: Sequelize.STRING
      },
      state_id: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('elearningv2Attacheds');
  }
};