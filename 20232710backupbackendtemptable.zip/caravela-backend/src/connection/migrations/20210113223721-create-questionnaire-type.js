'use strict';
module.exports = {
    up: (queryInterface, Sequelize) => {
        return queryInterface.createTable('questionnaire_types', {
            id: {
              allowNull: false,
              autoIncrement: true,
              primaryKey: true,
              type: Sequelize.INTEGER
            },
            survey_type_id: {
              type: Sequelize.STRING(255)
            },
            name: {
              type: Sequelize.STRING(255), 
              defaultValue: "NA",
              get: function() {
                return this.getDataValue("spanish_name");
              },
              set: function(value) {
                this.setDataValue("spanish_name", capitalize(value));
              }
            },
            createdAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            updatedAt: {
              allowNull: false,
              type: Sequelize.DATE
            },
            deleteAt:{
              type: Sequelize.DataTypes.DATE,
              allowNull: true,
            },
            state_id:{
              type: Sequelize.DataTypes.INTEGER,
              defaultValue: 1,
              allowNull: true,
              references: {
                  model: "state",
                  key: "id",
              },
            },

          });
    },
    down: (queryInterface, Sequelize) => {
        return queryInterface.dropTable('questionnaire_types');
    }
};