"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const country = sequelize.define(
    "country",
    {
      country_id: DataTypes.STRING,
      spanish_name: DataTypes.STRING,
      area_units: DataTypes.STRING,
      area_units_spanish_name: DataTypes.STRING,
      currency_type: DataTypes.STRING,
      weight_units: DataTypes.STRING,
      weight_units_spanish_name: DataTypes.STRING,
      iso_code: DataTypes.STRING,
      country_code: DataTypes.STRING,
      language: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      bulto:DataTypes.INTEGER
    },
    {
      freezeTableName: true,
      name: {
        singular: "country",
        plural: "country"
      }
    }
  );

  country.associate = function(models) {
    // associations can be defined here
    country.belongsToMany(models.dni_type, {
      through: 'dni_type_country',
      foreignKey: "country_id",
    });
    
    country.hasMany(models.SurveyApply, {
      foreignKey: { name: "id_country", allowNull: false },
    });
    country.hasMany(models.current_versionservice, {
      foreignKey: { name: "id_country", allowNull: true }
    });

    country.hasMany(models.department, { foreignKey: { name: 'country_id', allowNull: false } });
  };
  sequelizePaginate.paginate(country);
  return country;
};
