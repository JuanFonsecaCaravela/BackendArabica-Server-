import express from 'express'
import jwtService from '../services/jwt.service'
import ctrlSurveyType from '../controllers/survey_type.controller'

const router = express.Router()

const verifyToken = jwtService.verifyToken

router.post('/', ctrlSurveyType.create)

router.put('/', verifyToken, ctrlSurveyType.update)

router.post('/all', verifyToken, ctrlSurveyType.findAll)

router.get('/:id', verifyToken, ctrlSurveyType.findById)

router.delete('/:id', verifyToken, ctrlSurveyType.deleteOne)

export default router