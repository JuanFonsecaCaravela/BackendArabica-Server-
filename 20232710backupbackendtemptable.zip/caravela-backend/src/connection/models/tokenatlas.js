'use strict';
module.exports = (sequelize, DataTypes) => {
  const TokenAtlas = sequelize.define('TokenAtlas', {
    token: DataTypes.STRING,
    expirationDate: DataTypes.DATE
  }, {});
  TokenAtlas.associate = function(models) {
    // associations can be defined here
  };
  return TokenAtlas;
};