import express from 'express'
import jwtService from '../services/jwt.service'
import ctrlQuestionnaire from '../controllers/questionnaire.controller'
import SurveyValidations from '../validations/survey.validations'

const router = express.Router()

// const verifyToken = jwtService.verifyToken;


router.post('/v2/create', ctrlQuestionnaire.createv2)
router.put('/v2/update', ctrlQuestionnaire.updatev2)
router.get('/v2/find/:id', ctrlQuestionnaire.findByIdv2)
router.get('/v2/findElearning/:id', ctrlQuestionnaire.findByIdV2ElearningV2)

    // router.get('/get-survey/create', ctrlSurvey.getSurveyCreate)

router.post('/create', ctrlQuestionnaire.create)
router.put('/', ctrlQuestionnaire.update)

router.put('/enable', ctrlQuestionnaire.updateEnable)

router.post('/all', [SurveyValidations.findAll()], ctrlQuestionnaire.findAll)

router.post('/allFilter', [SurveyValidations.findAll()], ctrlQuestionnaire.findAllFilter)

router.get('/:id', ctrlQuestionnaire.findById)

router.delete('/:id', ctrlQuestionnaire.deleteSurvey)

router.post('/associate', ctrlQuestionnaire.associate)

router.get('/get-survey/create', ctrlQuestionnaire.getSurveyCreate)
router.get('/get-survey/associate/:version/:uuid', ctrlQuestionnaire.geSurveyAssociate)
router.get('/v2/get-survey/associate/:version/:uuid', ctrlQuestionnaire.geSurveyAssociatev2)
router.post('/get-survey/associatebypeca/:version/:uuid', ctrlQuestionnaire.geSurveyAssociatebyIdPeca)

router.post('/v2/get-survey/associatebypeca/:version/:uuid', ctrlQuestionnaire.geSurveyAssociatebyIdPecav2)

router.get('/v2/regularizationDataSurvey', ctrlQuestionnaire.regularizationDataSurveyv2)



export default router