'use strict'
module.exports = (sequelize, DataTypes) => {
  const PlannerProgrammingBody = sequelize.define('PlannerProgrammingBody', {
    planner_programming_head_id: DataTypes.INTEGER,
    planner_master_id: DataTypes.INTEGER,
    check: DataTypes.BOOLEAN,
    starting_week: DataTypes.INTEGER,
    final_week: DataTypes.INTEGER,
    starting_week_real: DataTypes.INTEGER,
    starting_week_real_year: DataTypes.INTEGER,
    final_week_real: DataTypes.INTEGER,
    final_week_real_year: DataTypes.INTEGER,
    color: DataTypes.STRING,
    date_initial: DataTypes.DATEONLY,
    date_limit: DataTypes.DATEONLY,
    date_app_movil: DataTypes.DATEONLY,
    date_app_movil_check: DataTypes.DATEONLY,
    unique_id: DataTypes.STRING,
    name: DataTypes.STRING,
  }, {})
  PlannerProgrammingBody.associate = function (models) {


    PlannerProgrammingBody.belongsTo(models.PlannerProgrammingHead, {
      foreignKey: { name: "planner_programming_head_id", allowNull: false }
    })

    PlannerProgrammingBody.belongsTo(models.PlannerMaster, {
      foreignKey: { name: "planner_master_id", allowNull: false }
    })


  }
  return PlannerProgrammingBody
}