'use strict';
module.exports = (sequelize, DataTypes) => {
  const recoveryPassord = sequelize.define('recoveryPassord', {
    email_id: DataTypes.STRING,
    bcrypt_code: DataTypes.STRING
  }, {});
  recoveryPassord.associate = function(models) {
    // associations can be defined here
  };
  return recoveryPassord;
};