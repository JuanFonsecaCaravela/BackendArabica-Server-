'use strict';
module.exports = (sequelize, DataTypes) => {
  const Agroforestry_Type = sequelize.define('Agroforestry_Type', {
    uuid: DataTypes.STRING,
    description_spanish: DataTypes.STRING,
    description_english: DataTypes.STRING,
    state_id: DataTypes.INTEGER
  }, {});
  Agroforestry_Type.associate = function(models) {
    // associations can be defined here
  };
  return Agroforestry_Type;
};