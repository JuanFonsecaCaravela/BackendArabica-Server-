"use strict"
import sequelizePaginate from "sequelize-paginate"
import capitalize from 'capitalize'
module.exports = (sequelize, DataTypes) => {
  const civil_status = sequelize.define(
    "civil_status",
    {
      civil_status_id: DataTypes.STRING,
      i18n: DataTypes.STRING,
      id_tenant:DataTypes.INTEGER,

      spanish_name:
      {
        type: DataTypes.STRING,
        set(value) {
          this.setDataValue('spanish_name', value.toLowerCase())
        },
        get() {
          const spanish_name = this.getDataValue('spanish_name')
          return capitalize.words(spanish_name)
        },
      },
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
    },
    {
      freezeTableName: true,
      name: {
        singular: "civil_status",
        plural: "civil_status"
      }
    }
  )

  civil_status.associate = function (models) {
    civil_status.hasMany(models.caravela_user, {
      foreignKey: { name: "civil_status_id", allowNull: false }
    })
  }
  sequelizePaginate.paginate(civil_status)
  return civil_status
}
