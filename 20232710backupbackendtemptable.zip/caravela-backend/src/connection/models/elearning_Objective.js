"use strict";
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const elearning_Objective = sequelize.define(
    "elearning_Objective",
    {
      elearning_Objective_id: DataTypes.STRING,
      objective: DataTypes.STRING,
      id_elearning_Head: DataTypes.INTEGER,
      createdAt: DataTypes.DATE,
      state_id: DataTypes.INTEGER,
      version: DataTypes.STRING,
    },
    {
      freezeTableName: true,
      name: {
        singular: "elearning_Objective",
        plural: "elearning_Objective"
      }
    }
  );

  elearning_Objective.associate = function (models) {

    elearning_Objective.belongsTo(models.elearning_Head, {
      foreignKey: { name: "id_elearning_Head", allowNull: false }
    });

  };
  sequelizePaginate.paginate(elearning_Objective);
  return elearning_Objective;
};
