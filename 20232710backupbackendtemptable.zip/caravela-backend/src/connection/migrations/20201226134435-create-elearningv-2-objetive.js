'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('elearningv2Objetives', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      elearningv2_Objective_id: {
        type: Sequelize.STRING
      },
      objective: {
        type: Sequelize.STRING
      },
      course_id:{
        type: Sequelize.INTEGER,
       references: {
          model: 'elearningv2s',
          key: 'id'
        }
      },
      version: {
        type: Sequelize.STRING
      },
      state_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'state',
          key: 'id'
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('elearningv2Objetives');
  }
};