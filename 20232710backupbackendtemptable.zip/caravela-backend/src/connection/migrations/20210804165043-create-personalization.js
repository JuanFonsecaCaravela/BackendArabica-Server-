'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable ('Personalizations', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      uuid: {
        type: Sequelize.STRING,
      },
      description: {
        type: Sequelize.STRING,
      },
      imgM: {
        type: Sequelize.STRING (500),
      },
      imgF: {
        type: Sequelize.STRING (500),
      },
      imgNameM: {
        type: Sequelize.STRING,
      },
      imgNameF: {
        type: Sequelize.STRING,
      },
      colorA: {
        type: Sequelize.STRING,
      },
      colorB: {
        type: Sequelize.STRING,
      },
      colorC: {
        type: Sequelize.STRING,
      },
      colorD: {
        type: Sequelize.STRING,
      },

      state_id: {
        type: Sequelize.INTEGER,
      },
      deleteAt: {
        allowNull: true,
        type: Sequelize.DATE,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable ('Personalizations');
  },
};
