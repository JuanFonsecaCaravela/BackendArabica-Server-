'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const Point = sequelize.define ('Point', {
    unique_id: DataTypes.STRING,
    points: DataTypes.INTEGER,
    description: DataTypes.STRING,
    date: DataTypes.STRING,
    user_id: DataTypes.INTEGER,
    deleteAt: DataTypes.DATE,
  });
  Point.associate = function (models) {
    Point.belongsTo (models.caravela_user, {
      foreignKey: {name: 'user_id', allowNull: true},
    });
  };
  sequelizePaginate.paginate (Point);
  return Point;
};
