'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('elearningv2sessions', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      elearningv2_session_id: {
        type: Sequelize.STRING
      },
      titleStage: {
        type: Sequelize.STRING
      },
      description: {
        type: Sequelize.STRING
      },
      id_elearningv2_Task_type: {
        type: Sequelize.INTEGER,
        references: {
        model: 'elearningv2TaskTypes',
         key: 'id'
        }
      },
      duration: {
        type: Sequelize.INTEGER
      },
      typeduration: {
        type: Sequelize.STRING
      },
      course_id:{
        type: Sequelize.INTEGER,
        references: {
          model: 'elearningv2s',
         key: 'id'
        }
      },
      version: {
        type: Sequelize.STRING
      },
      state_id:{
        type: Sequelize.INTEGER,
        references: {
          model: 'state',
          key: 'id',
        },
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('elearningv2sessions');
  }
};