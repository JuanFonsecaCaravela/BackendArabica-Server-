"use strict";

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable("elearning_Body", {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      elearning_Body_id: {
        type: Sequelize.STRING(255),
      },
      title: {
        type: Sequelize.STRING(50),
        defaultValue: "NA",

      },

      description: {
        type: Sequelize.STRING(500),
        defaultValue: "NA",

      },

      id_elearning_Head: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: "elearning_Head",
          key: "id",
        },
      },
      version: {
        type: Sequelize.STRING,
        defaultValue: "NA",
      },
      state_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'state',
          key: 'id'
        }
      },

      deleteAt: {
        allowNull: true,
        type: Sequelize.DATE
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable("elearning_Body");
  }
};
