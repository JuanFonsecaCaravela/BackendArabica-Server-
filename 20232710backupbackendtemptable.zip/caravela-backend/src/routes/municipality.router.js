import express from 'express';
import jwtService from '../services/jwt.service';
import ctrlMunicipality from '../controllers/municipality.controller';

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.post('/', ctrlMunicipality.create);

router.put('/', verifyToken, ctrlMunicipality.update);

router.post('/all', verifyToken, ctrlMunicipality.findAll);

router.post('/id', verifyToken, ctrlMunicipality.findById);

router.get('/department/:id', ctrlMunicipality.findByDepartmentId);

router.delete('/:id', verifyToken, ctrlMunicipality.deleteOne);

router.post('/findMunicipalityByCountry', ctrlMunicipality.findMunicipalityByCountry);

export default router;