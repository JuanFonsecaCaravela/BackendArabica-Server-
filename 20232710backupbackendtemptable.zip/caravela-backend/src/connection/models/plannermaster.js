'use strict';
module.exports = (sequelize, DataTypes) => {
  const PlannerMaster = sequelize.define (
    'PlannerMaster',
    {
      description: DataTypes.STRING,
      unique_id: DataTypes.STRING,
      starting_week: DataTypes.INTEGER,
      i18n: DataTypes.STRING,
      final_week: DataTypes.INTEGER,
      color: DataTypes.STRING,
      required: DataTypes.BOOLEAN,
      visible: DataTypes.BOOLEAN,
      version: DataTypes.INTEGER,
      points: DataTypes.INTEGER,
      cost_id : DataTypes.INTEGER,
      id_tenant:DataTypes.INTEGER,

    },
    {}
  );
  PlannerMaster.associate = function (models) {
    PlannerMaster.hasMany (models.PlannerProgrammingBody, {
      foreignKey: {name: 'planner_master_id', allowNull: false},
    });

    PlannerMaster.belongsTo (models.cost_Body, {
      foreignKey: {name: 'cost_id', allowNull: false},
    });
  };
  return PlannerMaster;
};
