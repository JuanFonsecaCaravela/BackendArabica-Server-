"use strict"
module.exports = (sequelize, DataTypes) => {
  const plot = sequelize.define(
    "plot",
    {
      plot_id: DataTypes.STRING,
      total_area: DataTypes.DOUBLE,
      total_trees: DataTypes.DOUBLE,
      planting_distance_plants: DataTypes.STRING,
      row_planting_distance: DataTypes.STRING,
      seed_date: DataTypes.DATEONLY,
      flowering_registry: DataTypes.DATEONLY,
      farm_id: DataTypes.INTEGER,
      coffee_variety_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      state_id: DataTypes.INTEGER,
      name: {
        type: DataTypes.STRING,
        set(value) {
          if (value)
            this.setDataValue('name', value.toUpperCase())
          else
            this.setDataValue('name', value)
        },
        get() {
          return this.getDataValue('name')
        },
      },
    },
    {
      freezeTableName: true,
      name: {
        singular: "plot",
        plural: "plot"
      }
    }
  )
  plot.associate = function (models) {
    plot.belongsTo(models.farm, {
      foreignKey: { name: "farm_id", allowNull: false }
    })
    plot.hasMany(models.plot_share_tree, {
      foreignKey: { name: "plot_id", allowNull: false }
    })
    plot.belongsTo(models.coffee_variety, {
      foreignKey: { name: "coffee_variety_id", allowNull: false }
    })
    plot.belongsToMany(models.renovation_type, {
      through: models.plot_renovation,
      foreignKey: "plot_id"
    })
    plot.hasMany(models.PlannerProgrammingHead, {
      foreignKey: { name: "plot_id", allowNull: true }
    })
  }
  return plot
}
