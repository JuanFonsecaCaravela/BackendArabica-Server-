'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const Personalizations = sequelize.define (
    'Personalizations',
    {
      uuid: DataTypes.STRING,
      description: DataTypes.STRING,
      imgM: DataTypes.STRING,
      imgF: DataTypes.STRING,
      imgNameM: DataTypes.STRING,
      imgNameF: DataTypes.STRING,
      colorB: DataTypes.STRING,
      colorC: DataTypes.STRING,
      colorD: DataTypes.STRING,
      colorA: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
    },
    {
      freezeTableName: true,
      name: {
        singular: 'Personalizations',
        plural: 'Personalizations',
      },
    }
  );
  //Personalizations.associate = function (models) {};
  sequelizePaginate.paginate (Personalizations);
  return Personalizations;
};
