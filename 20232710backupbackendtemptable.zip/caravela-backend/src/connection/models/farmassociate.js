
"use strict"
import sequelizePaginate from "sequelize-paginate";
module.exports = (sequelize, DataTypes) => {
  const farmAssociate = sequelize.define(
    "farmAssociate",
    {
      farm_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      state_id: DataTypes.INTEGER,
      family_id: DataTypes.INTEGER,
      deletedAt: DataTypes.DATE
    },
    {}
  )
  farmAssociate.associate = function (models) {

    farmAssociate.belongsTo(models.farm, {
      foreignKey: { name: "farm_id", allowNull: true }
    });

    farmAssociate.belongsTo(models.family_member, {
      foreignKey: { name: "family_id", allowNull: true }
    });

    farmAssociate.belongsTo(models.caravela_user, {
      foreignKey: { name: "user_id", allowNull: true }
    });

  }
  sequelizePaginate.paginate(farmAssociate);
  return farmAssociate
}
