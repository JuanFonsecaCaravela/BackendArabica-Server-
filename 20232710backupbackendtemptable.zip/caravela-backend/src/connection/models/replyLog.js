'use strict';
import sequelizePaginate from 'sequelize-paginate';
module.exports = (sequelize, DataTypes) => {
  const replyLog = sequelize.define (
    'replyLog',
    {
      uuid_movil: DataTypes.STRING,
      uuid: DataTypes.STRING,
      value: DataTypes.STRING,
      date: DataTypes.DATE,
      hour: DataTypes.TIME,
      id_replyQuestion: DataTypes.INTEGER,
      deleteAt: DataTypes.DATE,
      description: DataTypes.STRING,
      state_id: DataTypes.INTEGER,
      typeQuestion: DataTypes.INTEGER,
    },
    {
      freezeTableName: true,
      name: {
        singular: 'replyLog',
        plural: 'replyLog',
      },
    }
  );

  replyLog.associate = function (models) {
    replyLog.belongsTo (models.replyQuestion, {
      foreignKey: {name: 'id_replyQuestion', allowNull: true},
    });
  };
  sequelizePaginate.paginate (replyLog);
  return replyLog;
};
