'use strict';
module.exports = (sequelize, DataTypes) => {
    const QuestionnaireQuestionOption = sequelize.define('QuestionnaireQuestionOption', {
        order: DataTypes.INTEGER,
        description: DataTypes.STRING,
        unique_id: DataTypes.STRING,
        question_id: DataTypes.INTEGER,
        version: DataTypes.INTEGER
      },
      {
        /*freezeTableName: true,
        name: {
          singular: "QuestionnaireQuestionOption",
          plural: "QuestionnaireQuestionOption"
        }*/
      }
    )
    QuestionnaireQuestionOption.associate = function (models) {
      // associations can be defined here
  
      QuestionnaireQuestionOption.belongsTo(models.QuestionnaireQuestion, {
        foreignKey: { name: "question_id", allowNull: false }
      })
    };
    return QuestionnaireQuestionOption;
};