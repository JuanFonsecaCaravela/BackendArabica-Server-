'use strict';
module.exports = (sequelize, DataTypes) => {
  const fertilizreRequirementCountry = sequelize.define('fertilizreRequirementCountry', {
    country: DataTypes.STRING,
    fertilizreRequirement_id: DataTypes.INTEGER
  }, {});
  fertilizreRequirementCountry.associate = function(models) {
    fertilizreRequirementCountry.belongsTo(models.fertilizreRequirement,{
      foreignKey: { name: "fertilizreRequirement_id", allowNull: false },
      onDelete: "CASCADE",
    })
  };
  return fertilizreRequirementCountry;
};