'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('SurveyApplies', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      id_country: {
        type: Sequelize.INTEGER,
        allowNull:false,
        references: {
          model: "country",
          key: "id"
        }
      },
      id_deparment: {
        type: Sequelize.INTEGER,
        allowNull:true,
        references: {
          model: "department",
          key: "id"
        }
      },
      id_survey: {
        type: Sequelize.INTEGER,
        allowNull:false,
        references: {
          model: "survey",
          key: "id"
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('SurveyApplies');
  }
};