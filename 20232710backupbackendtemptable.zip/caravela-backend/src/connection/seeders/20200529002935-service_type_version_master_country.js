'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert(
      "typeServices",
      [
        {
          id: 7,
          description: "Service Master Country",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    ),
    await queryInterface.bulkInsert(
      "serviceVersions",
      [
        {
          type_service_id: 7,
          version: 1,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ],
      {}
    )
  },

  down: (queryInterface, Sequelize) => {
    /*
      Add reverting commands here.
      Return a promise to correctly handle asynchronicity.

      Example:
      return queryInterface.bulkDelete('People', null, {});
    */
  }
};
