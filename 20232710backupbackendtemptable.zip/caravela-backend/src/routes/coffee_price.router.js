import express from "express";
import CoffeePriceController from "../controllers/coffee_price.controller";
const router = express.Router();

 router.post('/addCoffeePriceTable', CoffeePriceController.addCoffeePrice)
 router.get('/getAllCoffeePriceDetails', CoffeePriceController.getAllCoffeePriceDetails)
 router.get('/getCoffeePriceTable', CoffeePriceController.getCoffeePrice)  //mobile tablel api
 router.delete('/deleteCoffeePriceTableById/:coffeePrice_id', CoffeePriceController.delteCoffeePriceById)
 router.put("/updateCoffeePriceById", CoffeePriceController.updateCoffeePrice)
 router.get("/getCoffeePriceForWebByID/:coffeePrice_id",CoffeePriceController.getCoffeePriceForWebById)
 router.post('/filterCoffeePrice',CoffeePriceController.filterCoffeePrice)
 router.post('/getAllCoffeePriceDetailsPaginate',CoffeePriceController.getAllCoffeePriceDetailsPaginate)
 

 router.post("/addWareHouse", CoffeePriceController.addWareHouse)
 router.get("/getAllWareHouse", CoffeePriceController.getWareHouse)
 router.get("/getWareHouseById/:wareHouse_id", CoffeePriceController.getWareHouseById)
 router.delete("/deleteWareHouse/:id", CoffeePriceController.deleteWareHouse)
 router.put("/updateWareHouse/", CoffeePriceController.updateWareHouse)
 router.post('/filterWareHouse',CoffeePriceController.filterWareHouse) 
 router.post('/getAllWareHousePaginate',CoffeePriceController.getAllWareHousePaginate)
 router.get("/getWareHouseFilterById/:wareHouse_id", CoffeePriceController.getWareHouseFilterById) 
 
export default router;