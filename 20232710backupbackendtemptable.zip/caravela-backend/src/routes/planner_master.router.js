import express from "express";
import jwtService from "../services/jwt.service";
import ctrlPlannerMaster from "../controllers/planner_master.controller";

const router = express.Router();

const verifyToken = jwtService.verifyToken;

router.get("/all/:version/:uuid", verifyToken, ctrlPlannerMaster.findAll);

router.get("/allv2/:version/:uuid", verifyToken, ctrlPlannerMaster.findAllv2);

router.post('/', verifyToken, ctrlPlannerMaster.create);

router.get("/lastVersion", verifyToken, ctrlPlannerMaster.findAllLastVersion);

router.get("/:id", verifyToken, ctrlPlannerMaster.findAllByid);

router.put('/', verifyToken, ctrlPlannerMaster.update);


export default router;
